import { supabase } from '@/lib/supabaseClient';

    export const getPreviousMonthBalance = async (branchId, currentMonthYearText) => {
      const [year, month] = currentMonthYearText.split('-').map(Number);
      let prevYear = year;
      let prevMonth = month - 1;

      if (prevMonth === 0) {
        prevMonth = 12;
        prevYear -= 1;
      }

      const prevMonthYearText = `${prevYear}-${String(prevMonth).padStart(2, '0')}`;

      const { data, error } = await supabase
        .from('saldos_mensuales')
        .select('saldo')
        .eq('sucursal_id', branchId)
        .eq('mes_anio', prevMonthYearText)
        .single();

      if (error && error.code !== 'PGRST116') { 
        console.error(`Error fetching previous month balance for ${prevMonthYearText}, branch ${branchId}:`, error.message);
        return 0; 
      }
      return data ? Number(data.saldo) : 0;
    };

    export const calculateAndSaveCurrentMonthBalance = async (branchId, currentMonthYearText, userEmail) => {
      if (!branchId || !currentMonthYearText || !userEmail) {
        console.error('Missing parameters for calculateAndSaveCurrentMonthBalance', { branchId, currentMonthYearText, userEmail });
        throw new Error('Faltan parámetros para calcular el saldo mensual.');
      }

      const previousBalance = await getPreviousMonthBalance(branchId, currentMonthYearText);

      const startDate = `${currentMonthYearText}-01`;
      const tempDate = new Date(currentMonthYearText.split('-')[0], currentMonthYearText.split('-')[1], 0);
      const endDate = `${currentMonthYearText}-${String(tempDate.getDate()).padStart(2, '0')}`;


      const { data: entriesData, error: entriesError } = await supabase
        .from('entradas_diarias')
        .select('debe, haber')
        .eq('sucursal_id', branchId)
        .gte('fecha', startDate)
        .lte('fecha', endDate);

      if (entriesError) {
        console.error('Error fetching daily entries for balance calculation:', entriesError.message);
        throw new Error('Error al obtener movimientos para calcular saldo.');
      }

      let sumDebe = 0;
      let sumHaber = 0;
      if (entriesData) {
        entriesData.forEach(entry => {
          sumDebe += Number(entry.debe || 0);
          sumHaber += Number(entry.haber || 0);
        });
      }
      
      const currentMonthCalculatedSaldo = previousBalance + sumDebe - sumHaber;

      const { error: upsertError } = await supabase
        .from('saldos_mensuales')
        .upsert({
          sucursal_id: branchId,
          mes_anio: currentMonthYearText,
          saldo: currentMonthCalculatedSaldo,
          actualizado_por_email: userEmail,
          fecha_actualizacion: new Date().toISOString(),
        }, {
          onConflict: 'sucursal_id, mes_anio'
        });

      if (upsertError) {
        console.error('Error upserting monthly balance:', upsertError.message);
        throw new Error('Error al guardar el saldo mensual.');
      }

      return currentMonthCalculatedSaldo;
    };

    export const getMonthlyBalanceForDisplay = async (branchId, monthYearText) => {
      if (!branchId || !monthYearText) return null;

      const { data, error } = await supabase
        .from('saldos_mensuales')
        .select('saldo')
        .eq('sucursal_id', branchId)
        .eq('mes_anio', monthYearText)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error(`Error fetching display balance for ${monthYearText}, branch ${branchId}:`, error.message);
        return null; 
      }
      return data ? Number(data.saldo) : null;
    };