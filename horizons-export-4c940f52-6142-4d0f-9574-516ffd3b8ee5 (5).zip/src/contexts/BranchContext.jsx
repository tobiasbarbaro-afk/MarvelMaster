import React, { createContext, useState, useEffect, useContext, useCallback } from 'react';
    import { supabase } from '@/lib/supabaseClient';
    import { useToast } from '@/components/ui/use-toast';

    const BranchContext = createContext(null);

    export const useBranch = () => {
      const context = useContext(BranchContext);
      if (!context) {
        throw new Error('useBranch must be used within a BranchProvider');
      }
      return context;
    };

    export const BranchProvider = ({ children }) => {
      const [availableBranches, setAvailableBranches] = useState([]);
      const [selectedBranchId, setSelectedBranchIdState] = useState(() => {
        const storedBranchId = localStorage.getItem('selectedBranchId');
        return storedBranchId || null;
      });
      const [loadingBranches, setLoadingBranches] = useState(true);
      const { toast } = useToast();

      const fetchBranches = useCallback(async () => {
        setLoadingBranches(true);
        const { data, error } = await supabase
          .from('sucursales')
          .select('id, nombre')
          .order('nombre', { ascending: true });

        if (error) {
          console.error('Error fetching branches:', error);
          toast({ variant: "destructive", title: "Error", description: "No se pudieron cargar las sucursales." });
          setAvailableBranches([]);
          // No cambiar selectedBranchId aquí si ya hay uno de localStorage,
          // podría ser una sucursal válida aunque falle el fetch momentáneamente.
          // Si no hay sucursales, selectedBranchId se volverá null abajo.
        } else {
          const branchesData = data || [];
          setAvailableBranches(branchesData);
          const currentSelectedId = localStorage.getItem('selectedBranchId');

          if (branchesData.length > 0) {
            if (currentSelectedId && branchesData.some(branch => branch.id.toString() === currentSelectedId)) {
              // El ID almacenado es válido y existe en la lista, mantenerlo.
              setSelectedBranchIdState(currentSelectedId);
            } else {
              // El ID almacenado no es válido o no existe, o no hay ID almacenado.
              // Establecer uno por defecto.
              const zonaNorte = branchesData.find(branch => branch.nombre && branch.nombre.toLowerCase().includes('zona norte'));
              const defaultBranchId = zonaNorte ? zonaNorte.id.toString() : branchesData[0].id.toString();
              setSelectedBranchIdState(defaultBranchId);
              localStorage.setItem('selectedBranchId', defaultBranchId);
            }
          } else {
            // No hay sucursales disponibles
            setSelectedBranchIdState(null);
            localStorage.removeItem('selectedBranchId');
          }
        }
        setLoadingBranches(false);
      }, [toast]);

      useEffect(() => {
        fetchBranches();
      }, [fetchBranches]);

      const setSelectedBranchId = (branchId) => {
        const newBranchIdString = branchId ? branchId.toString() : null;
        if (newBranchIdString && newBranchIdString !== "null" && newBranchIdString !== "undefined") {
          localStorage.setItem('selectedBranchId', newBranchIdString);
          setSelectedBranchIdState(newBranchIdString);
        } else {
          localStorage.removeItem('selectedBranchId');
          setSelectedBranchIdState(null);
        }
      };
      
      const getBranchNameById = useCallback((branchId) => {
        if (!branchId || !availableBranches.length) return 'N/A';
        const branch = availableBranches.find(b => b.id.toString() === branchId.toString());
        return branch ? branch.nombre : 'Desconocida';
      }, [availableBranches]);

      return (
        <BranchContext.Provider value={{ availableBranches, selectedBranchId, setSelectedBranchId, loadingBranches, getBranchNameById, fetchBranches }}>
          {children}
        </BranchContext.Provider>
      );
    };