import React, { createContext, useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';

export const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
  
      const {
        data: { session },
      } = await supabase.auth.getSession();
  
      if (!session) {
        setUser(null);
        setUserProfile(null);
        setLoading(false);
        return;
      }
  
      setUser(session.user);
  
      const { data: profile, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('id', session.user.id)
        .single();
  
      if (error || !profile) {
        console.error('No se pudo obtener el perfil del usuario:', error);
        setUserProfile(null);
      } else {
        setUserProfile(profile);
      }
  
      setLoading(false);
    };
  
    fetchData();
  }, []);

  const login = async (email, password) => {
    setLoading(true);
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (data.user) {
      setUser(data.user);
      const { data: profile, error: profileError } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('id', data.user.id)
        .single();

      if (profileError || !profile) {
        console.error('No se pudo obtener el perfil del usuario tras login:', profileError);
        setUserProfile(null);
      } else {
        setUserProfile(profile);
      }
    }
    setLoading(false);
    return { data, error };
  };

  const logout = async () => {
    setLoading(true);
    const { error } = await supabase.auth.signOut();
    setUser(null); 
    setUserProfile(null);
    setLoading(false);
    return { error };
  };
  
  const signUp = async (email, password, metadata = {}) => {
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: metadata, 
      },
    });
    setLoading(false);
    return { data, error };
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      userProfile, 
      userRole: userProfile?.role, 
      login, 
      logout, 
      signUp, 
      isAuthenticated: !!user && !!userProfile, 
      loading
    }}>
      {children}
    </AuthContext.Provider>
  );
};