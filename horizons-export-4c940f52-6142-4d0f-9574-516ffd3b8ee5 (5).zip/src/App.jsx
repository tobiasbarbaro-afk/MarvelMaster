import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import { useAuth } from '@/hooks/useAuth';
import { BranchProvider } from '@/contexts/BranchContext';
import Layout from '@/components/Layout';
import LoginPage from '@/pages/LoginPage';
import DashboardPage from '@/pages/DashboardPage';
import BranchesPage from '@/pages/BranchesPage';
import SuppliersPage from '@/pages/SuppliersPage';
import EmployeesPage from '@/pages/EmployeesPage';
import SettingsPage from '@/pages/SettingsPage';
import CentralizedOrdersPage from '@/pages/CentralizedOrdersPage';
import CashClosingPage from '@/pages/CashClosingPage';
import EmployeePaymentsPage from '@/pages/EmployeePaymentsPage';
import CadetPaymentsPage from '@/pages/CadetPaymentsPage';
import StockTurnoPage from '@/pages/StockTurnoPage';
import ManagementPage from '@/pages/ManagementPage';
import SupervisionPage from '@/pages/SupervisionPage';
import PaymentsPage from '@/pages/PaymentsPage';
import ProviderOrdersPage from '@/pages/ProviderOrdersPage';
import ProductsPage from '@/pages/ProductsPage';
import SafeBoxPage from '@/pages/SafeBoxPage';
import LoansPage from '@/pages/LoansPage';
import ProtectedProviderOrdersRoute from '@/components/ProtectedProviderOrdersRoute';
import ProtectedAdminRoute from '@/components/ProtectedAdminRoute';
import ProtectedSafeBoxRoute from '@/components/ProtectedSafeBoxRoute';
import { Toaster } from '@/components/ui/toaster';
import ClarificationNotifier from '@/components/ClarificationNotifier';

const ProtectedRoute = ({ children, allowedRoles }) => {
  const { isAuthenticated, user, userProfile, loading, userRole } = useAuth();
  
  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <div className="text-primary text-xl">Cargando...</div>
      </div>
    );
  }
  
  if (!isAuthenticated && !loading) {
    return <Navigate to="/login" replace />;
  }

  if (user && !userProfile) {
     return (
      <div className="flex items-center justify-center h-screen bg-background">
        <div className="text-primary text-xl">Cargando perfil de usuario...</div>
      </div>
    );
  }

  if (allowedRoles && !allowedRoles.includes(userRole)) {
    return <Navigate to="/" replace />;
  }

  return children;
};

const AppRoutes = () => {
  const { isAuthenticated, loading, user, userProfile, userRole } = useAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <div className="text-primary text-xl">Cargando...</div>
      </div>
    );
  }
  
  if (!user) {
    return (
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    );
  }

  if (user && !userProfile) {
    return (
       <div className="flex items-center justify-center h-screen bg-background">
        <div className="text-primary text-xl">Cargando perfil de usuario...</div>
      </div>
    )
  }
  
  const getDefaultRouteForRole = (role) => {
    switch (role) {
      case 'admin':
        return '/supervision';
      case 'gerente':
        return '/';
      case 'cocina':
        return '/stock-turno';
      case 'mostrador':
        return '/cash-closing';
      case 'centralizada':
        return '/centralized-orders';
      default:
        return '/';
    }
  };

  return (
    <>
      {isAuthenticated && <ClarificationNotifier />}
      <Routes>
        <Route path="/login" element={isAuthenticated ? <Navigate to={getDefaultRouteForRole(userRole)} /> : <LoginPage />} />
        <Route 
          path="/" 
          element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          }
        >
          <Route index element={['admin', 'gerente'].includes(userRole) ? <DashboardPage /> : <Navigate to={getDefaultRouteForRole(userRole)} replace />} />
          
          <Route path="stock-turno" element={<ProtectedRoute allowedRoles={['admin', 'gerente', 'centralizada', 'cocina']}><StockTurnoPage /></ProtectedRoute>} />
          <Route path="centralized-orders" element={<ProtectedRoute allowedRoles={['admin', 'centralizada', 'gerente', 'cocina']}><CentralizedOrdersPage /></ProtectedRoute>} />
          <Route path="/provider-orders" element={<ProtectedProviderOrdersRoute><ProviderOrdersPage /></ProtectedProviderOrdersRoute>} />
          
          <Route path="safe-box" element={<ProtectedSafeBoxRoute><SafeBoxPage /></ProtectedSafeBoxRoute>} />
          <Route path="daily-entry" element={<Navigate to="/safe-box" replace />} />
          <Route path="update-sheet" element={<Navigate to="/safe-box" replace />} />

          {['admin', 'gerente', 'mostrador'].includes(userRole) && (
            <>
              <Route path="cash-closing" element={<CashClosingPage />} />
            </>
          )}

          {['admin', 'gerente'].includes(userRole) && (
            <>
              <Route path="management" element={<ManagementPage />} />
              <Route path="employee-payments" element={<EmployeePaymentsPage />} />
              <Route path="cadet-payments" element={<CadetPaymentsPage />} />
              <Route path="employees" element={<EmployeesPage />} />
              <Route path="loans" element={<ProtectedRoute allowedRoles={['admin', 'gerente']}><LoansPage /></ProtectedRoute>} />
            </>
          )}

          {userRole === 'admin' && (
            <>
              <Route path="supervision" element={<SupervisionPage />} />
              <Route path="branches" element={<BranchesPage />} />
              <Route path="suppliers" element={<SuppliersPage />} />
              <Route path="settings" element={<SettingsPage />} />
              <Route path="pagos" element={<PaymentsPage />} />
              <Route path="products" element={<ProtectedAdminRoute><ProductsPage /></ProtectedAdminRoute>} />
            </>
          )}
        </Route>
        <Route path="*" element={<Navigate to={isAuthenticated ? getDefaultRouteForRole(userRole) : "/login"} replace />} />
      </Routes>
    </>
  );
};

function App() {
  return (
    <AuthProvider>
      <BranchProvider>
        <Router>
          <AppRoutes />
          <Toaster />
        </Router>
      </BranchProvider>
    </AuthProvider>
  );
}

export default App;