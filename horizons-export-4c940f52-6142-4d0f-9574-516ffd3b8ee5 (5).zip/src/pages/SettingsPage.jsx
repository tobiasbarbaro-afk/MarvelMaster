import React, { useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';
import { calculateAndSaveCurrentMonthBalance } from '@/services/balanceService';
import { logModificationAndNotify } from '@/lib/modificationLogger';
import { useBranch } from '@/contexts/BranchContext';

const SettingsPage = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const { getBranchNameById } = useBranch();
  const [isProcessing, setIsProcessing] = useState(false);

  // The handleManualEntryCreation function and the button that triggered it are being removed.
  // This functionality was temporary for specific data adjustments.

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-6">Configuración</h1>
      <div className="bg-card p-6 rounded-lg shadow-sm border">
        <h2 className="text-lg font-semibold mb-2">Herramientas de Administrador</h2>
        <p className="text-muted-foreground mb-4">
          Aquí podrás encontrar opciones de configuración avanzadas y herramientas para la administración del sistema.
        </p>
        {/* The button for manual entry creation has been removed as requested. */}
        <p className="text-sm text-muted-foreground">
          Actualmente no hay herramientas adicionales disponibles en esta sección.
        </p>
      </div>
    </div>
  );
};

export default SettingsPage;