import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogTrigger } from '@/components/ui/dialog';
import { History } from 'lucide-react';
import { formatDateForDB, getBuenosAiresTime } from '@/lib/sheetUtils';
import EmployeePaymentStep1 from '@/components/employee_payments/EmployeePaymentStep1';
import EmployeePaymentForm from '@/components/employee_payments/EmployeePaymentForm';
import EmployeePaymentHistory from '@/components/employee_payments/EmployeePaymentHistory';

const EmployeePaymentsPage = () => {
    const { userRole, userProfile, user } = useAuth();
    const { toast } = useToast();

    const [selectedBranchId, setSelectedBranchId] = useState('');
    const [paymentDate, setPaymentDate] = useState(getBuenosAiresTime());
    const [payments, setPayments] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [step, setStep] = useState(1);

    useEffect(() => {
        if (userRole === 'gerente' && userProfile?.sucursal_id) {
            setSelectedBranchId(userProfile.sucursal_id.toString());
        }
    }, [userProfile, userRole]);

    const fetchEmployeesForPayment = async () => {
        if (!selectedBranchId) return;
        setIsLoading(true);
        
        try {
            // Fetch employees
            const { data: employeesData, error: employeesError } = await supabase
                .from('empleados')
                .select('*')
                .eq('sucursal_id', selectedBranchId);

            if (employeesError) throw employeesError;

            // Fetch active loans for this branch
            const { data: loansData, error: loansError } = await supabase
                .from('prestamos_empleados')
                .select('*')
                .eq('sucursal_id', selectedBranchId)
                .gt('saldo_actual', 0);

            if (loansError) throw loansError;

            const initialPayments = employeesData.map(emp => {
                const empLoans = loansData.filter(l => l.empleado_id === emp.id);
                
                return {
                    empleado_id: emp.id,
                    nombre_completo: emp.nombre_completo,
                    puesto: emp.puesto,
                    tipo_pago: emp.tipo_pago,
                    monto_base: emp.monto,
                    horas_trabajadas: '',
                    efectivo: '',
                    transferencia: '',
                    descuentos: '',
                    descuento_prestamo: '',
                    extras: '',
                    detalle: '',
                    recibo: null,
                    recibo_nombre: '',
                    total_a_pagar: emp.tipo_pago === 'Fijo' ? (parseFloat(emp.monto) || 0) : 0,
                    prestamos_activos: empLoans // Store active loans in row
                };
            });
            
            setPayments(initialPayments);
            setStep(2);
        } catch (error) {
            console.error("Error fetching data for payments:", error);
            toast({ variant: 'destructive', title: 'Error', description: 'No se pudieron cargar los datos necesarios.' });
        } finally {
            setIsLoading(false);
        }
    };

    const isRowValid = (p) => {
        const totalPagado = (parseFloat(p.efectivo) || 0) + (parseFloat(p.transferencia) || 0);
        const totalAPagar = parseFloat(p.total_a_pagar) || 0;
        return p.recibo && totalAPagar > 0 && Math.abs(totalPagado - totalAPagar) < 0.01;
    };

    const processPayments = async () => {
        setIsLoading(true);
        
        const validPayments = payments.filter(isRowValid);

        if (validPayments.length === 0) {
            toast({ variant: 'destructive', title: 'Sin pagos válidos', description: 'No hay filas completas para procesar.' });
            setIsLoading(false);
            return;
        }

        const totalEfectivo = validPayments.reduce((acc, p) => acc + (parseFloat(p.efectivo) || 0), 0);
        const totalGeneral = validPayments.reduce((acc, p) => acc + p.total_a_pagar, 0);
        const paymentDateFormatted = formatDateForDB(paymentDate); 
        const paymentsWithUrls = [];

        try {
            for (const payment of validPayments) {
                // 1. Upload receipt
                const filePath = `${selectedBranchId}/${paymentDateFormatted}/${payment.empleado_id}-${Date.now()}-${payment.recibo.name}`;
                const { error: uploadError } = await supabase.storage
                    .from('recibos-pagos-empleados')
                    .upload(filePath, payment.recibo);

                if (uploadError) throw new Error(`Error al subir el recibo de ${payment.nombre_completo}: ${uploadError.message}`);

                const { data: { publicUrl } } = supabase.storage.from('recibos-pagos-empleados').getPublicUrl(filePath);
                
                // 2. Process Loan Deductions if any
                const deduccionPrestamo = parseFloat(payment.descuento_prestamo) || 0;
                if (deduccionPrestamo > 0 && payment.prestamos_activos?.length > 0) {
                    let remainingDeduction = deduccionPrestamo;
                    
                    // Iterate through active loans to deduct
                    for (const loan of payment.prestamos_activos) {
                        if (remainingDeduction <= 0) break;
                        
                        const currentBalance = parseFloat(loan.saldo_actual);
                        const deductionForThisLoan = Math.min(currentBalance, remainingDeduction);
                        const newBalance = currentBalance - deductionForThisLoan;
                        
                        // Update loan balance
                        const { error: updateLoanError } = await supabase
                            .from('prestamos_empleados')
                            .update({ saldo_actual: newBalance })
                            .eq('id', loan.id);
                            
                        if (updateLoanError) throw new Error(`Error actualizando préstamo de ${payment.nombre_completo}`);
                        
                        // Register movement
                        const { error: movError } = await supabase
                            .from('movimientos_prestamos')
                            .insert([{
                                prestamo_id: loan.id,
                                tipo_movimiento: 'pago',
                                monto: deductionForThisLoan,
                                saldo_anterior: currentBalance,
                                saldo_nuevo: newBalance
                            }]);
                            
                        if (movError) throw new Error(`Error registrando movimiento de préstamo`);
                        
                        remainingDeduction -= deductionForThisLoan;
                    }
                }

                paymentsWithUrls.push({
                    ...payment,
                    recibo_url: publicUrl,
                    recibo: undefined, 
                    prestamos_activos: undefined // Clean up payload
                });
            }

            // 3. Register Safe Box Egreso if Cash was used
            if (totalEfectivo > 0) {
                const { error: dailyEntryError } = await supabase.from('entradas_diarias').insert({
                    fecha: paymentDateFormatted,
                    monto: totalEfectivo,
                    ioe: 'E',
                    tipo_ioe: 'Pago de Empleados',
                    razon_social: 'Varios',
                    observaciones: `Pago de sueldos en efectivo a ${validPayments.length} empleados.`,
                    haber: totalEfectivo,
                    debe: 0,
                    sucursal_id: parseInt(selectedBranchId),
                    usuario_email: user.email,
                });
                if (dailyEntryError) throw new Error(`Error al crear el egreso en la planilla: ${dailyEntryError.message}`);
            }

            // 4. Save Payment Record
            const { error: paymentRecordError } = await supabase.from('pagos_empleados').insert({
                sucursal_id: parseInt(selectedBranchId),
                usuario_id: user.id,
                fecha_pago: paymentDateFormatted,
                total_pagado: totalGeneral,
                pagos_individuales: paymentsWithUrls,
                estado: 'pendiente de verificación'
            });
            
            if (paymentRecordError) throw new Error(`Error al guardar el registro de pago: ${paymentRecordError.message}`);

            toast({ title: 'Éxito', description: `${validPayments.length} pagos procesados y enviados a verificación.` });
            resetForm();

        } catch (error) {
            toast({ variant: 'destructive', title: 'Error en el procesamiento', description: error.message });
        } finally {
            setIsLoading(false);
        }
    };
    
    const resetForm = () => {
        setStep(1);
        setPayments([]);
        setPaymentDate(getBuenosAiresTime());
        if(userRole === 'admin') setSelectedBranchId('');
    };

    return (
        <div className="container mx-auto p-4 md:p-8 flex flex-col h-[calc(100vh-2rem)]">
            <Helmet>
                <title>Pago de Empleados - MarvelMaster</title>
                <meta name="description" content="Gestión y procesamiento de pagos a empleados." />
            </Helmet>
            <div className="flex justify-between items-center mb-6 flex-shrink-0">
                <h1 className="text-3xl font-bold text-primary">Pago de Empleados</h1>
                <Dialog>
                    <DialogTrigger asChild>
                        <Button variant="outline"><History className="mr-2 h-4 w-4" /> Historial de Pagos</Button>
                    </DialogTrigger>
                    <EmployeePaymentHistory />
                </Dialog>
            </div>
            
            <Card className="w-full flex-grow flex flex-col overflow-hidden">
                <CardHeader className="flex-shrink-0">
                    <CardTitle>Proceso de Pago - Paso {step} de 2</CardTitle>
                    <CardDescription>
                        {step === 1 ? 'Seleccione sucursal y fecha para iniciar el pago.' : 'Complete el formulario para cada empleado y adjunte los recibos.'}
                    </CardDescription>
                </CardHeader>
                <CardContent className="flex-grow flex flex-col overflow-hidden">
                    {step === 1 && (
                        <EmployeePaymentStep1
                            selectedBranchId={selectedBranchId}
                            setSelectedBranchId={setSelectedBranchId}
                            paymentDate={paymentDate}
                            setPaymentDate={setPaymentDate}
                            isLoading={isLoading}
                            onNext={fetchEmployeesForPayment}
                        />
                    )}
                    {step === 2 && (
                        <EmployeePaymentForm
                            payments={payments}
                            setPayments={setPayments}
                            isLoading={isLoading}
                            onProcess={processPayments}
                            onReset={resetForm}
                        />
                    )}
                </CardContent>
            </Card>
        </div>
    );
};

export default EmployeePaymentsPage;