import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Search, Loader2 } from 'lucide-react';
import { useBranch } from '@/contexts/BranchContext';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import DocumentUploadForm from '@/components/invoice_processing/DocumentUploadForm';
import DocumentList from '@/components/invoice_processing/DocumentList';
import UploadInvoiceDialog from '@/components/invoice_processing/UploadInvoiceDialog';
import { useAuth } from '@/hooks/useAuth';

const InvoiceProcessingPage = () => {
  const { availableBranches, loadingBranches } = useBranch();
  const { userRole, userProfile } = useAuth();
  const [suppliers, setSuppliers] = useState([]);
  const [loadingSuppliers, setLoadingSuppliers] = useState(true);
  
  const [formBranchId, setFormBranchId] = useState('');
  const [formSupplierId, setFormSupplierId] = useState('');
  
  const [filterBranchId, setFilterBranchId] = useState('ALL');
  const [filterSupplierId, setFilterSupplierId] = useState('ALL');

  const [uploadedDocuments, setUploadedDocuments] = useState([]);
  const [loadingDocuments, setLoadingDocuments] = useState(false);
  const [isSubmittingFlagChange, setIsSubmittingFlagChange] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  
  const [isUploadInvoiceDialogOpen, setIsUploadInvoiceDialogOpen] = useState(false);
  const [selectedOCToUploadInvoice, setSelectedOCToUploadInvoice] = useState(null);

  const { toast } = useToast();

  useEffect(() => {
    if (!['admin', 'centralizada'].includes(userRole) && userProfile?.sucursal_id) {
      const branchIdStr = userProfile.sucursal_id.toString();
      setFormBranchId(branchIdStr);
      setFilterBranchId(branchIdStr);
    }
  }, [userProfile, userRole]);

  const handleFormBranchChange = (value) => {
    setFormBranchId(value);
  };

  const handleFormSupplierChange = (value) => {
    setFormSupplierId(value);
  };

  const handleFilterBranchChange = (value) => {
    setFilterBranchId(value);
  };

  const handleFilterSupplierChange = (value) => {
    setFilterSupplierId(value);
  };

  const fetchSuppliers = useCallback(async () => {
    setLoadingSuppliers(true);
    const { data, error } = await supabase.from('suppliers').select('id, name').order('name', { ascending: true });
    if (error) {
      toast({ variant: "destructive", title: "Error", description: "No se pudieron cargar los proveedores." });
      setSuppliers([]);
    } else {
      setSuppliers(data || []);
    }
    setLoadingSuppliers(false);
  }, [toast]);
  
  const handleSearch = useCallback(async () => {
    setLoadingDocuments(true);
    setHasSearched(true);
    
    const baseFields = 'id, fecha, numero_pedido, archivo_url, verificado, cargado_en_sistema, pdf_fusionado_url, creado_en, sucursal_id, proveedor_id, sucursales(nombre), suppliers(name)';

    let facturasQuery = supabase.from('facturas').select(`${baseFields}, orden_compra_id`);
    if (filterBranchId !== 'ALL') facturasQuery = facturasQuery.eq('sucursal_id', filterBranchId);
    if (filterSupplierId !== 'ALL') facturasQuery = facturasQuery.eq('proveedor_id', filterSupplierId);
    facturasQuery = facturasQuery.order('creado_en', { ascending: false });

    let ordenesQuery = supabase.from('ordenes_compra').select(`${baseFields}, factura_id`);
    if (filterBranchId !== 'ALL') ordenesQuery = ordenesQuery.eq('sucursal_id', filterBranchId);
    if (filterSupplierId !== 'ALL') ordenesQuery = ordenesQuery.eq('proveedor_id', filterSupplierId);
    ordenesQuery = ordenesQuery.order('creado_en', { ascending: false });

    const [
      { data: facturasData, error: facturasError },
      { data: ordenesData, error: ordenesError }
    ] = await Promise.all([facturasQuery, ordenesQuery]);
    
    if (facturasError) toast({ variant: "destructive", title: `Error cargando Facturas`, description: facturasError.message });
    if (ordenesError) toast({ variant: "destructive", title: `Error cargando Órdenes de Compra`, description: ordenesError.message });

    const processedDocuments = [];
    const processedMergedIds = new Set();

    (facturasData || []).forEach(factura => {
        if (factura.orden_compra_id && factura.pdf_fusionado_url) {
            const ocAsociada = (ordenesData || []).find(oc => oc.id === factura.orden_compra_id);
            processedDocuments.push({
                ...factura, 
                unique_id: `merged-${factura.id}`,
                id_for_flags: factura.id, 
                tipo_for_flags: 'Factura',
                is_merged_document: true,
                tipo_documento: 'Documento Fusionado',
                numero_pedido_display: `FAC: ${factura.numero_pedido} / OC: ${ocAsociada ? ocAsociada.numero_pedido : 'N/A'}`,
                fecha_display: factura.fecha, 
                archivo_url_display: factura.pdf_fusionado_url,
            });
            processedMergedIds.add(factura.id); 
            if (ocAsociada) processedMergedIds.add(ocAsociada.id); 
        } else if (!processedMergedIds.has(factura.id)) {
            processedDocuments.push({
                ...factura,
                unique_id: `factura-${factura.id}`, id_for_flags: factura.id, tipo_for_flags: 'Factura',
                is_merged_document: false, tipo_documento: 'Factura',
                numero_pedido_display: factura.numero_pedido, fecha_display: factura.fecha, archivo_url_display: factura.archivo_url,
            });
        }
    });

    (ordenesData || []).forEach(oc => {
        if (!processedMergedIds.has(oc.id)) {
            processedDocuments.push({
                ...oc,
                unique_id: `oc-${oc.id}`, id_for_flags: oc.id, tipo_for_flags: 'Orden de Compra',
                is_merged_document: false, tipo_documento: 'Orden de Compra',
                numero_pedido_display: oc.numero_pedido, fecha_display: oc.fecha, archivo_url_display: oc.archivo_url,
            });
        }
    });
    
    setUploadedDocuments(processedDocuments.sort((a, b) => new Date(b.creado_en) - new Date(a.creado_en)));
    setLoadingDocuments(false);
  }, [filterBranchId, filterSupplierId, toast]);

  useEffect(() => {
    fetchSuppliers();
  }, [fetchSuppliers]);
  
  const handleFlagChange = async (docId, flagType, currentValue, docTipo) => {
    if (!['admin', 'gerente', 'centralizada'].includes(userRole)) {
        toast({ variant: "destructive", title: "Acceso Denegado", description: "No tienes permisos para verificar documentos." });
        return;
    }
    const tableName = docTipo === 'Factura' ? 'facturas' : 'ordenes_compra';
    setIsSubmittingFlagChange(true); 
    const { error } = await supabase.from(tableName).update({ [flagType]: !currentValue }).eq('id', docId);
    
    if (error) {
      toast({ variant: "destructive", title: "Error", description: `No se pudo actualizar el estado: ${error.message}` });
    } else {
      toast({ title: "Éxito", description: "Estado actualizado." });
      handleSearch();
    }
    setIsSubmittingFlagChange(false);
  };
  
  const handleUploadInvoiceClick = (ordenDeCompra) => {
    setSelectedOCToUploadInvoice(ordenDeCompra);
    setIsUploadInvoiceDialogOpen(true);
  };

  const onDocumentManipulationSuccess = () => { 
    handleSearch();
  };
  
  const canSelectFilterBranch = ['admin', 'centralizada', 'gerente'].includes(userRole);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-8 p-4 md:p-6"
    >
      <h1 className="text-3xl md:text-4xl font-bold text-primary text-center tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-primary to-accent">
        Procesamiento de Documentos
      </h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="shadow-xl border-border lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-xl">Cargar Orden de Compra</CardTitle>
            <CardDescription>Adjunte el PDF de la OC y complete los detalles.</CardDescription>
          </CardHeader>
          <CardContent>
            <DocumentUploadForm 
              suppliers={suppliers}
              loadingSuppliers={loadingSuppliers}
              availableBranches={availableBranches}
              loadingBranches={loadingBranches}
              selectedBranchId={formBranchId}
              selectedSupplierId={formSupplierId}
              onBranchChange={handleFormBranchChange}
              onSupplierChange={handleFormSupplierChange}
              onUploadSuccess={onDocumentManipulationSuccess} 
            />
          </CardContent>
        </Card>

        <Card className="shadow-xl border-border lg:col-span-2">
          <CardHeader>
            <div className="flex flex-col space-y-4 md:flex-row md:justify-between md:items-center md:space-y-0">
                <div>
                  <CardTitle className="text-xl">Documentos Cargados</CardTitle>
                  <CardDescription>Visualice y filtre documentos. Cargue facturas para OCs existentes.</CardDescription>
                </div>
                <div className="flex flex-col gap-4 md:flex-row md:items-end">
                  <div>
                    <Label htmlFor="filter-branch" className="text-sm font-medium">Filtrar Sucursal</Label>
                    <Select onValueChange={handleFilterBranchChange} value={filterBranchId} disabled={loadingBranches || !canSelectFilterBranch}>
                      <SelectTrigger id="filter-branch" className="w-full md:w-[180px]">
                        <SelectValue placeholder="Sucursal..." />
                      </SelectTrigger>
                      <SelectContent>
                        {canSelectFilterBranch && <SelectItem value="ALL">Todas las sucursales</SelectItem>}
                        {availableBranches.map(branch => (
                          <SelectItem key={branch.id} value={branch.id.toString()}>{branch.nombre}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="filter-supplier" className="text-sm font-medium">Filtrar Proveedor</Label>
                    <Select onValueChange={handleFilterSupplierChange} value={filterSupplierId} disabled={loadingSuppliers}>
                      <SelectTrigger id="filter-supplier" className="w-full md:w-[180px]">
                        <SelectValue placeholder="Proveedor..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ALL">Todos los proveedores</SelectItem>
                        {suppliers.map(supplier => (
                          <SelectItem key={supplier.id} value={supplier.id.toString()}>{supplier.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <Button onClick={handleSearch} disabled={loadingDocuments} className="w-full md:w-auto">
                    {loadingDocuments ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Search className="mr-2 h-4 w-4" />}
                    Buscar
                  </Button>
                </div>
            </div>
          </CardHeader>
          <CardContent>
            <DocumentList
              documents={uploadedDocuments}
              loading={loadingDocuments}
              isSubmitting={isSubmittingFlagChange}
              onFlagChange={handleFlagChange}
              onUploadInvoiceClick={handleUploadInvoiceClick}
              hasSearched={hasSearched}
            />
          </CardContent>
        </Card>
      </div>
      
      {selectedOCToUploadInvoice && (
        <UploadInvoiceDialog
          isOpen={isUploadInvoiceDialogOpen}
          onClose={() => {
            setIsUploadInvoiceDialogOpen(false);
            setSelectedOCToUploadInvoice(null);
          }}
          onUploadSuccess={onDocumentManipulationSuccess} 
          ordenDeCompra={selectedOCToUploadInvoice}
        />
      )}

    </motion.div>
  );
};

export default InvoiceProcessingPage;