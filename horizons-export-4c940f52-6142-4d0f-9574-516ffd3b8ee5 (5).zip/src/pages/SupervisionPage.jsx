import React, { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/hooks/useAuth';
import { useBranch } from '@/contexts/BranchContext';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Shield, LayoutDashboard } from 'lucide-react';
import SheetStatus from '@/components/supervision/SheetStatus';
import ClosingStatus from '@/components/supervision/ClosingStatus';
import OrderHistory from '@/components/supervision/OrderHistory';
import UnverifiedClosings from '@/components/dashboard/UnverifiedClosings';
import PendingPayments from '@/components/dashboard/PendingPayments';
import PendingCadetPayments from '@/components/dashboard/PendingCadetPayments';
import SupervisionClosingList from '@/components/supervision/SupervisionClosingList';

const EXCLUDED_BRANCH_NAMES = [
  "Frigorífico",
  "Sala de Expedición - Central",
  "Cocina Centralizada",
  "Verdulería - Producción"
];

const SupervisionPage = () => {
  const { userRole } = useAuth();
  const { availableBranches } = useBranch();
  const [selectedBranchId, setSelectedBranchId] = useState('all');

  // Filter branches for the dropdown and to pass to child components
  const filteredBranches = useMemo(() => {
    return availableBranches.filter(branch => 
      !EXCLUDED_BRANCH_NAMES.includes(branch.nombre)
    );
  }, [availableBranches]);

  if (userRole !== 'admin') {
    return (
      <div className="flex justify-center items-center h-full">
        <Card className="w-full max-w-md text-center p-8">
          <CardHeader>
            <Shield className="mx-auto h-16 w-16 text-destructive" />
            <CardTitle className="text-2xl mt-4">Acceso Denegado</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Esta sección es exclusiva para administradores.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }} 
      animate={{ opacity: 1, y: 0 }} 
      transition={{ duration: 0.5 }} 
      className="space-y-6"
    >
      <Helmet>
        <title>Módulo de Supervisión - MarvelMaster</title>
        <meta name="description" content="Panel de control general para supervisión." />
      </Helmet>

      <Card className="shadow-lg border-primary/20">
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <CardTitle className="text-3xl font-bold text-primary flex items-center gap-3">
                <LayoutDashboard className="h-8 w-8" />
                Módulo de Supervisión
              </CardTitle>
              <CardDescription className="mt-2 text-lg">
                Panel de control general para la visualización y gestión de todas las sucursales.
              </CardDescription>
            </div>
            <div className="w-full sm:w-64">
              <Label htmlFor="branch-filter-supervision">Filtrar por Sucursal</Label>
              <Select onValueChange={setSelectedBranchId} value={selectedBranchId}>
                <SelectTrigger id="branch-filter-supervision">
                  <SelectValue placeholder="Seleccionar sucursal..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas las Sucursales</SelectItem>
                  {filteredBranches.map(branch => (
                    <SelectItem key={branch.id} value={branch.id.toString()}>
                      {branch.nombre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-1 space-y-6">
          {/* 1. STATUS PLANILLA DIARIA */}
          <SheetStatus 
            selectedBranchId={selectedBranchId} 
            branches={filteredBranches} 
            excludedBranches={EXCLUDED_BRANCH_NAMES}
          />
          {/* 2. STATUS CIERRE DE CAJA */}
          <ClosingStatus 
            selectedBranchId={selectedBranchId} 
            branches={filteredBranches} 
            excludedBranches={EXCLUDED_BRANCH_NAMES}
          />
        </div>
        <div className="xl:col-span-2 space-y-6">
          {/* 3. TABLERO DE VERIFICACIONES */}
          <div>
            <h2 className="text-2xl font-semibold mb-4">Tablero de Verificaciones</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              <UnverifiedClosings 
                selectedBranchId={selectedBranchId} 
                excludedBranches={EXCLUDED_BRANCH_NAMES}
              />
              <PendingPayments 
                selectedBranchId={selectedBranchId} 
                excludedBranches={EXCLUDED_BRANCH_NAMES}
              />
              <PendingCadetPayments 
                selectedBranchId={selectedBranchId} 
                excludedBranches={EXCLUDED_BRANCH_NAMES}
              />
            </div>
            {/* Nueva sección: Verificaciones pendientes de nivel 2 (Supervisión/Admin) */}
            <div className="mt-6">
                <h3 className="text-lg font-semibold mb-2 text-blue-600">Validaciones de Cierres (Instancia 2)</h3>
                <Card>
                    <CardContent className="p-4">
                         <SupervisionClosingList 
                            selectedBranchId={selectedBranchId} 
                            excludedBranches={EXCLUDED_BRANCH_NAMES}
                         />
                    </CardContent>
                </Card>
            </div>
          </div>
          {/* 4. HISTORIAL DE PEDIDOS */}
          <OrderHistory 
            selectedBranchId={selectedBranchId} 
            excludedBranches={EXCLUDED_BRANCH_NAMES}
          />
        </div>
      </div>
    </motion.div>
  );
};

export default SupervisionPage;