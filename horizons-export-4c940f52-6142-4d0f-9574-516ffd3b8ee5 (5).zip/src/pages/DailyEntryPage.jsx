import React from 'react';
    import EntryForm from '@/components/daily_entry/EntryForm';
    
    const DailyEntryPage = () => {
      return <EntryForm />;
    };
    
    export default DailyEntryPage;