import React, { useState, useEffect } from 'react';
    import { motion } from 'framer-motion';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
    import ImportSection from '@/components/sheet/ImportSection';
    import ExportSection from '@/components/sheet/ExportSection';
    import ClearSheetSection from '@/components/sheet/ClearSheetSection';
    import ViewSheetSection from '@/components/sheet/ViewSheetSection';
    import { useAuth } from '@/hooks/useAuth';
    import { useBranch } from '@/contexts/BranchContext';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/supabaseClient';

    const UpdateSheetPage = () => {
      const { userRole, user, userProfile } = useAuth();
      const { 
        availableBranches, 
        loadingBranches, 
        getBranchNameById,
        fetchBranches 
      } = useBranch();
      const { toast } = useToast();

      const [selectedBranchId, setSelectedBranchId] = useState('');
      const [currentTab, setCurrentTab] = useState("import");
      
      const [viewSheetKey, setViewSheetKey] = useState(Date.now());

      useEffect(() => {
        if (userRole === 'gerente' && userProfile?.sucursal_id) {
          setSelectedBranchId(userProfile.sucursal_id.toString());
        }
      }, [userProfile, userRole]);

      const handleClearSuccess = () => {
        if (currentTab === "view") {
          setViewSheetKey(Date.now()); 
        }
        fetchBranches();
      };

      const commonSheetProps = {
        supabase,
        toast,
        user,
        availableBranches,
        selectedBranchId: selectedBranchId,
        setSelectedBranchId: setSelectedBranchId,
        loadingBranches,
        getBranchNameById,
      };

      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-8"
        >
          <Card className="shadow-xl border-border bg-card/80 backdrop-blur-sm">
            <CardHeader className="text-center pb-2">
              <CardTitle className="text-3xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-primary via-accent to-secondary py-1">
                Gestión de Planilla Diaria
              </CardTitle>
              <CardDescription className="text-muted-foreground text-lg">
                Importe, exporte, visualice o vacíe los datos de la planilla diaria por sucursal y mes.
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <Tabs defaultValue="import" className="w-full" onValueChange={setCurrentTab}>
                <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 gap-2 mb-6 bg-muted p-1 rounded-lg">
                  <TabsTrigger value="import" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-md">Importar</TabsTrigger>
                  <TabsTrigger value="export" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-md">Exportar</TabsTrigger>
                  <TabsTrigger value="view" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-md">Visualizar</TabsTrigger>
                  {userRole === 'admin' && (
                    <TabsTrigger value="clear" className="data-[state=active]:bg-destructive data-[state=active]:text-destructive-foreground data-[state=active]:shadow-md">Vaciar</TabsTrigger>
                  )}
                </TabsList>
                
                <TabsContent value="import">
                  <ImportSection {...commonSheetProps} onImportSuccess={handleClearSuccess} />
                </TabsContent>
                <TabsContent value="export">
                  <ExportSection {...commonSheetProps} />
                </TabsContent>
                <TabsContent value="view">
                  <ViewSheetSection key={viewSheetKey} {...commonSheetProps} />
                </TabsContent>
                {userRole === 'admin' && (
                  <TabsContent value="clear">
                    <ClearSheetSection {...commonSheetProps} onClearSuccess={handleClearSuccess} />
                  </TabsContent>
                )}
              </Tabs>
            </CardContent>
          </Card>
        </motion.div>
      );
    };

    export default UpdateSheetPage;