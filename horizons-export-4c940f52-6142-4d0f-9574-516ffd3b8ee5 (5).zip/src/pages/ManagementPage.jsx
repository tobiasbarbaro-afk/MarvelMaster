import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/hooks/useAuth';
import { useBranch } from '@/contexts/BranchContext';
import { supabase } from '@/lib/supabaseClient';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Loader2, CalendarClock, Package, Archive } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import StockStatusDashboard from '@/components/management/StockStatusDashboard';
import UnverifiedClosingsList from '@/components/management/UnverifiedClosingsList';
import PendingOrdersList from '@/components/management/PendingOrdersList';

const ManagementPage = () => {
    const { userRole, userProfile } = useAuth();
    const { availableBranches, loadingBranches } = useBranch();
    const [selectedSucursalId, setSelectedSucursalId] = useState('');
    const [refreshKey, setRefreshKey] = useState(0);

    useEffect(() => {
        if (userRole === 'gerente' && userProfile?.sucursal_id) {
            setSelectedSucursalId(userProfile.sucursal_id.toString());
        } else if (userRole === 'admin' && availableBranches.length > 0) {
            if (!selectedSucursalId) {
               setSelectedSucursalId(availableBranches[0].id.toString());
            }
        }
    }, [userRole, userProfile, availableBranches, selectedSucursalId]);

    const handleRefresh = () => {
      setRefreshKey(prev => prev + 1);
    };

    const sections = [
        { id: 'stock', title: 'Estado de Stock (Últimas 48hs)', icon: CalendarClock, component: StockStatusDashboard },
        { id: 'closings', title: 'Cierres de Caja Pendientes', icon: Archive, component: UnverifiedClosingsList },
        { id: 'orders', title: 'Pedidos a Centralizada Activos', icon: Package, component: PendingOrdersList },
    ];

    return (
        <div className="container mx-auto p-4 space-y-8">
            <Helmet>
                <title>Gerencia - MarvelMaster</title>
                <meta name="description" content="Panel de control y verificación para gerentes y administradores." />
            </Helmet>

            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
                <CardHeader className="text-center px-0">
                    <CardTitle className="text-3xl font-bold">Panel de Gerencia</CardTitle>
                    <CardDescription>Supervisión y control de operaciones de sucursales.</CardDescription>
                </CardHeader>
            </motion.div>

            {userRole === 'admin' && (
                <Card>
                    <CardContent className="p-4">
                        <Label htmlFor="sucursal-selector">Seleccionar Sucursal</Label>
                        <Select onValueChange={setSelectedSucursalId} value={selectedSucursalId} disabled={loadingBranches}>
                            <SelectTrigger id="sucursal-selector">
                                <SelectValue placeholder={loadingBranches ? 'Cargando...' : 'Seleccione una sucursal'} />
                            </SelectTrigger>
                            <SelectContent>
                                {availableBranches.map(branch => (
                                    <SelectItem key={branch.id} value={branch.id.toString()}>{branch.nombre}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </CardContent>
                </Card>
            )}

            {!selectedSucursalId ? (
                <div className="text-center py-10 text-muted-foreground">
                    {loadingBranches ? <Loader2 className="mx-auto h-8 w-8 animate-spin" /> : 'Seleccione una sucursal para comenzar.'}
                </div>
            ) : (
                <AnimatePresence>
                    <div className="space-y-6">
                        {sections.map((section, index) => (
                            <motion.div
                                key={`${section.id}-${selectedSucursalId}`}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0, transition: { delay: index * 0.1 } }}
                            >
                                <Card>
                                    <CardHeader>
                                        <CardTitle className="flex items-center gap-2">
                                            <section.icon className="h-6 w-6 text-primary" />
                                            {section.title}
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <section.component 
                                          sucursalId={selectedSucursalId} 
                                          key={`${refreshKey}-${selectedSucursalId}`} 
                                          onActionComplete={handleRefresh}
                                        />
                                    </CardContent>
                                </Card>
                            </motion.div>
                        ))}
                    </div>
                </AnimatePresence>
            )}
        </div>
    );
};

export default ManagementPage;