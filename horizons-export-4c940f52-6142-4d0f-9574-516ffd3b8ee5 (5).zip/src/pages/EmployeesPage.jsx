import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/hooks/useAuth';
import { useBranch } from '@/contexts/BranchContext';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { PlusCircle, Trash2, Edit, Save, X, Loader2, UserPlus, Filter } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const EmployeesPage = () => {
    const { userRole, userProfile } = useAuth();
    const { availableBranches, loadingBranches } = useBranch();
    const { toast } = useToast();

    const [employees, setEmployees] = useState([]);
    const [loading, setLoading] = useState(false);
    const [editingId, setEditingId] = useState(null);
    const [editingData, setEditingData] = useState({});
    const [newEmployeeData, setNewEmployeeData] = useState({
        nombre_completo: '',
        puesto: '',
        tipo_pago: 'Fijo',
        monto: '',
        sucursal_id: ''
    });
    const [isNewEmployeeDialogOpen, setIsNewEmployeeDialogOpen] = useState(false);
    const [selectedBranchFilter, setSelectedBranchFilter] = useState('all');

    const fetchEmployees = useCallback(async () => {
        setLoading(true);
        let query = supabase.from('empleados').select('*, sucursales(nombre)');

        if (userRole === 'gerente' && userProfile?.sucursal_id) {
            query = query.eq('sucursal_id', userProfile.sucursal_id);
        } else if (userRole === 'admin' && selectedBranchFilter !== 'all') {
            query = query.eq('sucursal_id', selectedBranchFilter);
        }
        
        query = query.order('nombre_completo', { ascending: true });

        const { data, error } = await query;
        if (error) {
            toast({ variant: 'destructive', title: 'Error', description: 'No se pudieron cargar los empleados.' });
        } else {
            setEmployees(data);
        }
        setLoading(false);
    }, [userRole, userProfile, selectedBranchFilter, toast]);

    useEffect(() => {
        if (!loadingBranches) {
           fetchEmployees();
           if(userRole === 'gerente' && userProfile?.sucursal_id) {
             setNewEmployeeData(prev => ({...prev, sucursal_id: userProfile.sucursal_id}));
           }
        }
    }, [fetchEmployees, loadingBranches, userRole, userProfile]);

    const handleEdit = (employee) => {
        setEditingId(employee.id);
        setEditingData(employee);
    };

    const handleCancelEdit = () => {
        setEditingId(null);
        setEditingData({});
    };

    const handleSave = async () => {
        const { sucursales, ...updateData } = editingData;
        const { error } = await supabase.from('empleados').update(updateData).eq('id', editingId);
        if (error) {
            toast({ variant: 'destructive', title: 'Error al guardar', description: error.message });
        } else {
            toast({ title: 'Éxito', description: 'Empleado actualizado correctamente.' });
            setEditingId(null);
            fetchEmployees();
        }
    };
    
    const handleDelete = async (id) => {
        const { error } = await supabase.from('empleados').delete().eq('id', id);
        if (error) {
            toast({ variant: 'destructive', title: 'Error al eliminar', description: error.message });
        } else {
            toast({ title: 'Éxito', description: 'Empleado eliminado.' });
            fetchEmployees();
        }
    };
    
    const handleAddNewEmployee = async () => {
        if (!newEmployeeData.nombre_completo || !newEmployeeData.monto || !newEmployeeData.sucursal_id) {
            toast({ variant: "destructive", title: "Campos requeridos", description: "Nombre, monto y sucursal son obligatorios." });
            return;
        }

        const { error } = await supabase.from('empleados').insert(newEmployeeData);
        if (error) {
            toast({ variant: "destructive", title: "Error al agregar", description: error.message });
        } else {
            toast({ title: "Éxito", description: "Nuevo empleado agregado." });
            setIsNewEmployeeDialogOpen(false);
            setNewEmployeeData({ nombre_completo: '', puesto: '', tipo_pago: 'Fijo', monto: '', sucursal_id: userRole === 'gerente' ? userProfile.sucursal_id : '' });
            fetchEmployees();
        }
    };

    return (
        <div className="container mx-auto p-4 md:p-8">
            <Helmet>
                <title>Gestión de Empleados - MarvelMaster</title>
                <meta name="description" content="Administre el personal de todas las sucursales." />
            </Helmet>

            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
                <div className="flex-1">
                    <h1 className="text-3xl font-bold text-primary">Gestión de Empleados</h1>
                    <p className="text-muted-foreground">Agregue, edite y gestione el personal.</p>
                </div>
                 <Dialog open={isNewEmployeeDialogOpen} onOpenChange={setIsNewEmployeeDialogOpen}>
                    <DialogTrigger asChild>
                        <Button><UserPlus className="mr-2 h-4 w-4" /> Agregar Empleado</Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Agregar Nuevo Empleado</DialogTitle>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                            <div className="grid grid-cols-4 items-center gap-4">
                                <Label htmlFor="nombre" className="text-right">Nombre</Label>
                                <Input id="nombre" value={newEmployeeData.nombre_completo} onChange={(e) => setNewEmployeeData({...newEmployeeData, nombre_completo: e.target.value})} className="col-span-3" />
                            </div>
                            <div className="grid grid-cols-4 items-center gap-4">
                                <Label htmlFor="puesto" className="text-right">Puesto</Label>
                                <Input id="puesto" value={newEmployeeData.puesto} onChange={(e) => setNewEmployeeData({...newEmployeeData, puesto: e.target.value})} className="col-span-3" />
                            </div>
                            <div className="grid grid-cols-4 items-center gap-4">
                                <Label htmlFor="tipo_pago" className="text-right">Tipo Pago</Label>
                                <Select value={newEmployeeData.tipo_pago} onValueChange={(v) => setNewEmployeeData({...newEmployeeData, tipo_pago: v})}>
                                    <SelectTrigger className="col-span-3"><SelectValue /></SelectTrigger>
                                    <SelectContent><SelectItem value="Fijo">Fijo</SelectItem><SelectItem value="Por hora">Por hora</SelectItem></SelectContent>
                                </Select>
                            </div>
                             <div className="grid grid-cols-4 items-center gap-4">
                                <Label htmlFor="monto" className="text-right">Monto</Label>
                                <Input id="monto" type="number" value={newEmployeeData.monto} onChange={(e) => setNewEmployeeData({...newEmployeeData, monto: e.target.value})} className="col-span-3" />
                            </div>
                            {userRole === 'admin' && (
                                <div className="grid grid-cols-4 items-center gap-4">
                                    <Label htmlFor="sucursal" className="text-right">Sucursal</Label>
                                    <Select value={newEmployeeData.sucursal_id} onValueChange={(v) => setNewEmployeeData({...newEmployeeData, sucursal_id: v})}>
                                        <SelectTrigger className="col-span-3"><SelectValue placeholder="Seleccionar..." /></SelectTrigger>
                                        <SelectContent>{availableBranches.map(b => <SelectItem key={b.id} value={b.id.toString()}>{b.nombre}</SelectItem>)}</SelectContent>
                                    </Select>
                                </div>
                            )}
                        </div>
                        <DialogFooter>
                            <Button onClick={handleAddNewEmployee}>Guardar Empleado</Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>
            
            <Card>
                <CardHeader>
                    {userRole === 'admin' && (
                         <div className="flex items-center gap-2 max-w-sm">
                             <Filter className="h-4 w-4 text-muted-foreground" />
                             <Select value={selectedBranchFilter} onValueChange={setSelectedBranchFilter}>
                                 <SelectTrigger><SelectValue/></SelectTrigger>
                                 <SelectContent>
                                     <SelectItem value="all">Todas las sucursales</SelectItem>
                                     {availableBranches.map(b => <SelectItem key={b.id} value={b.id.toString()}>{b.nombre}</SelectItem>)}
                                 </SelectContent>
                             </Select>
                         </div>
                    )}
                </CardHeader>
                <CardContent>
                    <div className="overflow-x-auto">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Nombre Completo</TableHead>
                                    <TableHead>Puesto</TableHead>
                                    <TableHead>Sucursal</TableHead>
                                    <TableHead>Tipo de Pago</TableHead>
                                    <TableHead>Monto</TableHead>
                                    <TableHead className="text-right">Acciones</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {loading ? (
                                    <TableRow><TableCell colSpan={6} className="text-center"><Loader2 className="mx-auto h-8 w-8 animate-spin" /></TableCell></TableRow>
                                ) : employees.length > 0 ? employees.map((emp) => (
                                    editingId === emp.id ? (
                                        <TableRow key={emp.id} className="bg-muted/50">
                                            <TableCell><Input value={editingData.nombre_completo} onChange={(e) => setEditingData({...editingData, nombre_completo: e.target.value})} /></TableCell>
                                            <TableCell><Input value={editingData.puesto} onChange={(e) => setEditingData({...editingData, puesto: e.target.value})} /></TableCell>
                                            <TableCell>{emp.sucursales.nombre}</TableCell>
                                            <TableCell>
                                                <Select value={editingData.tipo_pago} onValueChange={(v) => setEditingData({...editingData, tipo_pago: v})}>
                                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                                    <SelectContent><SelectItem value="Fijo">Fijo</SelectItem><SelectItem value="Por hora">Por hora</SelectItem></SelectContent>
                                                </Select>
                                            </TableCell>
                                            <TableCell><Input type="number" value={editingData.monto} onChange={(e) => setEditingData({...editingData, monto: e.target.value})} /></TableCell>
                                            <TableCell className="text-right space-x-2">
                                                <Button size="icon" variant="ghost" onClick={handleSave}><Save className="h-4 w-4 text-green-500" /></Button>
                                                <Button size="icon" variant="ghost" onClick={handleCancelEdit}><X className="h-4 w-4 text-red-500" /></Button>
                                            </TableCell>
                                        </TableRow>
                                    ) : (
                                        <TableRow key={emp.id}>
                                            <TableCell>{emp.nombre_completo}</TableCell>
                                            <TableCell>{emp.puesto}</TableCell>
                                            <TableCell>{emp.sucursales?.nombre || 'N/A'}</TableCell>
                                            <TableCell>{emp.tipo_pago}</TableCell>
                                            <TableCell>${parseFloat(emp.monto).toLocaleString('es-AR')}</TableCell>
                                            <TableCell className="text-right space-x-2">
                                                <Button size="icon" variant="ghost" onClick={() => handleEdit(emp)}><Edit className="h-4 w-4" /></Button>
                                                <AlertDialog>
                                                    <AlertDialogTrigger asChild><Button size="icon" variant="ghost"><Trash2 className="h-4 w-4 text-destructive" /></Button></AlertDialogTrigger>
                                                    <AlertDialogContent>
                                                        <AlertDialogHeader>
                                                            <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
                                                            <AlertDialogDescription>Esta acción no se puede deshacer. Esto eliminará permanentemente al empleado.</AlertDialogDescription>
                                                        </AlertDialogHeader>
                                                        <AlertDialogFooter>
                                                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                                            <AlertDialogAction onClick={() => handleDelete(emp.id)} className="bg-destructive hover:bg-destructive/90">Eliminar</AlertDialogAction>
                                                        </AlertDialogFooter>
                                                    </AlertDialogContent>
                                                </AlertDialog>
                                            </TableCell>
                                        </TableRow>
                                    )
                                )) : (
                                    <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground">No se encontraron empleados.</TableCell></TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
};

export default EmployeesPage;