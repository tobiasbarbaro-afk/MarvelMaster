import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/components/ui/use-toast';
import { Eye, EyeOff, LogIn, UserPlus } from 'lucide-react';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);
  const navigate = useNavigate();
  const { login, signUp } = useAuth();
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    if (isSignUp) {
      const { data, error } = await signUp(email, password, { username: email.split('@')[0] });
      if (error) {
        toast({
          variant: "destructive",
          title: "Error al registrar",
          description: error.message || "No se pudo crear la cuenta. Intenta de nuevo.",
        });
      } else if (data.user) {
         if (data.user.identities && data.user.identities.length === 0) {
           toast({
            variant: "destructive",
            title: "Error de Registro",
            description: "Este correo electrónico ya está en uso o hubo un problema con el registro.",
          });
         } else {
            toast({
              title: "Registro Exitoso",
              description: "Cuenta creada. Por favor, revisa tu email para confirmar.",
            });
            setIsSignUp(false);
         }
      } else {
        toast({
          variant: "destructive",
          title: "Error de Registro",
          description: "Ocurrió un error inesperado durante el registro.",
        });
      }
    } else {
      const { error } = await login(email, password);
      if (error) {
        toast({
          variant: "destructive",
          title: "Error de autenticación",
          description: error.message || "Email o contraseña incorrectos.",
        });
      } else {
        toast({
          title: "Inicio de sesión exitoso",
          description: `Bienvenido de nuevo!`,
        });
        navigate('/');
      }
    }
    setIsLoading(false);
  };

  const toggleFormMode = () => {
    setIsSignUp(!isSignUp);
    setEmail('');
    setPassword('');
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-yellow-300 via-amber-400 to-orange-500 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="w-full max-w-md"
      >
        <Card className="w-full shadow-2xl bg-white border-gray-200">
          <CardHeader className="text-center pt-8 pb-4">
            <div className="flex justify-center mb-6">
              <img alt="MarvelMaster Logo" className="h-28 w-auto" src="https://storage.googleapis.com/hostinger-horizons-assets-prod/4c940f52-6142-4d0f-9574-516ffd3b8ee5/1ea58ebb48c6afb8a4d88f94a4bdf813.png" />
            </div>
            <CardTitle className="text-3xl font-bold text-slate-800">
              {isSignUp ? 'Crear Cuenta' : 'MarvelMaster Gestión'}
            </CardTitle>
            <CardDescription className="text-slate-600">
              {isSignUp ? 'Completa tus datos para registrarte.' : 'Acceso exclusivo para empleados'}
            </CardDescription>
          </CardHeader>
          <CardContent className="px-6 py-4">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-slate-700 font-medium">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="tu@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="bg-slate-50 border-slate-300 focus:border-yellow-500 focus:ring-yellow-500 text-slate-900 placeholder-slate-400"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="text-slate-700 font-medium">Contraseña</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="bg-slate-50 border-slate-300 focus:border-yellow-500 focus:ring-yellow-500 text-slate-900 placeholder-slate-400"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute inset-y-0 right-0 h-full text-slate-500 hover:text-yellow-600"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </Button>
                </div>
              </div>
              <Button type="submit" className="w-full bg-yellow-500 text-black hover:bg-yellow-600 text-lg py-3 font-semibold" disabled={isLoading}>
                {isLoading ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    className="w-5 h-5 border-2 border-black border-t-transparent rounded-full mr-2"
                  />
                ) : (
                  isSignUp ? <UserPlus className="w-5 h-5 mr-2" /> : <LogIn className="w-5 h-5 mr-2" />
                )}
                {isLoading ? (isSignUp ? 'Registrando...' : 'Ingresando...') : (isSignUp ? 'Registrarme' : 'Ingresar')}
              </Button>
            </form>
          </CardContent>
          <CardFooter className="flex flex-col items-center space-y-3 pt-4 pb-6">
            <Button variant="link" onClick={toggleFormMode} className="text-yellow-600 hover:text-yellow-700 font-medium">
              {isSignUp ? '¿Ya tienes cuenta? Inicia Sesión' : '¿No tienes cuenta? Regístrate'}
            </Button>
            <p className="text-xs text-slate-500">&copy; {new Date().getFullYear()} MarvelMaster. Todos los derechos reservados.</p>
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  );
};

export default LoginPage;