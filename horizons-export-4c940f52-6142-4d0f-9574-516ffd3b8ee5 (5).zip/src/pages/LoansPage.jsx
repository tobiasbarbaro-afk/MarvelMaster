import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/hooks/useAuth';
import { useBranch } from '@/contexts/BranchContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Loader2, DollarSign } from 'lucide-react';
import { format } from 'date-fns';
import LoanFormDialog from '@/components/loans/LoanFormDialog';
import LoanDetailsDialog from '@/components/loans/LoanDetailsDialog';

const LoansPage = () => {
    const { userRole, userProfile } = useAuth();
    const { availableBranches } = useBranch();
    const { toast } = useToast();

    const [loans, setLoans] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedBranchId, setSelectedBranchId] = useState('');
    const [filterEmployeeId, setFilterEmployeeId] = useState('all');

    useEffect(() => {
        if (userRole === 'gerente' && userProfile?.sucursal_id) {
            setSelectedBranchId(userProfile.sucursal_id.toString());
        } else if (userRole === 'admin' && availableBranches.length > 0 && !selectedBranchId) {
            setSelectedBranchId(availableBranches[0].id.toString());
        }
    }, [userProfile, userRole, availableBranches]);

    const fetchLoans = useCallback(async () => {
        if (!selectedBranchId) return;
        setLoading(true);
        try {
            const { data, error } = await supabase
                .from('prestamos_empleados')
                .select(`
                    *,
                    empleados (id, nombre_completo),
                    sucursales (id, nombre)
                `)
                .eq('sucursal_id', selectedBranchId)
                .order('fecha_creacion', { ascending: false });

            if (error) throw error;
            setLoans(data || []);
        } catch (error) {
            console.error("Error fetching loans:", error);
            toast({ variant: 'destructive', title: 'Error', description: 'No se pudieron cargar los préstamos.' });
        } finally {
            setLoading(false);
        }
    }, [selectedBranchId, toast]);

    useEffect(() => {
        fetchLoans();
    }, [fetchLoans]);

    if (!['admin', 'gerente'].includes(userRole)) {
        return (
            <div className="flex items-center justify-center h-full">
                <p className="text-xl text-muted-foreground">No tienes acceso a esta sección.</p>
            </div>
        );
    }

    const uniqueEmployees = Array.from(new Set(loans.map(l => l.empleado_id)))
        .map(id => loans.find(l => l.empleado_id === id)?.empleados)
        .filter(Boolean);

    const filteredLoans = filterEmployeeId === 'all' 
        ? loans 
        : loans.filter(l => l.empleado_id === filterEmployeeId);

    return (
        <div className="container mx-auto p-4 md:p-8">
            <Helmet>
                <title>Préstamos - MarvelMaster</title>
            </Helmet>
            
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h1 className="text-3xl font-bold text-primary flex items-center">
                        <DollarSign className="mr-2 h-8 w-8" /> Gestión de Préstamos
                    </h1>
                    <p className="text-muted-foreground">Administre los préstamos de los empleados.</p>
                </div>
                <LoanFormDialog branchId={selectedBranchId} onLoanCreated={fetchLoans} />
            </div>

            <Card className="mb-6">
                <CardHeader className="pb-4">
                    <CardTitle className="text-lg">Filtros</CardTitle>
                </CardHeader>
                <CardContent className="flex flex-col sm:flex-row gap-4">
                    {userRole === 'admin' && (
                        <div className="flex-1">
                            <Label>Sucursal</Label>
                            <Select value={selectedBranchId} onValueChange={(val) => { setSelectedBranchId(val); setFilterEmployeeId('all'); }}>
                                <SelectTrigger>
                                    <SelectValue placeholder="Seleccione Sucursal" />
                                </SelectTrigger>
                                <SelectContent>
                                    {availableBranches.map(b => (
                                        <SelectItem key={b.id} value={b.id.toString()}>{b.nombre}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                    )}
                    <div className="flex-1">
                        <Label>Empleado</Label>
                        <Select value={filterEmployeeId} onValueChange={setFilterEmployeeId}>
                            <SelectTrigger>
                                <SelectValue placeholder="Todos los empleados" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">Todos los empleados</SelectItem>
                                {uniqueEmployees.map(emp => (
                                    <SelectItem key={emp.id} value={emp.id}>{emp.nombre_completo}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Préstamos Activos e Históricos</CardTitle>
                </CardHeader>
                <CardContent>
                    {loading ? (
                        <div className="flex justify-center p-8"><Loader2 className="animate-spin h-8 w-8 text-primary" /></div>
                    ) : filteredLoans.length === 0 ? (
                        <div className="text-center p-8 text-muted-foreground">
                            No se encontraron préstamos para los filtros seleccionados.
                        </div>
                    ) : (
                        <div className="overflow-x-auto">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Empleado</TableHead>
                                        <TableHead>Monto Total</TableHead>
                                        <TableHead>Saldo Actual</TableHead>
                                        <TableHead>Tipo</TableHead>
                                        <TableHead>Fecha</TableHead>
                                        <TableHead>Estado</TableHead>
                                        <TableHead className="text-right">Acciones</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {filteredLoans.map((loan) => (
                                        <TableRow key={loan.id}>
                                            <TableCell className="font-medium">{loan.empleados?.nombre_completo}</TableCell>
                                            <TableCell>${parseFloat(loan.monto_total).toLocaleString('es-AR', {minimumFractionDigits: 2})}</TableCell>
                                            <TableCell className="font-bold">
                                                ${parseFloat(loan.saldo_actual).toLocaleString('es-AR', {minimumFractionDigits: 2})}
                                            </TableCell>
                                            <TableCell className="capitalize">{loan.tipo}</TableCell>
                                            <TableCell>{format(new Date(loan.fecha_creacion), 'dd/MM/yyyy')}</TableCell>
                                            <TableCell>
                                                {parseFloat(loan.saldo_actual) > 0 ? (
                                                    <Badge variant="outline" className="bg-orange-100 text-orange-800 border-orange-300">Activo</Badge>
                                                ) : (
                                                    <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">Saldado</Badge>
                                                )}
                                            </TableCell>
                                            <TableCell className="text-right">
                                                <LoanDetailsDialog loan={loan} />
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
};

export default LoansPage;