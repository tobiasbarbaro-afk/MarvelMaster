import React, { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import WelcomeHeader from '@/components/dashboard/WelcomeHeader';
import PaymentRegistrationForm from '@/components/payments/PaymentRegistrationForm';
import PaymentHistoryDialog from '@/components/payments/PaymentHistoryDialog';
import { Button } from '@/components/ui/button';
import { History } from 'lucide-react';

const PaymentsPage = () => {
  const { userRole } = useAuth();
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);

  if (userRole !== 'admin') {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-8">
        <h2 className="text-2xl font-bold text-destructive mb-2">Acceso Denegado</h2>
        <p className="text-muted-foreground">No tienes permisos para ver esta página.</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <WelcomeHeader title="Gestión de Pagos a Proveedores" />
        <Button 
          variant="outline" 
          onClick={() => setIsHistoryOpen(true)}
          className="w-full md:w-auto"
        >
          <History className="mr-2 h-4 w-4" />
          Ver Historial de Pagos
        </Button>
      </div>

      <div className="mt-8">
        <PaymentRegistrationForm />
      </div>

      <PaymentHistoryDialog 
        isOpen={isHistoryOpen} 
        onClose={() => setIsHistoryOpen(false)} 
      />
    </div>
  );
};

export default PaymentsPage;