import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';

const UsersPage = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
        <Helmet>
            <title>Usuarios - MarvelMaster</title>
            <meta name="description" content="Página de gestión de usuarios obsoleta." />
        </Helmet>
        <div className="text-center py-20">
            <h1 className="text-4xl font-bold text-destructive mb-4">Página Obsoleta</h1>
            <p className="text-lg text-muted-foreground">La gestión de usuarios ha sido reemplazada por la nueva sección de "Empleados".</p>
        </div>
    </motion.div>
  );
};

export default UsersPage;