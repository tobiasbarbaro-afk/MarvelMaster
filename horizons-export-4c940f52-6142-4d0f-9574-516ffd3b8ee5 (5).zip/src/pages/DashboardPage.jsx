import React from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/hooks/useAuth';
import WelcomeHeader from '@/components/dashboard/WelcomeHeader';
import QuickAccess from '@/components/dashboard/QuickAccess';
import WeeklyInvoiceSummary from '@/components/dashboard/WeeklyInvoiceSummary';
import { Archive, BarChart, FileText } from 'lucide-react';
import { Link } from 'react-router-dom';
const DashboardPage = () => {
  const {
    userRole,
    userProfile
  } = useAuth();
  const isManager = userRole === 'gerente';
  if (!userProfile) {
    return <div className="flex justify-center items-center h-screen">Cargando...</div>;
  }
  if (!isManager) {
    return <div className="container mx-auto p-4 text-center">
                 <WelcomeHeader />
                 <p className="text-lg mt-4">Seleccioná la sección deseada</p>
             </div>;
  }
  return <div className="container mx-auto p-4">
          <Helmet>
            <title>Panel Principal - MarvelMaster</title>
            <meta name="description" content="Panel de control para la gestión de sucursales." />
          </Helmet>
          
          <WelcomeHeader />
          
          <QuickAccess />

          <div>
              <h2 className="text-xl font-semibold mb-3">Tablero de Control del Gerente</h2>
              <p className="text-muted-foreground mb-4 text-sm">Resumen de facturación semanal de proveedores.</p>
              <div className="mt-6">
                <WeeklyInvoiceSummary />
              </div>
          </div>
        </div>;
};
export default DashboardPage;