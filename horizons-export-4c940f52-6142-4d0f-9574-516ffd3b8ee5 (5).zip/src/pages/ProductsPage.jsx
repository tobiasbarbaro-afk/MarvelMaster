import React, { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Plus, Edit, Trash2, ChevronLeft, ChevronRight, Package, Box, Filter, DollarSign } from 'lucide-react';
import { motion } from 'framer-motion';

const ProductsPage = () => {
  const { toast } = useToast();
  const [currentTab, setCurrentTab] = useState('productos');
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Filtering state
  const [selectedRubro, setSelectedRubro] = useState('all');
  const [rubros, setRubros] = useState([]);
  
  // Available rubros for select
  const [availableProductosRubros, setAvailableProductosRubros] = useState([]);
  const [availableInsumosRubros, setAvailableInsumosRubros] = useState([]);

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  
  // Modals state
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [formData, setFormData] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formErrors, setFormErrors] = useState({});

  const fetchAvailableRubros = async () => {
    try {
      // Fetch productos rubros
      const { data: productosData, error: productosError } = await supabase
        .from('productos_centralizada')
        .select('Rubro')
        .not('Rubro', 'is', null);

      if (productosError) throw productosError;

      const uniqueProductosRubros = [...new Set(productosData.map(item => item.Rubro).filter(Boolean))].sort();
      setAvailableProductosRubros(uniqueProductosRubros);

      // Fetch insumos rubros
      const { data: insumosData, error: insumosError } = await supabase
        .from('insumos_centralizada')
        .select('rubro')
        .not('rubro', 'is', null);

      if (insumosError) throw insumosError;

      const uniqueInsumosRubros = [...new Set(insumosData.map(item => item.rubro).filter(Boolean))].sort();
      setAvailableInsumosRubros(uniqueInsumosRubros);

    } catch (error) {
      console.error('Error fetching available rubros:', error);
    }
  };

  const fetchTableData = async (tab) => {
    setLoading(true);
    try {
      const tableName = tab === 'productos' ? 'productos_centralizada' : 'insumos_centralizada';
      const { data: result, error } = await supabase
        .from(tableName)
        .select('*')
        .order(tab === 'productos' ? 'creado_en' : 'creado_el', { ascending: false });

      if (error) throw error;
      
      const fetchedData = result || [];
      setData(fetchedData);
      
      // Extract unique rubros for the current tab
      const rubroField = tab === 'productos' ? 'Rubro' : 'rubro';
      const uniqueRubros = [...new Set(fetchedData.map(item => item[rubroField]).filter(Boolean))].sort();
      setRubros(uniqueRubros);
      
      setCurrentPage(1);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast({
        variant: 'destructive',
        title: 'Error de carga',
        description: 'No se pudieron obtener los registros.',
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAvailableRubros();
  }, []);

  useEffect(() => {
    fetchTableData(currentTab);
  }, [currentTab]);

  useEffect(() => {
    setCurrentPage(1);
  }, [selectedRubro]);

  const handleTabChange = (value) => {
    setCurrentTab(value);
    setSelectedRubro('all');
  };

  const filteredData = useMemo(() => {
    if (selectedRubro === 'all') return data;
    const rubroField = currentTab === 'productos' ? 'Rubro' : 'rubro';
    return data.filter(item => item[rubroField] === selectedRubro);
  }, [data, selectedRubro, currentTab]);

  const paginatedData = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredData.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredData, currentPage]);

  const totalPages = Math.ceil(filteredData.length / itemsPerPage);

  const openAddModal = () => {
    setSelectedItem(null);
    setFormData(currentTab === 'productos' 
      ? { nombre: '', unidad_medida: '', Rubro: '', unidad_medida_stock: '', precio: '' }
      : { producto: '', unidad_medida: '', rubro: '', precio: '' }
    );
    setFormErrors({});
    setIsFormOpen(true);
  };

  const openEditModal = (item) => {
    setSelectedItem(item);
    setFormData({ ...item });
    setFormErrors({});
    setIsFormOpen(true);
  };

  const openDeleteModal = (item) => {
    setSelectedItem(item);
    setIsDeleteOpen(true);
  };

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    // Clear error for this field when user types
    if (formErrors[name]) {
      setFormErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const handleRubroChange = (value) => {
    const fieldName = currentTab === 'productos' ? 'Rubro' : 'rubro';
    setFormData(prev => ({ ...prev, [fieldName]: value }));
    if (formErrors[fieldName]) {
      setFormErrors(prev => ({ ...prev, [fieldName]: undefined }));
    }
  };

  const validateForm = () => {
    const errors = {};
    
    if (currentTab === 'productos') {
      if (!formData.nombre?.trim()) {
        errors.nombre = 'El nombre es requerido';
      }
      if (!formData.unidad_medida?.trim()) {
        errors.unidad_medida = 'La unidad de medida es requerida';
      }
    } else {
      if (!formData.producto?.trim()) {
        errors.producto = 'El producto es requerido';
      }
      if (!formData.unidad_medida?.trim()) {
        errors.unidad_medida = 'La unidad de medida es requerida';
      }
    }

    // Validate precio - NOW REQUIRED
    if (formData.precio === '' || formData.precio === null || formData.precio === undefined) {
      errors.precio = 'El precio es obligatorio';
    } else {
      const parsedPrecio = parseFloat(formData.precio);
      if (isNaN(parsedPrecio) || parsedPrecio < 0) {
        errors.precio = 'El precio debe ser un número mayor o igual a 0';
      }
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSave = async () => {
    if (!validateForm()) {
      toast({
        variant: 'destructive',
        title: 'Error de validación',
        description: 'Por favor, completa todos los campos requeridos correctamente.',
      });
      return;
    }

    setIsSubmitting(true);
    const tableName = currentTab === 'productos' ? 'productos_centralizada' : 'insumos_centralizada';
    
    try {
      let submitData = { ...formData };
      
      // Convert precio to number
      submitData.precio = parseFloat(submitData.precio);

      if (selectedItem) {
        // Edit
        const { id, creado_en, creado_el, ...updateData } = submitData; 
        const { error } = await supabase
          .from(tableName)
          .update(updateData)
          .eq('id', selectedItem.id);
        
        if (error) throw error;
        toast({ title: 'Actualizado', description: 'El registro se actualizó correctamente.' });
      } else {
        // Create
        if (currentTab === 'productos') {
            submitData.creado_en = new Date().toISOString();
        } else {
            submitData.creado_el = new Date().toISOString();
        }
        
        const { error } = await supabase
          .from(tableName)
          .insert([submitData]);
        
        if (error) throw error;
        toast({ title: 'Creado', description: 'El nuevo registro ha sido creado.' });
      }
      
      setIsFormOpen(false);
      fetchTableData(currentTab);
      fetchAvailableRubros(); // Refresh rubros list
    } catch (error) {
      console.error('Error saving data:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error.message || 'Hubo un problema al guardar el registro.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    setIsSubmitting(true);
    const tableName = currentTab === 'productos' ? 'productos_centralizada' : 'insumos_centralizada';
    
    try {
      const { error } = await supabase
        .from(tableName)
        .delete()
        .eq('id', selectedItem.id);
        
      if (error) throw error;
      
      toast({ title: 'Eliminado', description: 'El registro ha sido eliminado correctamente.' });
      setIsDeleteOpen(false);
      fetchTableData(currentTab);
    } catch (error) {
      console.error('Error deleting data:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Hubo un problema al eliminar el registro. Puede que esté en uso.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatPrice = (price) => {
    if (price === null || price === undefined) return '$0.00';
    return new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS' }).format(price);
  };

  const currentRubrosForSelect = currentTab === 'productos' ? availableProductosRubros : availableInsumosRubros;
  const rubroFieldName = currentTab === 'productos' ? 'Rubro' : 'rubro';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Gestión de Productos e Insumos</h1>
          <p className="text-muted-foreground mt-1">Administra la base de datos de productos e insumos centralizados.</p>
        </div>
        <Button onClick={openAddModal} className="flex items-center gap-2">
          <Plus className="h-4 w-4" /> Agregar Nuevo
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <Tabs value={currentTab} onValueChange={handleTabChange} className="w-full sm:w-auto">
          <TabsList className="grid w-full sm:w-[400px] grid-cols-2">
            <TabsTrigger value="productos" className="flex items-center gap-2">
              <Package className="h-4 w-4" /> Productos
            </TabsTrigger>
            <TabsTrigger value="insumos" className="flex items-center gap-2">
              <Box className="h-4 w-4" /> Insumos
            </TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="w-full sm:w-[250px]">
          <Select value={selectedRubro} onValueChange={setSelectedRubro}>
            <SelectTrigger className="w-full">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <SelectValue placeholder="Todos los rubros" />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los rubros</SelectItem>
              {rubros.map((rubro) => (
                <SelectItem key={rubro} value={rubro}>
                  {rubro}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="capitalize text-xl flex items-center justify-between">
            <span>{currentTab}</span>
            {selectedRubro !== 'all' && (
              <span className="text-sm font-normal text-muted-foreground">
                Filtrado por: <span className="font-semibold text-foreground">{selectedRubro}</span> ({filteredData.length})
              </span>
            )}
          </CardTitle>
          <CardDescription>
            Listado de {currentTab} disponibles en el sistema.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center items-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : filteredData.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              No se encontraron registros. {selectedRubro !== 'all' ? "Prueba cambiando el filtro de rubro." : "Haz clic en 'Agregar Nuevo' para comenzar."}
            </div>
          ) : (
            <div className="space-y-4">
              <div className="rounded-md border overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      {currentTab === 'productos' ? (
                        <>
                          <TableHead>Nombre</TableHead>
                          <TableHead>Unid. Medida</TableHead>
                          <TableHead>Rubro</TableHead>
                          <TableHead>Unid. Medida Stock</TableHead>
                          <TableHead>Precio</TableHead>
                          <TableHead>Creado En</TableHead>
                        </>
                      ) : (
                        <>
                          <TableHead>Producto</TableHead>
                          <TableHead>Unid. Medida</TableHead>
                          <TableHead>Rubro</TableHead>
                          <TableHead>Precio</TableHead>
                          <TableHead>Creado El</TableHead>
                        </>
                      )}
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedData.map((item) => (
                      <TableRow key={item.id}>
                        {currentTab === 'productos' ? (
                          <>
                            <TableCell className="font-medium">{item.nombre}</TableCell>
                            <TableCell>{item.unidad_medida}</TableCell>
                            <TableCell>{item.Rubro}</TableCell>
                            <TableCell>{item.unidad_medida_stock}</TableCell>
                            <TableCell className="font-medium text-emerald-600 dark:text-emerald-400">{formatPrice(item.precio)}</TableCell>
                            <TableCell>{new Date(item.creado_en).toLocaleDateString()}</TableCell>
                          </>
                        ) : (
                          <>
                            <TableCell className="font-medium">{item.producto}</TableCell>
                            <TableCell>{item.unidad_medida}</TableCell>
                            <TableCell>{item.rubro}</TableCell>
                            <TableCell className="font-medium text-emerald-600 dark:text-emerald-400">{formatPrice(item.precio)}</TableCell>
                            <TableCell>{new Date(item.creado_el).toLocaleDateString()}</TableCell>
                          </>
                        )}
                        <TableCell className="text-right space-x-2">
                          <Button variant="ghost" size="icon" onClick={() => openEditModal(item)} title="Editar">
                            <Edit className="h-4 w-4 text-blue-500" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => openDeleteModal(item)} title="Eliminar">
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Pagination Controls */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between">
                  <div className="text-sm text-muted-foreground">
                    Mostrando {(currentPage - 1) * itemsPerPage + 1} a {Math.min(currentPage * itemsPerPage, filteredData.length)} de {filteredData.length} registros
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                      disabled={currentPage === 1}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <span className="text-sm font-medium">
                      Página {currentPage} de {totalPages}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                      disabled={currentPage === totalPages}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add/Edit Modal */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{selectedItem ? 'Editar' : 'Agregar'} {currentTab === 'productos' ? 'Producto' : 'Insumo'}</DialogTitle>
            <DialogDescription>
              Completa los campos a continuación para guardar el registro. Los campos marcados con <span className="text-red-500">*</span> son obligatorios.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4">
            {/* Columna Izquierda */}
            <div className="space-y-4">
              {currentTab === 'productos' ? (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="nombre">Nombre <span className="text-red-500">*</span></Label>
                    <Input 
                      id="nombre" 
                      name="nombre" 
                      value={formData.nombre || ''} 
                      onChange={handleFormChange} 
                      className={formErrors.nombre ? 'border-red-500' : ''}
                    />
                    {formErrors.nombre && (
                      <p className="text-sm text-red-500">{formErrors.nombre}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="unidad_medida">Unidad de Medida <span className="text-red-500">*</span></Label>
                    <Input 
                      id="unidad_medida" 
                      name="unidad_medida" 
                      value={formData.unidad_medida || ''} 
                      onChange={handleFormChange}
                      className={formErrors.unidad_medida ? 'border-red-500' : ''}
                    />
                    {formErrors.unidad_medida && (
                      <p className="text-sm text-red-500">{formErrors.unidad_medida}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="Rubro">Rubro</Label>
                    <Select
                      value={formData.Rubro || ''}
                      onValueChange={handleRubroChange}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Seleccionar rubro..." />
                      </SelectTrigger>
                      <SelectContent>
                        {currentRubrosForSelect.length === 0 ? (
                          <SelectItem value="none" disabled>No hay rubros disponibles</SelectItem>
                        ) : (
                          currentRubrosForSelect.map((rubro) => (
                            <SelectItem key={rubro} value={rubro}>
                              {rubro}
                            </SelectItem>
                          ))
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                </>
              ) : (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="producto">Producto <span className="text-red-500">*</span></Label>
                    <Input 
                      id="producto" 
                      name="producto" 
                      value={formData.producto || ''} 
                      onChange={handleFormChange}
                      className={formErrors.producto ? 'border-red-500' : ''}
                    />
                    {formErrors.producto && (
                      <p className="text-sm text-red-500">{formErrors.producto}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="unidad_medida">Unidad de Medida <span className="text-red-500">*</span></Label>
                    <Input 
                      id="unidad_medida" 
                      name="unidad_medida" 
                      value={formData.unidad_medida || ''} 
                      onChange={handleFormChange}
                      className={formErrors.unidad_medida ? 'border-red-500' : ''}
                    />
                    {formErrors.unidad_medida && (
                      <p className="text-sm text-red-500">{formErrors.unidad_medida}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="rubro">Rubro</Label>
                    <Select
                      value={formData.rubro || ''}
                      onValueChange={handleRubroChange}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Seleccionar rubro..." />
                      </SelectTrigger>
                      <SelectContent>
                        {currentRubrosForSelect.length === 0 ? (
                          <SelectItem value="none" disabled>No hay rubros disponibles</SelectItem>
                        ) : (
                          currentRubrosForSelect.map((rubro) => (
                            <SelectItem key={rubro} value={rubro}>
                              {rubro}
                            </SelectItem>
                          ))
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}
            </div>

            {/* Columna Derecha */}
            <div className="space-y-4">
              {currentTab === 'productos' && (
                <div className="space-y-2">
                  <Label htmlFor="unidad_medida_stock">Unidad Medida (Stock)</Label>
                  <Input id="unidad_medida_stock" name="unidad_medida_stock" value={formData.unidad_medida_stock || ''} onChange={handleFormChange} />
                </div>
              )}
              <div className="space-y-2">
                <Label htmlFor="precio">Precio <span className="text-red-500">*</span></Label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input 
                    id="precio" 
                    name="precio" 
                    type="number" 
                    min="0" 
                    step="0.01" 
                    placeholder="0.00"
                    className={`pl-9 ${formErrors.precio ? 'border-red-500' : ''}`}
                    value={formData.precio !== undefined ? formData.precio : ''} 
                    onChange={handleFormChange}
                  />
                </div>
                {formErrors.precio && (
                  <p className="text-sm text-red-500">{formErrors.precio}</p>
                )}
              </div>
            </div>
          </div>
          
          <DialogFooter className="sm:justify-center border-t pt-6 gap-2 sm:space-x-2">
            <Button variant="outline" onClick={() => setIsFormOpen(false)} className="w-full sm:w-32">Cancelar</Button>
            <Button onClick={handleSave} disabled={isSubmitting} className="w-full sm:w-32">
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Guardar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Modal */}
      <AlertDialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. Esto eliminará permanentemente el registro 
              <span className="font-semibold text-foreground"> {selectedItem?.nombre || selectedItem?.producto} </span> 
              del sistema.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isSubmitting}>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700" disabled={isSubmitting}>
              {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Eliminar'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

    </motion.div>
  );
};

export default ProductsPage;