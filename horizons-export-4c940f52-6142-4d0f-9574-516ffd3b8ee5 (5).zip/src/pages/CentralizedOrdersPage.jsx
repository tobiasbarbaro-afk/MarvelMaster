import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import NewOrderForm from '@/components/centralized_orders/NewOrderForm';
import OrderList from '@/components/centralized_orders/OrderList';
import ShipmentHistoryDialog from '@/components/centralized_orders/ShipmentHistoryDialog';
import MissingItemsDialog from '@/components/centralized_orders/MissingItemsDialog';
import PlacedOrdersDialog from '@/components/centralized_orders/PlacedOrdersDialog';
import OrderListProveedor from '@/components/centralized_orders/OrderListProveedor';
import FilterBar from '@/components/centralized_orders/FilterBar'; 
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { History, Loader2, ClipboardCheck, Package, Truck, Building, RefreshCw, Bug, AlertTriangle, CheckCircle, ShieldAlert } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { resolveFaltantesForPedido } from '@/lib/orderConstraintHelper';
import { isValidStatus } from '@/lib/orderStatusValidator';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { useProductTypeFilter } from '@/hooks/useProductTypeFilter';

const CentralizedOrdersPage = () => {
    const [refreshKey, setRefreshKey] = useState(0);
    const [productosMap, setProductosMap] = useState({});
    const [sucursales, setSucursales] = useState([]);
    const [loadingProducts, setLoadingProducts] = useState(true);
    const [isHistoryOpen, setIsHistoryOpen] = useState(false);
    const [isMissingItemsOpen, setIsMissingItemsOpen] = useState(false);
    const [isPlacedOrdersOpen, setIsPlacedOrdersOpen] = useState(false);
    const [missingItemsCount, setMissingItemsCount] = useState(0);
    const [debugOrders, setDebugOrders] = useState([]);
    const [showDebug, setShowDebug] = useState(false);
    
    // Filter states
    const [selectedStatus, setSelectedStatus] = useState('all');
    const [selectedBranch, setSelectedBranch] = useState('all');
    
    // Per-order loading state management
    const [processingPedidos, setProcessingPedidos] = useState({});
    
    // Integrity check states
    const [integrityCount, setIntegrityCount] = useState(0);
    const [affectedPedidos, setAffectedPedidos] = useState([]);
    const [fixingIntegrity, setFixingIntegrity] = useState(false);
    
    // Data review states
    const [invalidOrdersReview, setInvalidOrdersReview] = useState([]);

    // Product Type Filter states
    const { selectedType, setSelectedType, shouldShowTypeSelector, filterRubrosByType, getFilteredItems } = useProductTypeFilter();
    const [rawProductos, setRawProductos] = useState([]);
    const [rawInsumos, setRawInsumos] = useState([]);
    const [rubros, setRubros] = useState([]);
    const [selectedRubroFilter, setSelectedRubroFilter] = useState('all');

    const { toast } = useToast();
    const { userRole, userProfile } = useAuth();

    const isCentral = userRole === 'centralizada';
    const isSucursalUser = ['admin', 'gerente', 'cocina'].includes(userRole);
    const canViewHistory = ['admin', 'centralizada', 'gerente'].includes(userRole);
    const canViewMissingItems = ['admin', 'centralizada', 'gerente', 'cocina'].includes(userRole);
    const canViewPlacedOrders = ['gerente', 'cocina'].includes(userRole);

    const centralInternalStatuses = useMemo(() => {
        const baseStatuses = ['pendiente', 'gestionado', 'firma_pendiente'];
        if (userRole === 'centralizada') {
            return [...baseStatuses, 'confirmado'];
        }
        return baseStatuses;
    }, [userRole]);

    const fetchMissingItemsCount = useCallback(async () => {
        if (!canViewMissingItems) return;

        let query = supabase
            .from('faltantes_centralizada')
            .select('id', { count: 'exact', head: true })
            .eq('estado', 'pendiente');

        if (['gerente', 'cocina'].includes(userRole) && userProfile?.sucursal_id) {
            query = query.eq('sucursal_id', userProfile.sucursal_id);
        }

        const { count, error } = await query;

        if (error) {
            console.error("Error fetching missing items count:", error);
        } else {
            setMissingItemsCount(count || 0);
        }
    }, [userRole, userProfile, canViewMissingItems]);

    const checkOrderStatuses = useCallback(async () => {
        if (userRole !== 'admin' && userRole !== 'centralizada') return;
        
        try {
            const { data, error } = await supabase
                .from('pedidos_centralizada')
                .select('id, estado, tipo_pedido, sucursal_id')
                .eq('tipo_pedido', 'proveedor')
                .neq('estado', 'cerrado')
                .neq('estado', 'cerrado_proveedor');
                
            if (error) throw error;
            
            const invalidStates = data.filter(o => !isValidStatus(o.estado) || o.estado !== o.estado.trim());
            
            if (invalidStates.length > 0) {
                console.warn("[Data Review] Detected provider orders with corrupt/unknown statuses:", invalidStates);
                setInvalidOrdersReview(invalidStates);
            } else {
                setInvalidOrdersReview([]);
            }
        } catch(error) {
            console.error("Status integrity check failed:", error);
        }
    }, [userRole]);

    const checkIntegrity = useCallback(async () => {
        if (userRole !== 'admin' && userRole !== 'centralizada') return;

        try {
            const { data, error } = await supabase
                .from('faltantes_centralizada')
                .select('pedido_id')
                .eq('estado', 'pendiente');
            
            if (error) throw error;

            if (data && data.length > 0) {
                const uniqueIds = [...new Set(data.map(item => item.pedido_id))];
                setIntegrityCount(data.length);
                setAffectedPedidos(uniqueIds);
            } else {
                setIntegrityCount(0);
                setAffectedPedidos([]);
            }

        } catch (error) {
            console.error("Integrity check failed:", error);
        }
    }, [userRole]);

    const handleFixIntegrity = async () => {
        setFixingIntegrity(true);
        try {
            let fixedCount = 0;
            for (const pedidoId of affectedPedidos) {
                const { success } = await resolveFaltantesForPedido(pedidoId);
                if (success) fixedCount++;
            }
            
            toast({ 
                title: 'Integridad Restaurada', 
                description: `Se han corregido problemas en ${fixedCount} pedidos.` 
            });
            
            setIntegrityCount(0);
            setAffectedPedidos([]);
            handleOrderUpdate();

        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: 'Falló la corrección de datos.' });
        } finally {
            setFixingIntegrity(false);
        }
    };

    const fetchRecentDebugOrders = useCallback(async () => {
        if (!showDebug) return;
        try {
            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            
            const { data, error } = await supabase
                .from('pedidos_centralizada')
                .select('id, created_at, estado, tipo_pedido, proveedor_id, sucursales(nombre), suppliers(name)')
                .gte('created_at', yesterday.toISOString())
                .or('estado.eq.pendiente_proveedor,tipo_pedido.eq.reposicion_faltantes')
                .neq('estado', 'orden_generada')
                .neq('estado', 'cerrado')
                .neq('estado', 'cerrado_proveedor')
                .order('created_at', { ascending: false })
                .limit(10);
            
            if (error) throw error;
            setDebugOrders(data || []);
        } catch (err) {
            console.error("Debug fetch failed:", err);
        }
    }, [showDebug]);

    useEffect(() => {
        const fetchData = async () => {
            setLoadingProducts(true);
            try {
                const [productsRes, sucursalesRes, insumosRes] = await Promise.all([
                    supabase.from('productos_centralizada').select('id, nombre, unidad_medida, unidad_medida_stock, Rubro'),
                    supabase.from('sucursales').select('id, nombre'),
                    supabase.from('insumos_centralizada').select('id, producto, unidad_medida, rubro')
                ]);

                if (productsRes.error) throw productsRes.error;
                if (sucursalesRes.error) throw sucursalesRes.error;
                if (insumosRes.error) throw insumosRes.error;

                const formattedInsumos = insumosRes.data.map(i => ({
                    id: i.id.toString(),
                    nombre: i.producto,
                    Rubro: i.rubro,
                    unidad_medida: i.unidad_medida,
                    unidad_medida_stock: i.unidad_medida
                }));

                setRawProductos(productsRes.data || []);
                setRawInsumos(formattedInsumos);
                setSucursales(sucursalesRes.data);

                // Build complete map for safety, although lists will be filtered
                const allItems = [...(productsRes.data || []), ...formattedInsumos];
                const pMap = allItems.reduce((acc, p) => {
                    acc[p.id] = {
                        nombre: p.nombre,
                        unidad_medida: p.unidad_medida,
                        unidad_medida_stock: p.unidad_medida_stock,
                        rubro: p.Rubro
                    };
                    return acc;
                }, {});
                setProductosMap(pMap);

            } catch (error) {
                toast({ variant: 'destructive', title: 'Error', description: `No se pudieron cargar los datos iniciales: ${error.message}` });
            } finally {
                setLoadingProducts(false);
            }
        };
        fetchData();
        fetchMissingItemsCount();
        checkIntegrity();
        checkOrderStatuses();
    }, [toast, fetchMissingItemsCount, checkIntegrity, checkOrderStatuses, refreshKey]);
    
    useEffect(() => {
        fetchRecentDebugOrders();
    }, [fetchRecentDebugOrders, refreshKey]);

    useEffect(() => {
        if (shouldShowTypeSelector) {
            setRubros(filterRubrosByType(rawProductos, rawInsumos, selectedType));
            setSelectedRubroFilter('all');
        }
    }, [selectedType, rawProductos, rawInsumos, filterRubrosByType, shouldShowTypeSelector]);

    const handleOrderUpdate = () => {
        setRefreshKey(prevKey => prevKey + 1);
    };

    const handleProcessingChange = (orderId, isLoading) => {
        setProcessingPedidos(prev => ({
            ...prev,
            [orderId]: isLoading
        }));
    };

    // Prepare a filtered map to pass to lists, satisfying "show only items matching the selected type"
    const filteredProductosMap = useMemo(() => {
        if (!shouldShowTypeSelector) return productosMap;
        const itemsToUse = getFilteredItems(rawProductos, rawInsumos, selectedType);
        return itemsToUse.reduce((acc, p) => {
            acc[p.id] = {
                nombre: p.nombre,
                unidad_medida: p.unidad_medida,
                unidad_medida_stock: p.unidad_medida_stock,
                rubro: p.Rubro
            };
            return acc;
        }, {});
    }, [shouldShowTypeSelector, rawProductos, rawInsumos, selectedType, getFilteredItems, productosMap]);

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-8"
        >
            <Card className="bg-card/50">
                <CardHeader>
                    <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center">
                        <div>
                            <CardTitle>Gestión de Pedidos</CardTitle>
                            <CardDescription>
                                Centralización de pedidos, envíos a sucursales y compras a proveedores.
                            </CardDescription>
                        </div>
                        <div className="flex items-center gap-2 mt-4 sm:mt-0">
                            {userRole === 'admin' && (
                                <Button variant="ghost" size="icon" onClick={() => setShowDebug(!showDebug)} title="Toggle Debug">
                                    <Bug className={`h-4 w-4 ${showDebug ? 'text-red-500' : 'text-muted-foreground'}`} />
                                </Button>
                            )}
                            <Button variant="outline" size="sm" onClick={handleOrderUpdate}>
                                <RefreshCw className="mr-2 h-4 w-4" /> Actualizar
                            </Button>
                            {canViewMissingItems && (
                                <Button variant="outline" onClick={() => setIsMissingItemsOpen(true)} className="relative">
                                    <ClipboardCheck className="mr-2 h-4 w-4" />
                                    Faltantes
                                    {missingItemsCount > 0 && (
                                        <span className="absolute -top-2 -right-2 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs font-bold text-white">
                                            {missingItemsCount}
                                        </span>
                                    )}
                                </Button>
                            )}
                            {canViewHistory && (
                                <Button onClick={() => setIsHistoryOpen(true)}>
                                    <History className="mr-2 h-4 w-4" />
                                    Historial de Envíos
                                </Button>
                            )}
                        </div>
                    </div>
                </CardHeader>
            </Card>

            {invalidOrdersReview.length > 0 && (
                <Alert variant="destructive" className="bg-orange-50 dark:bg-orange-900/10 border-orange-200 dark:border-orange-900">
                    <ShieldAlert className="h-4 w-4 text-orange-600 dark:text-orange-400" />
                    <AlertTitle className="text-orange-800 dark:text-orange-400">Revisión Manual Requerida</AlertTitle>
                    <AlertDescription className="text-orange-700 dark:text-orange-300">
                        Se encontraron <strong>{invalidOrdersReview.length}</strong> pedidos con estados corruptos (ej. espacios en blanco adicionales o texto no reconocido). 
                        Revise la base de datos o contacte a soporte para su normalización.
                    </AlertDescription>
                </Alert>
            )}

            {integrityCount > 0 && (
                <Alert variant="destructive" className="bg-red-50 dark:bg-red-900/10 border-red-200 dark:border-red-900">
                    <AlertTriangle className="h-4 w-4 text-red-600 dark:text-red-400" />
                    <AlertTitle className="text-red-800 dark:text-red-400">Atención: Problema de Integridad de Datos</AlertTitle>
                    <AlertDescription className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-red-700 dark:text-red-300">
                        <span>
                            Se encontraron <strong>{integrityCount}</strong> registros de faltantes pendientes asociados a <strong>{affectedPedidos.length}</strong> pedidos.
                            Esto puede causar errores al modificar o eliminar pedidos.
                        </span>
                        <Button 
                            variant="destructive" 
                            size="sm" 
                            className="whitespace-nowrap"
                            onClick={handleFixIntegrity}
                            disabled={fixingIntegrity}
                        >
                            {fixingIntegrity ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <CheckCircle className="mr-2 h-4 w-4"/>}
                            {fixingIntegrity ? 'Corrigiendo...' : 'Corregir Integridad'}
                        </Button>
                    </AlertDescription>
                </Alert>
            )}

            {shouldShowTypeSelector && (
                <Card className="bg-card/50">
                    <CardHeader className="pb-3">
                        <CardTitle className="text-lg">Filtro de Productos/Insumos</CardTitle>
                        <CardDescription>Aplica a la creación y visualización de pedidos.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-6 md:space-y-0 md:flex md:items-center md:gap-8">
                            <div className="space-y-3">
                                <Label className="text-base font-semibold">Selecciona tipo</Label>
                                <RadioGroup
                                    value={selectedType}
                                    onValueChange={(val) => {
                                        setSelectedType(val);
                                        setSelectedRubroFilter('all');
                                    }}
                                    className="flex space-x-6"
                                >
                                    <div className="flex items-center space-x-2">
                                        <RadioGroupItem value="Productos" id="type-prod-cop" />
                                        <Label htmlFor="type-prod-cop" className="cursor-pointer">Productos</Label>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                        <RadioGroupItem value="Insumos" id="type-ins-cop" />
                                        <Label htmlFor="type-ins-cop" className="cursor-pointer">Insumos</Label>
                                    </div>
                                </RadioGroup>
                            </div>
                            
                            <div className="space-y-2 flex-1 max-w-sm">
                                <Label htmlFor="rubro-filter">Rubro</Label>
                                <Select value={selectedRubroFilter} onValueChange={setSelectedRubroFilter}>
                                    <SelectTrigger id="rubro-filter" className="w-full">
                                        <SelectValue placeholder="Todos los rubros" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="all">Todos</SelectItem>
                                        {rubros.map(r => (
                                            <SelectItem key={r} value={r}>{r}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            )}

            <FilterBar 
                selectedStatus={selectedStatus}
                onStatusChange={setSelectedStatus}
                selectedBranch={selectedBranch}
                onBranchChange={setSelectedBranch}
                sucursales={sucursales}
            />

            {showDebug && (
                <div className="border border-red-200 bg-red-50 p-4 rounded-md mb-4 dark:bg-red-950/20 dark:border-red-800">
                    <h3 className="font-bold text-red-700 dark:text-red-400 mb-2 flex items-center gap-2">
                        <Bug className="h-4 w-4" /> Debug: Últimos pedidos (24h) validos
                    </h3>
                    <div className="overflow-x-auto">
                        <table className="w-full text-xs text-left">
                            <thead>
                                <tr className="border-b border-red-200 dark:border-red-800">
                                    <th className="p-1">ID</th>
                                    <th className="p-1">Hora</th>
                                    <th className="p-1">Estado (Raw)</th>
                                    <th className="p-1">Tipo</th>
                                    <th className="p-1">Proveedor</th>
                                    <th className="p-1">Sucursal</th>
                                </tr>
                            </thead>
                            <tbody>
                                {debugOrders.map(o => (
                                    <tr key={o.id} className="border-b border-red-100 dark:border-red-900/50">
                                        <td className="p-1 font-mono">{o.id.slice(0, 8)}...</td>
                                        <td className="p-1">{new Date(o.created_at).toLocaleTimeString()}</td>
                                        <td className="p-1">
                                            <Badge variant="outline" className={o.estado === 'orden_generada' ? 'bg-red-100' : ''}>
                                                '{o.estado}'
                                            </Badge>
                                        </td>
                                        <td className="p-1">{o.tipo_pedido}</td>
                                        <td className="p-1">{o.suppliers?.name || '-'}</td>
                                        <td className="p-1">{o.sucursales?.nombre}</td>
                                    </tr>
                                ))}
                                {debugOrders.length === 0 && (
                                    <tr>
                                        <td colSpan="6" className="p-2 text-center text-muted-foreground">No hay datos en 24h</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
                
                {isSucursalUser && (
                    <div className="space-y-6">
                        <div className="flex justify-between items-center">
                            <h2 className="text-2xl font-bold text-blue-400 flex items-center gap-2">
                                <Building className="h-7 w-7" /> Panel Sucursal
                            </h2>
                            {canViewPlacedOrders && (
                                <Button variant="secondary" onClick={() => setIsPlacedOrdersOpen(true)}>
                                    <Package className="mr-2 h-4 w-4" />
                                    Mis Pedidos
                                </Button>
                            )}
                        </div>
                        
                        <NewOrderForm 
                            onOrderCreated={handleOrderUpdate} 
                            filterType={selectedType} 
                            filterRubro={selectedRubroFilter} 
                        />
                        
                        <div className="space-y-2 pt-4">
                            <h3 className="text-lg font-semibold flex items-center gap-2 text-muted-foreground"><Truck className="h-5 w-5" /> Envíos de Proveedores</h3>
                            <OrderListProveedor
                                refreshTrigger={refreshKey}
                                onOrdersRefreshed={handleOrderUpdate}
                                productosMap={filteredProductosMap}
                                loadingProducts={loadingProducts}
                                filterStatus={selectedStatus}
                                filterBranch={selectedBranch}
                                statuses={['pendiente_proveedor']}
                            />
                        </div>
                        <div className="space-y-2 pt-4">
                            <h3 className="text-lg font-semibold flex items-center gap-2 text-muted-foreground"><Building className="h-5 w-5" /> Envíos y Pedidos Internos</h3>
                            <OrderList
                                statuses={['confirmado', 'firma_pendiente', 'pendiente', 'gestionado']}
                                refreshTrigger={refreshKey}
                                onOrdersRefreshed={handleOrderUpdate}
                                productosMap={filteredProductosMap}
                                loadingProducts={loadingProducts}
                                processingOrders={processingPedidos}
                                onProcessingChange={handleProcessingChange}
                                filterStatus={selectedStatus}
                                filterBranch={selectedBranch}
                            />
                        </div>
                    </div>
                )}

                {(isCentral || userRole === 'admin') && (
                    <div className={`space-y-6 ${!isSucursalUser ? 'lg:col-span-2' : ''}`}>
                        <h2 className="text-2xl font-bold text-orange-400 flex items-center gap-2">
                            <Building className="h-7 w-7" /> Panel Centralizada
                        </h2>
                        
                        {!isSucursalUser && (
                             <NewOrderForm 
                                 onOrderCreated={handleOrderUpdate} 
                                 filterType={selectedType} 
                                 filterRubro={selectedRubroFilter} 
                             />
                        )}

                        {loadingProducts ? (
                            <div className="flex justify-center items-center h-40">
                                <Loader2 className="h-8 w-8 animate-spin" />
                            </div>
                        ) : (
                            <>
                                <div className="space-y-2 pt-4">
                                    <h3 className="text-lg font-semibold flex items-center gap-2 text-muted-foreground"><Truck className="h-5 w-5" /> Pedidos a Proveedores</h3>
                                    <OrderListProveedor
                                        refreshTrigger={refreshKey}
                                        onOrdersRefreshed={handleOrderUpdate}
                                        productosMap={filteredProductosMap}
                                        loadingProducts={loadingProducts}
                                        filterStatus={selectedStatus}
                                        filterBranch={selectedBranch}
                                        statuses={['pendiente_proveedor']}
                                    />
                                </div>
                                <div className="space-y-2 pt-4">
                                    <h3 className="text-lg font-semibold flex items-center gap-2 text-muted-foreground"><Building className="h-5 w-5" /> Pedidos y Envíos (Sucursales)</h3>
                                    <OrderList
                                        statuses={centralInternalStatuses}
                                        refreshTrigger={refreshKey}
                                        onOrdersRefreshed={handleOrderUpdate}
                                        productosMap={filteredProductosMap}
                                        loadingProducts={loadingProducts}
                                        processingOrders={processingPedidos}
                                        onProcessingChange={handleProcessingChange}
                                        filterStatus={selectedStatus}
                                        filterBranch={selectedBranch}
                                    />
                                </div>
                            </>
                        )}
                    </div>
                )}
            </div>

            {canViewHistory && (
                <ShipmentHistoryDialog
                    isOpen={isHistoryOpen}
                    onClose={() => setIsHistoryOpen(false)}
                    productosMap={filteredProductosMap}
                    sucursales={sucursales}
                    filterStatus={selectedStatus}
                    filterBranch={selectedBranch}
                />
            )}

            {canViewMissingItems && (
                <MissingItemsDialog
                    isOpen={isMissingItemsOpen}
                    onClose={() => setIsMissingItemsOpen(false)}
                    sucursales={sucursales}
                    onMissingItemsUpdate={handleOrderUpdate}
                    filterStatus={selectedStatus}
                    filterBranch={selectedBranch}
                />
            )}

            {canViewPlacedOrders && (
                <PlacedOrdersDialog
                    isOpen={isPlacedOrdersOpen}
                    onClose={() => setIsPlacedOrdersOpen(false)}
                    productosMap={filteredProductosMap}
                    filterStatus={selectedStatus}
                    filterBranch={selectedBranch}
                />
            )}

        </motion.div>
    );
};

export default CentralizedOrdersPage;