import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/hooks/useAuth';
import { useBranch } from '@/contexts/BranchContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogTrigger } from '@/components/ui/dialog';
import { Loader2, Wallet, PlusCircle, Trash2, Paperclip, CheckCircle, CalendarPlus as CalendarIcon, History } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { v4 as uuidv4 } from 'uuid';
import CadetPaymentHistory from '@/components/cadet_payments/CadetPaymentHistory';
import { getBuenosAiresTime } from '@/lib/sheetUtils';

const CadetPaymentsPage = () => {
    const { userRole, userProfile, user } = useAuth();
    const { availableBranches } = useBranch();
    const { toast } = useToast();

    const [selectedBranchId, setSelectedBranchId] = useState('');
    const [paymentDate, setPaymentDate] = useState(getBuenosAiresTime());
    const [payments, setPayments] = useState([]);
    const [blockReceipt, setBlockReceipt] = useState(null);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        if (userRole === 'gerente' && userProfile?.sucursal_id) {
            setSelectedBranchId(userProfile.sucursal_id.toString());
        }
        addNewRow(); 
    }, [userProfile, userRole]);

    const addNewRow = () => {
        setPayments(prev => [...prev, {
            id: uuidv4(),
            nombre: '',
            monto: '',
            ad_piso: '',
            extras: '',
            descuentos: '',
            justificacion: '',
            total_a_pagar: 0,
        }]);
    };

    const removeRow = (id) => {
        setPayments(prev => prev.filter(p => p.id !== id));
    };

    const updatePaymentRow = (id, field, value) => {
        setPayments(prev => {
            const newPayments = [...prev];
            const index = newPayments.findIndex(p => p.id === id);
            if (index === -1) return prev;

            const payment = { ...newPayments[index], [field]: value };
            
            const monto = parseFloat(payment.monto) || 0;
            const adPiso = parseFloat(payment.ad_piso) || 0;
            const extras = parseFloat(payment.extras) || 0;
            const descuentos = parseFloat(payment.descuentos) || 0;

            payment.total_a_pagar = monto + adPiso + extras - descuentos;
            newPayments[index] = payment;
            return newPayments;
        });
    };

    const handleReceiptChange = (file) => {
        if (file && (file.type === 'application/pdf' || file.type.startsWith('image/'))) {
            setBlockReceipt(file);
        } else {
            toast({ variant: 'destructive', title: 'Archivo no válido', description: 'Por favor, suba un PDF o una imagen.' });
            setBlockReceipt(null);
        }
    };

    const isFormValid = useMemo(() => {
        if (payments.length === 0 || !selectedBranchId || !paymentDate || !blockReceipt) return false;
        return payments.every(p => p.nombre && p.total_a_pagar > 0);
    }, [payments, selectedBranchId, paymentDate, blockReceipt]);

    const totalGeneral = useMemo(() => {
        return payments.reduce((acc, p) => acc + p.total_a_pagar, 0);
    }, [payments]);

    const processPayments = async () => {
        if (!isFormValid) {
            toast({ variant: 'destructive', title: 'Formulario incompleto', description: 'Por favor, complete todos los campos requeridos y adjunte el recibo del bloque.' });
            return;
        }
        setIsLoading(true);

        const paymentDateFormatted = format(paymentDate, 'yyyy-MM-dd');
        let blockReceiptUrl = '';

        try {
            // Upload block receipt
            const filePath = `cadetes/${selectedBranchId}/${paymentDateFormatted}/bloque-${uuidv4()}-${blockReceipt.name}`;
            const { error: uploadError } = await supabase.storage
                .from('recibos-pagos-cadetes')
                .upload(filePath, blockReceipt);

            if (uploadError) throw new Error(`Error al subir el recibo del bloque: ${uploadError.message}`);

            const { data: urlData } = supabase.storage.from('recibos-pagos-cadetes').getPublicUrl(filePath);
            blockReceiptUrl = urlData.publicUrl;

            // Create daily entry for the total amount
            if (totalGeneral > 0) {
                const { error: dailyEntryError } = await supabase.from('entradas_diarias').insert({
                    fecha: paymentDateFormatted,
                    monto: totalGeneral,
                    ioe: 'E',
                    tipo_ioe: 'Pago de Cadetes',
                    razon_social: 'Varios Cadetes',
                    observaciones: `Pago a ${payments.length} cadetes.`,
                    haber: totalGeneral,
                    debe: 0,
                    sucursal_id: parseInt(selectedBranchId),
                    usuario_email: user.email,
                });
                if (dailyEntryError) throw new Error(`Error al crear el egreso en la planilla: ${dailyEntryError.message}`);
            }

            // Create the payment record
            const { error: paymentRecordError } = await supabase.from('pagos_cadetes').insert({
                sucursal_id: parseInt(selectedBranchId),
                usuario_id: user.id,
                fecha_pago: paymentDateFormatted,
                total_pagado: totalGeneral,
                pagos_individuales: payments,
                estado: 'pendiente de verificación',
                advertencia: blockReceiptUrl // Using 'advertencia' field to store the block receipt URL
            });
            if (paymentRecordError) throw new Error(`Error al guardar el registro de pago: ${paymentRecordError.message}`);

            toast({ title: 'Éxito', description: 'Pagos de cadetes procesados y enviados a verificación.' });
            resetForm();

        } catch (error) {
            toast({ variant: 'destructive', title: 'Error en el procesamiento', description: error.message });
        } finally {
            setIsLoading(false);
        }
    };
    
    const resetForm = () => {
        setPayments([]);
        addNewRow();
        setPaymentDate(getBuenosAiresTime());
        setBlockReceipt(null);
        if(userRole === 'admin') setSelectedBranchId('');
    };

    return (
        <div className="container mx-auto p-4 md:p-8">
            <Helmet>
                <title>Pago de Cadetes - MarvelMaster</title>
                <meta name="description" content="Gestión y procesamiento de pagos a cadetes." />
            </Helmet>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold text-primary">Pago de Cadetes</h1>
                <Dialog>
                    <DialogTrigger asChild>
                        <Button variant="outline"><History className="mr-2 h-4 w-4" /> Historial</Button>
                    </DialogTrigger>
                    <CadetPaymentHistory />
                </Dialog>
            </div>
            
            <Card className="w-full">
                <CardHeader>
                    <CardTitle>Formulario de Pago</CardTitle>
                    <CardDescription>Complete los datos para cada cadete. Puede agregar múltiples filas.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {userRole === 'admin' && (
                            <div>
                                <Label htmlFor="branch">Sucursal</Label>
                                <Select value={selectedBranchId} onValueChange={setSelectedBranchId}>
                                    <SelectTrigger><SelectValue placeholder="Seleccionar sucursal" /></SelectTrigger>
                                    <SelectContent>{availableBranches.map(b => <SelectItem key={b.id} value={b.id.toString()}>{b.nombre}</SelectItem>)}</SelectContent>
                                </Select>
                            </div>
                        )}
                        <div>
                            <Label>Fecha del Pago</Label>
                            <Popover>
                                <PopoverTrigger asChild>
                                    <Button variant={"outline"} className={cn("w-full justify-start text-left font-normal", !paymentDate && "text-muted-foreground")}>
                                        <CalendarIcon className="mr-2 h-4 w-4" />
                                        {paymentDate ? format(paymentDate, "PPP", { locale: es }) : <span>Seleccionar fecha</span>}
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={paymentDate} onSelect={setPaymentDate} initialFocus /></PopoverContent>
                            </Popover>
                        </div>
                    </div>

                    <div className="overflow-x-auto">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Nombre</TableHead>
                                    <TableHead>Monto</TableHead>
                                    <TableHead>Ad. Piso</TableHead>
                                    <TableHead>Extras</TableHead>
                                    <TableHead>Descuentos</TableHead>
                                    <TableHead>Justificación</TableHead>
                                    <TableHead>Total</TableHead>
                                    <TableHead></TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {payments.map((p) => (
                                <TableRow key={p.id}>
                                    <TableCell><Input value={p.nombre} onChange={e => updatePaymentRow(p.id, 'nombre', e.target.value)} className="w-32" /></TableCell>
                                    <TableCell><Input type="number" value={p.monto} onChange={e => updatePaymentRow(p.id, 'monto', e.target.value)} className="w-24" /></TableCell>
                                    <TableCell><Input type="number" value={p.ad_piso} onChange={e => updatePaymentRow(p.id, 'ad_piso', e.target.value)} className="w-24" /></TableCell>
                                    <TableCell><Input type="number" value={p.extras} onChange={e => updatePaymentRow(p.id, 'extras', e.target.value)} className="w-24" /></TableCell>
                                    <TableCell><Input type="number" value={p.descuentos} onChange={e => updatePaymentRow(p.id, 'descuentos', e.target.value)} className="w-24" /></TableCell>
                                    <TableCell><Input value={p.justificacion} onChange={e => updatePaymentRow(p.id, 'justificacion', e.target.value)} className="w-32" /></TableCell>
                                    <TableCell className="font-bold">${p.total_a_pagar.toLocaleString('es-AR', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</TableCell>
                                    <TableCell>
                                        <Button variant="ghost" size="icon" onClick={() => removeRow(p.id)} disabled={payments.length <= 1}>
                                            <Trash2 className="h-4 w-4 text-destructive" />
                                        </Button>
                                    </TableCell>
                                </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </div>
                    <Button variant="outline" onClick={addNewRow}><PlusCircle className="mr-2 h-4 w-4" /> Agregar Fila</Button>
                    
                    <div className="text-right font-bold text-xl">
                        Total General: ${totalGeneral.toLocaleString('es-AR', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                    </div>

                    <div className="flex justify-end items-center gap-4">
                            <div>
                            <Label htmlFor="block-receipt" className="cursor-pointer flex items-center gap-2 text-primary hover:text-primary/80">
                                {blockReceipt ? (
                                    <>
                                        <CheckCircle className="h-5 w-5 text-green-500" /> 
                                        <span className="truncate max-w-xs">{blockReceipt.name}</span>
                                    </>
                                ) : (
                                    <>
                                        <Paperclip className="h-5 w-5" /> 
                                        Adjuntar Recibo (Obligatorio)
                                    </>
                                )}
                            </Label>
                            <Input id="block-receipt" type="file" accept="application/pdf,image/*" onChange={(e) => handleReceiptChange(e.target.files[0])} className="sr-only" />
                        </div>
                        <Button onClick={processPayments} disabled={isLoading || !isFormValid}>
                            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Wallet className="mr-2 h-4 w-4" />}
                            Procesar Pagos
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
};

export default CadetPaymentsPage;