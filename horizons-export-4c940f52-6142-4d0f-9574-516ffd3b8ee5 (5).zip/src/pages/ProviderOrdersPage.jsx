import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/lib/supabaseClient';
import InvoiceUploadForm from '@/components/provider_orders/InvoiceUploadForm';
import InvoiceListDisplay from '@/components/provider_orders/InvoiceListDisplay';
import OrdersWithStatusList from '@/components/provider_orders/OrdersWithStatusList';
import ProviderMatchingPanel from '@/components/provider_orders/ProviderMatchingPanel';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';

const ProviderOrdersPage = () => {
    const { userRole, userProfile } = useAuth();
    const { toast } = useToast();
    const isManagerOrKitchen = ['gerente', 'cocina'].includes(userRole);
    const isAdminOrCentral = ['admin', 'centralizada'].includes(userRole);

    const [invoices, setInvoices] = useState([]);
    const [orders, setOrders] = useState([]);
    const [selectedInvoiceId, setSelectedInvoiceId] = useState(null);
    const [selectedOrderId, setSelectedOrderId] = useState(null);
    const [refreshKey, setRefreshKey] = useState(0);
    const [loading, setLoading] = useState(true);

    const fetchData = useCallback(async () => {
        setLoading(true);
        try {
            let invoicesQuery = supabase
                .from('facturas')
                .select('*, suppliers(name), sucursales(nombre)')
                .order('fecha', { ascending: false });

            // ONLY fetch pedidos with estado = 'orden_generada'
            let ordersQuery = supabase
                .from('pedidos_centralizada')
                .select('*, suppliers(name), sucursales(nombre)')
                .eq('estado', 'orden_generada')
                .order('fecha_pedido', { ascending: false });

            if (isManagerOrKitchen && userProfile?.sucursal_id) {
                invoicesQuery = invoicesQuery.eq('sucursal_id', userProfile.sucursal_id);
                // For gerente and cocina, only fetch orders matching user's branch
                ordersQuery = ordersQuery.eq('sucursal_id', userProfile.sucursal_id);
            }

            const [invoicesRes, ordersRes] = await Promise.all([
                invoicesQuery,
                ordersQuery
            ]);

            if (invoicesRes.error) throw invoicesRes.error;
            if (ordersRes.error) throw ordersRes.error;

            setInvoices(invoicesRes.data || []);
            setOrders(ordersRes.data || []);
        } catch (error) {
            console.error("Error fetching provider data:", error);
            toast({
                variant: 'destructive',
                title: 'Error de carga',
                description: 'No se pudieron obtener los datos.'
            });
        } finally {
            setLoading(false);
        }
    }, [isManagerOrKitchen, userProfile, toast]);

    useEffect(() => {
        fetchData();
    }, [fetchData, refreshKey]);

    const handleRefresh = () => {
        setRefreshKey(prev => prev + 1);
        setSelectedInvoiceId(null);
        setSelectedOrderId(null);
    };

    const handleSelectInvoice = (id) => {
        setSelectedInvoiceId(prev => prev === id ? null : id);
    };

    const handleSelectOrder = (id) => {
        setSelectedOrderId(prev => prev === id ? null : id);
    };

    const selectedInvoice = invoices.find(i => i.id === selectedInvoiceId);
    const selectedOrder = orders.find(o => o.id === selectedOrderId);

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-6"
        >
            <div>
                <h1 className="text-3xl font-bold tracking-tight">Gestión de Facturas y Proveedores</h1>
                <p className="text-muted-foreground mt-2">
                    {isAdminOrCentral 
                        ? 'Administra órdenes de compra, carga facturas y asocialas a sus respectivos pedidos.' 
                        : 'Carga de facturas de proveedores y visualiza las órdenes de compra generadas para la sucursal.'}
                </p>
            </div>

            {isAdminOrCentral && (selectedOrderId || selectedInvoiceId) && (
                <ProviderMatchingPanel 
                    selectedOrder={selectedOrder}
                    selectedInvoice={selectedInvoice}
                    onMatchSuccess={handleRefresh}
                />
            )}

            {loading ? (
                <div className="flex justify-center items-center h-64">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
            ) : (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
                    
                    {/* Upload Form Column */}
                    <div className="lg:col-span-1 space-y-6">
                        <InvoiceUploadForm onUploadSuccess={handleRefresh} />
                    </div>

                    {/* Lists Columns */}
                    <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
                        
                        <div className="h-[600px]">
                            <OrdersWithStatusList 
                                orders={orders}
                                selectedOrderId={selectedOrderId}
                                onSelectOrder={handleSelectOrder}
                            />
                        </div>

                        <div className="h-[600px]">
                            <InvoiceListDisplay 
                                invoices={invoices}
                                selectedInvoiceId={selectedInvoiceId}
                                onSelectInvoice={handleSelectInvoice}
                                isReadOnly={isManagerOrKitchen}
                            />
                        </div>

                    </div>

                </div>
            )}
        </motion.div>
    );
};

export default ProviderOrdersPage;