import React, { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, Save, Eye, Calendar as CalendarIcon, AlertTriangle } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { getBuenosAiresTime } from '@/lib/sheetUtils';
import { useProductTypeFilter } from '@/hooks/useProductTypeFilter';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';

const StockTurnoPage = () => {
    const { toast } = useToast();
    const { userProfile, userRole } = useAuth();
    const [loading, setLoading] = useState(false);
    const [saving, setSaving] = useState(false);
    const [productos, setProductos] = useState([]);
    const [insumos, setInsumos] = useState([]);
    const [rubros, setRubros] = useState([]);
    const [selectedRubro, setSelectedRubro] = useState('');
    const [stockData, setStockData] = useState({});
    const [selectedDate, setSelectedDate] = useState(getBuenosAiresTime());
    const [selectedTurno, setSelectedTurno] = useState('Mediodia');
    const [sucursalId, setSucursalId] = useState(null);
    const [sucursales, setSucursales] = useState([]);
    const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
    const [viewStockData, setViewStockData] = useState([]);
    const [viewLoading, setViewLoading] = useState(false);
    
    const [submittedRubros, setSubmittedRubros] = useState(new Set());
    const [checkingStock, setCheckingStock] = useState(false);

    const { selectedType, setSelectedType, shouldShowTypeSelector, filterRubrosByType, getFilteredItems } = useProductTypeFilter();

    const canManageAllBranches = ['admin', 'centralizada'].includes(userRole);

    useEffect(() => {
        const fetchInitialData = async () => {
            setLoading(true);
            try {
                const [productosRes, insumosRes] = await Promise.all([
                    supabase.from('productos_centralizada').select('id, nombre, Rubro, unidad_medida, unidad_medida_stock').order('nombre', { ascending: true }),
                    supabase.from('insumos_centralizada').select('id, producto, unidad_medida, rubro')
                ]);

                if (productosRes.error) throw productosRes.error;
                if (insumosRes.error) throw insumosRes.error;

                // Task 1: Fix UUID validation error. 
                // Map numeric insumo ID to UUID by matching name with productos_centralizada
                const formattedInsumos = insumosRes.data.reduce((acc, i) => {
                    const matchingProduct = productosRes.data.find(
                        p => p.nombre.trim().toLowerCase() === i.producto.trim().toLowerCase()
                    );
                    
                    // Only include insumos that have a corresponding UUID in productos_centralizada
                    if (matchingProduct) {
                        acc.push({
                            id: matchingProduct.id, // Use UUID from productos_centralizada
                            nombre: i.producto,
                            Rubro: i.rubro || matchingProduct.Rubro,
                            unidad_medida: i.unidad_medida,
                            unidad_medida_stock: i.unidad_medida
                        });
                    }
                    return acc;
                }, []).sort((a, b) => a.nombre.localeCompare(b.nombre));

                setProductos(productosRes.data);
                setInsumos(formattedInsumos);

                if (canManageAllBranches) {
                    const { data: sucursalesData, error: sucursalesError } = await supabase
                        .from('sucursales')
                        .select('id, nombre')
                        .order('nombre', { ascending: true });

                    if (sucursalesError) throw sucursalesError;
                    setSucursales(sucursalesData);
                } else if (userProfile?.sucursal_id) {
                    setSucursalId(userProfile.sucursal_id);
                }
            } catch (error) {
                toast({ variant: 'destructive', title: 'Error', description: `No se pudieron cargar los datos: ${error.message}` });
            } finally {
                setLoading(false);
            }
        };

        fetchInitialData();
    }, [toast, userProfile, canManageAllBranches, userRole]);

    useEffect(() => {
        setRubros(filterRubrosByType(productos, insumos, selectedType));
        setSelectedRubro('');
    }, [selectedType, productos, insumos, filterRubrosByType]);

    useEffect(() => {
        const checkExistingStock = async () => {
            if (!sucursalId || !selectedDate || !selectedTurno || productos.length === 0) {
                setSubmittedRubros(new Set());
                return;
            }

            setCheckingStock(true);
            try {
                const formattedDate = format(selectedDate, 'yyyy-MM-dd');
                const { data, error } = await supabase
                    .from('stock_turno')
                    .select('producto_id')
                    .eq('sucursal_id', sucursalId)
                    .eq('fecha', formattedDate)
                    .eq('turno', selectedTurno);

                if (error) throw error;

                const foundRubros = new Set();
                const itemsToUse = selectedType === 'Productos' ? productos : insumos;
                
                data.forEach(item => {
                    // Look up by itemsToUse to get context-aware Rubro (Product Rubro vs Insumo Rubro)
                    const product = itemsToUse.find(p => p.id === item.producto_id);
                    if (product && product.Rubro) {
                        foundRubros.add(product.Rubro);
                    }
                });

                setSubmittedRubros(foundRubros);
            } catch (error) {
                console.error("Error checking existing stock:", error);
            } finally {
                setCheckingStock(false);
            }
        };

        checkExistingStock();
    }, [sucursalId, selectedDate, selectedTurno, productos, insumos, selectedType]);

    const itemsToUse = getFilteredItems(productos, insumos, selectedType);
    
    const productosInRubro = useMemo(() => {
        if (!selectedRubro) return [];
        return itemsToUse.filter(p => p.Rubro === selectedRubro);
    }, [selectedRubro, itemsToUse]);

    const isCurrentRubroSubmitted = useMemo(() => {
        return selectedRubro && submittedRubros.has(selectedRubro);
    }, [selectedRubro, submittedRubros]);

    const handleStockChange = (productoId, cantidad) => {
        let parsedQuantity = parseInt(cantidad, 10);
        if (isNaN(parsedQuantity) || parsedQuantity < 0) {
            parsedQuantity = parsedQuantity < 0 ? 0 : '';
        }
        setStockData(prev => ({
            ...prev,
            [productoId]: parsedQuantity
        }));
    };

    const handleSaveStock = async () => {
        if (!sucursalId) {
            toast({ variant: 'destructive', title: 'Error', description: 'Debes seleccionar una sucursal.' });
            return;
        }

        if (!selectedDate) {
            toast({ variant: 'destructive', title: 'Error', description: 'Debes seleccionar una fecha.' });
            return;
        }
        
        if (isCurrentRubroSubmitted) {
             toast({ variant: 'destructive', title: 'Error', description: `El stock para el rubro ${selectedRubro} ya ha sido registrado.` });
             return;
        }

        const stockEntries = Object.entries(stockData)
            .filter(([_, cantidad]) => cantidad !== '' && cantidad >= 0)
            .map(([productoId, cantidad]) => ({
                sucursal_id: sucursalId,
                producto_id: productoId, // This is now guaranteed to be a UUID
                usuario_id: userProfile.id,
                fecha: format(selectedDate, 'yyyy-MM-dd'),
                turno: selectedTurno,
                cantidad: Number(cantidad)
            }));

        if (stockEntries.length === 0) {
            toast({ variant: 'destructive', title: 'Sin datos', description: 'No hay cantidades válidas para guardar.' });
            return;
        }

        setSaving(true);
        try {
            const { error } = await supabase
                .from('stock_turno')
                .upsert(stockEntries, {
                    onConflict: 'sucursal_id,producto_id,fecha,turno',
                    ignoreDuplicates: false
                });

            if (error) throw error;

            toast({ title: 'Éxito', description: `Stock de ${selectedRubro} guardado correctamente.` });
            setStockData({});
            setSubmittedRubros(prev => new Set(prev).add(selectedRubro));
            
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: `No se pudo guardar el stock: ${error.message}` });
        } finally {
            setSaving(false);
        }
    };

    const handleViewStock = async () => {
        if (!sucursalId) {
            toast({ variant: 'destructive', title: 'Error', description: 'Debes seleccionar una sucursal.' });
            return;
        }

        if (!selectedDate) {
            toast({ variant: 'destructive', title: 'Error', description: 'Debes seleccionar una fecha.' });
            return;
        }

        setViewLoading(true);
        setIsViewDialogOpen(true);

        try {
            const { data, error } = await supabase.rpc('get_stock_by_sucursal_and_date', {
                p_sucursal_id: sucursalId,
                p_fecha: format(selectedDate, 'yyyy-MM-dd')
            });

            if (error) throw error;

            const allItems = [...productos, ...insumos];
            const enrichedData = data.map(item => {
                const productInfo = allItems.find(p => p.id === item.producto_id);
                return {
                    ...item,
                    unidad_medida: productInfo?.unidad_medida,
                    unidad_medida_stock: productInfo?.unidad_medida_stock
                };
            });

            setViewStockData(enrichedData || []);
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: `No se pudo cargar el stock: ${error.message}` });
            setViewStockData([]);
        } finally {
            setViewLoading(false);
        }
    };

    const groupedViewStock = useMemo(() => {
        return viewStockData.reduce((acc, item) => {
            if (!acc[item.rubro]) {
                acc[item.rubro] = [];
            }
            acc[item.rubro].push(item);
            return acc;
        }, {});
    }, [viewStockData]);

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-6"
        >
            <Card>
                <CardHeader>
                    <CardTitle>Stock Fin de Turno</CardTitle>
                    <CardDescription>Registra el stock disponible al finalizar cada turno.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        {canManageAllBranches && (
                            <div>
                                <Label htmlFor="sucursal-select">Sucursal</Label>
                                <Select value={sucursalId?.toString() || ''} onValueChange={(v) => setSucursalId(Number(v))}>
                                    <SelectTrigger id="sucursal-select">
                                        <SelectValue placeholder="Seleccionar sucursal" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {sucursales.map(s => (
                                            <SelectItem key={s.id} value={s.id.toString()}>{s.nombre}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                        )}

                        <div>
                            <Label htmlFor="date-select">Fecha</Label>
                            <Popover>
                                <PopoverTrigger asChild>
                                    <Button
                                        id="date-select"
                                        variant="outline"
                                        className={cn("w-full justify-start text-left font-normal", !selectedDate && "text-muted-foreground")}
                                    >
                                        <CalendarIcon className="mr-2 h-4 w-4" />
                                        {selectedDate ? format(selectedDate, "PPP", { locale: es }) : <span>Seleccionar fecha</span>}
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0">
                                    <Calendar mode="single" selected={selectedDate} onSelect={setSelectedDate} initialFocus />
                                </PopoverContent>
                            </Popover>
                        </div>

                        <div>
                            <Label htmlFor="turno-select">Turno</Label>
                            <Select value={selectedTurno} onValueChange={setSelectedTurno}>
                                <SelectTrigger id="turno-select">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Mediodia">Mediodía</SelectItem>
                                    <SelectItem value="Noche">Noche</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="flex items-end">
                            <Button onClick={handleViewStock} variant="outline" className="w-full" disabled={!sucursalId || !selectedDate}>
                                <Eye className="mr-2 h-4 w-4" />
                                Ver Stock del Día
                            </Button>
                        </div>
                    </div>

                    {shouldShowTypeSelector && (
                        <div className="space-y-3 mb-6 p-4 border rounded-md bg-muted/20">
                            <Label className="text-base font-semibold">Selecciona tipo</Label>
                            <RadioGroup
                                value={selectedType}
                                onValueChange={(val) => {
                                    setSelectedType(val);
                                }}
                                className="flex space-x-6"
                            >
                                <div className="flex items-center space-x-2">
                                    <RadioGroupItem value="Productos" id="type-prod" />
                                    <Label htmlFor="type-prod" className="cursor-pointer">Productos</Label>
                                </div>
                                <div className="flex items-center space-x-2">
                                    <RadioGroupItem value="Insumos" id="type-ins" />
                                    <Label htmlFor="type-ins" className="cursor-pointer">Insumos</Label>
                                </div>
                            </RadioGroup>
                        </div>
                    )}

                    <div>
                        <Label htmlFor="rubro-select">Seleccionar Rubro</Label>
                        <Select value={selectedRubro} onValueChange={setSelectedRubro} disabled={loading}>
                            <SelectTrigger id="rubro-select">
                                <SelectValue placeholder={loading ? "Cargando rubros..." : "Selecciona un rubro"} />
                            </SelectTrigger>
                            <SelectContent className="max-h-60 overflow-y-auto">
                                {rubros.map(rubro => {
                                    const isSubmitted = submittedRubros.has(rubro);
                                    return (
                                        <SelectItem key={rubro} value={rubro} className="flex justify-between items-center w-full">
                                            <span className={cn(isSubmitted && "text-muted-foreground line-through decoration-green-500 decoration-2")}>
                                                {rubro}
                                            </span>
                                            {isSubmitted && <span className="ml-2 text-green-600 text-xs font-bold">(Cargado)</span>}
                                        </SelectItem>
                                    );
                                })}
                            </SelectContent>
                        </Select>
                    </div>

                    {isCurrentRubroSubmitted && (
                        <Alert variant="destructive">
                            <AlertTriangle className="h-4 w-4" />
                            <AlertTitle>Rubro ya registrado</AlertTitle>
                            <AlertDescription>
                                Ya se ha registrado el stock para el rubro <strong>{selectedRubro}</strong> en este turno. No es posible realizar modificaciones ni nuevas cargas para este rubro específico.
                            </AlertDescription>
                        </Alert>
                    )}

                    {selectedRubro && !isCurrentRubroSubmitted && (
                        <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            className="space-y-3 border p-4 rounded-md bg-muted/50"
                        >
                            <h3 className="font-semibold text-lg text-primary flex items-center gap-2">
                                {selectedRubro}
                            </h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                {productosInRubro.map(producto => (
                                    <div key={producto.id} className="flex items-center gap-2">
                                        <Label htmlFor={`stock-${producto.id}`} className="flex-1 text-sm">{producto.nombre}</Label>
                                        <div className="flex items-center">
                                            <Input
                                                id={`stock-${producto.id}`}
                                                type="number"
                                                min="0"
                                                placeholder="0"
                                                value={stockData[producto.id] || ''}
                                                onChange={(e) => handleStockChange(producto.id, e.target.value)}
                                                className="w-20 rounded-r-none"
                                            />
                                            <span className="bg-background text-muted-foreground text-xs px-2 py-2 border border-l-0 rounded-r-md whitespace-nowrap">
                                                {producto.unidad_medida_stock || producto.unidad_medida || 'Unid.'}
                                            </span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </motion.div>
                    )}

                    <div className="flex justify-end pt-4">
                        <Button 
                            onClick={handleSaveStock} 
                            disabled={saving || !sucursalId || Object.keys(stockData).length === 0 || isCurrentRubroSubmitted || checkingStock}
                        >
                            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                            Guardar Stock
                        </Button>
                    </div>
                </CardContent>
            </Card>

            <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
                <DialogContent className="max-w-4xl h-[90vh] flex flex-col">
                    <DialogHeader>
                        <DialogTitle>Stock del {selectedDate ? format(selectedDate, "PPP", { locale: es }) : ''}</DialogTitle>
                        <DialogDescription>
                            {sucursales.find(s => s.id === sucursalId)?.nombre || 'Sucursal seleccionada'}
                        </DialogDescription>
                    </DialogHeader>
                    <ScrollArea className="flex-1 pr-4">
                        {viewLoading ? (
                            <div className="flex justify-center items-center h-full">
                                <Loader2 className="h-8 w-8 animate-spin" />
                            </div>
                        ) : viewStockData.length === 0 ? (
                            <p className="text-center text-muted-foreground py-8">No hay stock registrado para esta fecha.</p>
                        ) : (
                            <div className="space-y-6">
                                {Object.entries(groupedViewStock).map(([rubro, items]) => (
                                    <div key={rubro}>
                                        <h3 className="font-semibold text-lg mb-2 text-primary">{rubro}</h3>
                                        <Table>
                                            <TableHeader>
                                                <TableRow>
                                                    <TableHead>Producto</TableHead>
                                                    <TableHead>Turno</TableHead>
                                                    <TableHead className="text-right">Cantidad</TableHead>
                                                </TableRow>
                                            </TableHeader>
                                            <TableBody>
                                                {items.map((item, idx) => {
                                                    const unit = item.unidad_medida_stock || item.unidad_medida || 'Unid.';
                                                    return (
                                                        <TableRow key={`${item.producto_id}-${item.turno}-${idx}`}>
                                                            <TableCell>{item.nombre_producto}</TableCell>
                                                            <TableCell>{item.turno}</TableCell>
                                                            <TableCell className="text-right font-medium">
                                                                {item.cantidad} x {unit}
                                                            </TableCell>
                                                        </TableRow>
                                                    );
                                                })}
                                            </TableBody>
                                        </Table>
                                    </div>
                                ))}
                            </div>
                        )}
                    </ScrollArea>
                </DialogContent>
            </Dialog>
        </motion.div>
    );
};

export default StockTurnoPage;