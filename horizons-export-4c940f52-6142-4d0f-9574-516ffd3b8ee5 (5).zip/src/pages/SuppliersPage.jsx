import React, { useState, useEffect, useCallback } from 'react';
    import { motion } from 'framer-motion';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { PlusCircle, AlertTriangle } from 'lucide-react';
    import SupplierList from '@/components/suppliers/SupplierList';
    import SupplierFormDialog from '@/components/suppliers/SupplierFormDialog';
    import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
    import { supabase } from '@/lib/supabaseClient';
    import { useToast } from '@/components/ui/use-toast';
    import { useAuth } from '@/hooks/useAuth';

    const SuppliersPage = () => {
      const [suppliers, setSuppliers] = useState([]);
      const [isLoading, setIsLoading] = useState(true);
      const [isFormOpen, setIsFormOpen] = useState(false);
      const [selectedSupplier, setSelectedSupplier] = useState(null);
      const [supplierToDelete, setSupplierToDelete] = useState(null);
      const [isAlertOpen, setIsAlertOpen] = useState(false);

      const { toast } = useToast();
      const { userRole } = useAuth();

      const fetchSuppliers = useCallback(async () => {
        setIsLoading(true);
        const { data, error } = await supabase
          .from('suppliers')
          .select('*') 
          .order('name', { ascending: true });

        if (error) {
          toast({ variant: "destructive", title: "Error", description: "No se pudieron cargar los proveedores." });
          setSuppliers([]);
        } else {
          setSuppliers(data || []);
        }
        setIsLoading(false);
      }, [toast]);

      useEffect(() => {
        fetchSuppliers();
      }, [fetchSuppliers]);

      const handleAddSupplier = () => {
        if (userRole !== 'admin') {
          toast({ variant: "destructive", title: "Acceso Denegado", description: "Solo los administradores pueden agregar proveedores." });
          return;
        }
        setSelectedSupplier(null);
        setIsFormOpen(true);
      };

      const handleEditSupplier = (supplier) => {
        if (userRole !== 'admin') {
          toast({ variant: "destructive", title: "Acceso Denegado", description: "Solo los administradores pueden editar proveedores." });
          return;
        }
        setSelectedSupplier(supplier);
        setIsFormOpen(true);
      };

      const handleDeleteSupplier = (supplierId) => {
         if (userRole !== 'admin') {
          toast({ variant: "destructive", title: "Acceso Denegado", description: "Solo los administradores pueden eliminar proveedores." });
          return;
        }
        setSupplierToDelete(supplierId);
        setIsAlertOpen(true);
      };

      const confirmDelete = async () => {
        if (!supplierToDelete) return;
        setIsLoading(true);
        const { error } = await supabase.from('suppliers').delete().eq('id', supplierToDelete);
        setIsLoading(false);
        setIsAlertOpen(false);
        setSupplierToDelete(null);

        if (error) {
          toast({ variant: "destructive", title: "Error al eliminar", description: error.message });
        } else {
          toast({ title: "Éxito", description: "Proveedor eliminado correctamente." });
          fetchSuppliers();
        }
      };

      const handleSaveSupplier = (savedSupplier) => {
        fetchSuppliers(); 
      };
      
      if (userRole !== 'admin' && !isLoading && suppliers.length === 0) {
         return (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="flex flex-col items-center justify-center h-[calc(100vh-200px)] text-center"
            >
              <AlertTriangle className="w-16 h-16 text-yellow-500 mb-4" />
              <h1 className="text-2xl font-semibold text-foreground mb-2">Acceso Restringido</h1>
              <p className="text-muted-foreground">
                Actualmente no hay proveedores para mostrar y no tienes permisos para agregar nuevos.
              </p>
            </motion.div>
          );
      }


      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-6"
        >
          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-bold text-primary">Gestión de Proveedores</h1>
            {userRole === 'admin' && (
              <Button onClick={handleAddSupplier} className="bg-primary text-primary-foreground hover:bg-primary/90">
                <PlusCircle className="w-5 h-5 mr-2" />
                Agregar Proveedor
              </Button>
            )}
          </div>

          <Card className="shadow-xl border-border">
            <CardHeader>
              <CardTitle className="text-xl">Listado de Proveedores</CardTitle>
              <CardDescription>
                Aquí puede ver, agregar, editar y eliminar proveedores. Los proveedores son comunes a todas las sucursales.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <SupplierList
                suppliers={suppliers}
                onEdit={handleEditSupplier}
                onDelete={handleDeleteSupplier}
                isLoading={isLoading}
                isAdmin={userRole === 'admin'}
              />
            </CardContent>
          </Card>

          {userRole === 'admin' && (
            <SupplierFormDialog
              open={isFormOpen}
              onOpenChange={setIsFormOpen}
              supplier={selectedSupplier}
              onSave={handleSaveSupplier}
            />
          )}

          <AlertDialog open={isAlertOpen} onOpenChange={setIsAlertOpen}>
            <AlertDialogContent className="bg-card border-border">
              <AlertDialogHeader>
                <AlertDialogTitle className="text-destructive">¿Está seguro de eliminar este proveedor?</AlertDialogTitle>
                <AlertDialogDescription>
                  Esta acción no se puede deshacer. El proveedor será eliminado permanentemente.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel onClick={() => setSupplierToDelete(null)} disabled={isLoading}>Cancelar</AlertDialogCancel>
                <AlertDialogAction onClick={confirmDelete} className="bg-destructive hover:bg-destructive/90" disabled={isLoading}>
                  {isLoading ? 'Eliminando...' : 'Sí, eliminar'}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </motion.div>
      );
    };

    export default SuppliersPage;