import React, { useState, useEffect, useCallback } from 'react';
    import { motion } from 'framer-motion';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { PlusCircle, ShieldAlert, Loader2 } from 'lucide-react';
    import { supabase } from '@/lib/supabaseClient';
    import { useAuth } from '@/hooks/useAuth';
    import { useToast } from '@/components/ui/use-toast';
    import BranchFormDialog from '@/components/branches/BranchFormDialog';
    import BranchList from '@/components/branches/BranchList';
    import { useBranch } from '@/contexts/BranchContext';

    const BranchesPage = () => {
      const [branches, setBranches] = useState([]);
      const [isLoadingPage, setIsLoadingPage] = useState(true);
      const [isSubmitting, setIsSubmitting] = useState(false);
      const [isDialogOpen, setIsDialogOpen] = useState(false);
      const [currentBranch, setCurrentBranch] = useState(null);

      const { user, userRole } = useAuth();
      const { toast } = useToast();
      const { fetchBranches: contextFetchBranches } = useBranch();

      const isAdmin = userRole === 'admin';

      const fetchPageBranches = useCallback(async () => {
        setIsLoadingPage(true);
        const { data, error } = await supabase
          .from('sucursales')
          .select('*')
          .order('fecha_creacion', { ascending: false });

        if (error) {
          console.error('Error fetching branches:', error);
          toast({ variant: "destructive", title: "Error", description: "No se pudieron cargar las sucursales." });
        } else {
          setBranches(data || []);
        }
        setIsLoadingPage(false);
      }, [toast]);

      useEffect(() => {
        if (isAdmin) {
          fetchPageBranches();
        } else {
          setIsLoadingPage(false); 
        }
      }, [isAdmin, fetchPageBranches]);
      
      const handleOpenDialog = (branch = null) => {
        setCurrentBranch(branch);
        setIsDialogOpen(true);
      };

      const handleCloseDialog = () => {
        setIsDialogOpen(false);
        setCurrentBranch(null);
      };

      const saveInitialBalance = async (branchId, initialBalance, initialBalanceMonth, userEmail) => {
        if (initialBalance == null || !initialBalanceMonth) return;

        const [year, month] = initialBalanceMonth.split('-').map(Number);
        let prevYear = year;
        let prevMonth = month - 1;
        if (prevMonth === 0) {
          prevMonth = 12;
          prevYear -= 1;
        }
        const targetMonthForInitialBalance = `${prevYear}-${String(prevMonth).padStart(2, '0')}`;

        const { error } = await supabase
          .from('saldos_mensuales')
          .upsert({
            sucursal_id: branchId,
            mes_anio: targetMonthForInitialBalance,
            saldo: initialBalance,
            actualizado_por_email: userEmail,
            fecha_actualizacion: new Date().toISOString()
          }, { onConflict: 'sucursal_id, mes_anio' });

        if (error) {
          console.error('Error saving initial balance:', error);
          toast({ variant: "destructive", title: "Error Saldo Inicial", description: `No se pudo guardar el saldo inicial: ${error.message}` });
        } else {
          toast({ title: "Saldo Inicial Guardado", description: `Saldo inicial para ${targetMonthForInitialBalance} guardado.`});
        }
      };

      const handleSubmit = async (branchDataInput) => {
        if (!isAdmin || !user || !user.email) {
          toast({ variant: "destructive", title: "Acceso denegado", description: "No tienes permisos o no estás autenticado." });
          return;
        }
        setIsSubmitting(true);

        const dataToSubmit = {
          nombre: branchDataInput.nombre,
          direccion: branchDataInput.direccion,
        };

        let response;
        let newBranchId = null;

        if (currentBranch) {
          response = await supabase
            .from('sucursales')
            .update(dataToSubmit)
            .eq('id', currentBranch.id)
            .select();
        } else {
          dataToSubmit.creado_por = user.id;
          response = await supabase
            .from('sucursales')
            .insert(dataToSubmit)
            .select();
          if (response.data && response.data.length > 0) {
            newBranchId = response.data[0].id;
          }
        }

        if (response.error) {
          console.error('Error saving branch:', response.error);
          toast({ variant: "destructive", title: "Error", description: `No se pudo guardar la sucursal: ${response.error.message}` });
        } else {
          toast({ title: "Éxito", description: `Sucursal ${currentBranch ? 'actualizada' : 'creada'} correctamente.` });
          
          if (newBranchId && branchDataInput.initial_balance != null && branchDataInput.initial_balance_month) {
            await saveInitialBalance(newBranchId, branchDataInput.initial_balance, branchDataInput.initial_balance_month, user.email);
          }

          fetchPageBranches(); 
          if (typeof contextFetchBranches === 'function') {
             await contextFetchBranches();
          } else {
            console.warn("contextFetchBranches is not a function in BranchesPage");
          }
          handleCloseDialog();
        }
        setIsSubmitting(false);
      };

      const handleDeleteBranch = async (branchId) => {
        if (!isAdmin) {
          toast({ variant: "destructive", title: "Acceso denegado", description: "No tienes permisos para eliminar sucursales." });
          return;
        }
        setIsSubmitting(true);
        
        const { error } = await supabase
          .from('sucursales')
          .delete()
          .eq('id', branchId);

        if (error) {
          console.error('Error deleting branch:', error);
          toast({ variant: "destructive", title: "Error", description: `No se pudo eliminar la sucursal: ${error.message}` });
        } else {
          toast({ title: "Éxito", description: "Sucursal eliminada correctamente." });
          fetchPageBranches();
           if (typeof contextFetchBranches === 'function') {
             await contextFetchBranches();
           } else {
            console.warn("contextFetchBranches is not a function in BranchesPage during delete");
           }
        }
        setIsSubmitting(false);
      };
      
      if (!isAdmin && !isLoadingPage) {
        return (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-6 flex flex-col items-center justify-center h-full"
          >
            <Card className="w-full max-w-md shadow-xl border-destructive/50 bg-destructive/10">
              <CardHeader className="items-center">
                <ShieldAlert className="w-16 h-16 text-destructive" />
                <CardTitle className="text-2xl text-destructive">Acceso Denegado</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-muted-foreground">No tienes los permisos necesarios para acceder a esta sección.</p>
                <p className="text-sm text-muted-foreground mt-2">Contacta a un administrador si crees que esto es un error.</p>
              </CardContent>
            </Card>
          </motion.div>
        );
      }

      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-6"
        >
          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-bold text-primary">Gestión de Sucursales</h1>
            {isAdmin && (
              
                <Button className="bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => handleOpenDialog()}>
                  <PlusCircle className="w-5 h-5 mr-2" />
                  Agregar Sucursal
                </Button>
              
            )}
          </div>

          <BranchFormDialog 
            isOpen={isDialogOpen}
            onOpenChange={setIsDialogOpen}
            onSubmit={handleSubmit}
            initialData={currentBranch}
            isSubmitting={isSubmitting}
          />

          {isLoadingPage ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-12 w-12 animate-spin text-primary" />
            </div>
          ) : (
            <Card className="shadow-xl border-border">
              <CardHeader>
                <CardTitle className="text-xl">Listado de Sucursales</CardTitle>
              </CardHeader>
              <CardContent>
                <BranchList 
                  branches={branches}
                  onEdit={handleOpenDialog}
                  onDelete={handleDeleteBranch}
                  isAdmin={isAdmin}
                  isSubmitting={isSubmitting}
                />
              </CardContent>
            </Card>
          )}
        </motion.div>
      );
    };

    export default BranchesPage;