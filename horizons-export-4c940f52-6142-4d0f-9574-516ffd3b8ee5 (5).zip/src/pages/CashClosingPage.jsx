import React from 'react';
    import { useAuth } from '@/hooks/useAuth';
    import ClosingForm from '@/components/cash_closing/ClosingForm';
    import ClosingRecords from '@/components/cash_closing/ClosingRecords';
    
    const CashClosingPage = () => {
      const { userRole } = useAuth();
    
      return (
        <div className="container mx-auto p-4">
          <ClosingForm />
          {['admin', 'gerente'].includes(userRole) && <ClosingRecords />}
        </div>
      );
    };
    
    export default CashClosingPage;