import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import EntryForm from '@/components/daily_entry/EntryForm';
import ExportSection from '@/components/sheet/ExportSection';
import ViewSheetSection from '@/components/sheet/ViewSheetSection';
import { useAuth } from '@/hooks/useAuth';
import { useBranch } from '@/contexts/BranchContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { DollarSign } from 'lucide-react';

const SafeBoxPage = () => {
  const { userRole, user, userProfile } = useAuth();
  const { 
    availableBranches, 
    loadingBranches, 
    getBranchNameById 
  } = useBranch();
  const { toast } = useToast();

  const [selectedBranchId, setSelectedBranchId] = useState('');
  const [currentTab, setCurrentTab] = useState("ingresar");

  useEffect(() => {
    if (['gerente', 'mostrador'].includes(userRole) && userProfile?.sucursal_id) {
      setSelectedBranchId(userProfile.sucursal_id.toString());
    }
  }, [userProfile, userRole]);

  const commonSheetProps = {
    supabase,
    toast,
    user,
    availableBranches,
    selectedBranchId,
    setSelectedBranchId,
    loadingBranches,
    getBranchNameById,
  };

  // Only Admin, Gerente and Centralizada have access to all tabs
  const canViewAll = ['admin', 'gerente', 'centralizada'].includes(userRole);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-8 pb-10"
    >
      <div className="flex flex-col items-center justify-center mb-6 mt-4">
        <h1 className="text-4xl font-extrabold text-primary mb-3 flex items-center gap-3">
          <DollarSign className="w-10 h-10 p-2 bg-primary/10 rounded-xl" />
          Caja Fuerte
        </h1>
        <p className="text-muted-foreground text-lg text-center max-w-2xl">
          {canViewAll 
            ? "Gestione los ingresos, egresos y visualice la planilla de movimientos de la caja fuerte."
            : "Registre un nuevo ingreso o egreso en la caja fuerte de su sucursal."}
        </p>
      </div>

      <Tabs 
        defaultValue="ingresar" 
        value={currentTab} 
        onValueChange={setCurrentTab} 
        className="w-full mx-auto"
      >
        {canViewAll && (
          <TabsList className="grid w-full max-w-3xl mx-auto grid-cols-3 gap-2 mb-8 bg-muted/50 p-1.5 rounded-xl shadow-sm">
            <TabsTrigger value="ingresar" className="text-md data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow">Ingresar Movimiento</TabsTrigger>
            <TabsTrigger value="exportar" className="text-md data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow">Exportar Planilla</TabsTrigger>
            <TabsTrigger value="visualizar" className="text-md data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow">Visualizar Movimientos</TabsTrigger>
          </TabsList>
        )}
        
        <div className="mt-4">
            <AnimatePresence mode="wait">
                {currentTab === 'ingresar' && (
                    <TabsContent value="ingresar" forceMount>
                        <motion.div
                            key="ingresar"
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -10 }}
                            transition={{ duration: 0.2 }}
                        >
                            <EntryForm />
                        </motion.div>
                    </TabsContent>
                )}
                
                {canViewAll && currentTab === 'exportar' && (
                    <TabsContent value="exportar" forceMount>
                        <motion.div
                            key="exportar"
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -10 }}
                            transition={{ duration: 0.2 }}
                        >
                            <ExportSection {...commonSheetProps} />
                        </motion.div>
                    </TabsContent>
                )}

                {canViewAll && currentTab === 'visualizar' && (
                    <TabsContent value="visualizar" forceMount>
                        <motion.div
                            key="visualizar"
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -10 }}
                            transition={{ duration: 0.2 }}
                        >
                            <ViewSheetSection {...commonSheetProps} />
                        </motion.div>
                    </TabsContent>
                )}
            </AnimatePresence>
        </div>
      </Tabs>
    </motion.div>
  );
};

export default SafeBoxPage;