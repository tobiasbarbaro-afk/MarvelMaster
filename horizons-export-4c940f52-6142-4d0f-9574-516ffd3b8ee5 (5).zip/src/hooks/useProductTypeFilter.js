import { useState, useCallback, useMemo } from 'react';
import { useAuth } from '@/hooks/useAuth';

export const useProductTypeFilter = () => {
    const { userRole, userProfile } = useAuth();
    const [selectedType, setSelectedType] = useState('Productos'); // 'Productos' | 'Insumos'

    const shouldShowTypeSelector = useMemo(() => {
        if (userRole !== 'cocina') return false;
        const branchId = userProfile?.sucursal_id;
        return [8, 17, 15].includes(Number(branchId));
    }, [userRole, userProfile]);

    const filterRubrosByType = useCallback((productos, insumos, type) => {
        if (type === 'Productos') {
            return [...new Set(productos.map(p => p.Rubro).filter(Boolean))].sort();
        } else {
            return [...new Set(insumos.map(i => i.Rubro).filter(Boolean))].sort();
        }
    }, []);

    const getFilteredItems = useCallback((productos, insumos, type) => {
        return type === 'Productos' ? productos : insumos;
    }, []);

    return {
        selectedType,
        setSelectedType,
        shouldShowTypeSelector,
        filterRubrosByType,
        getFilteredItems
    };
};