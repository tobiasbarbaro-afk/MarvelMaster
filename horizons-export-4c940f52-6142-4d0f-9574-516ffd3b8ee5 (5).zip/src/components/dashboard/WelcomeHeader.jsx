import React from 'react';
import { useAuth } from '@/hooks/useAuth';

const WelcomeHeader = () => {
  const { userProfile } = useAuth();
  const displayName = userProfile?.full_name || userProfile?.username || 'Usuario';

  return (
    <div className="bg-primary text-primary-foreground p-6 rounded-lg mb-6 shadow-lg">
      <h1 className="text-3xl font-bold">¡Bienvenido, {displayName}!</h1>
      <p className="text-lg opacity-90">Panel de Control de MarvelMaster.</p>
    </div>
  );
};

export default WelcomeHeader;