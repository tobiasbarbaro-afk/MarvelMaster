import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { DollarSign, FileText, Building, Users } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

const QuickAccess = () => {
    const { userRole } = useAuth();

    const links = [
        { to: '/daily-entry', icon: <DollarSign className="w-5 h-5 mr-2"/>, label: 'Entrada Diaria', roles: ['admin', 'gerente', 'empleado'] },
        { to: '/invoice-processing', icon: <FileText className="w-5 h-5 mr-2"/>, label: 'Procesar Docs', roles: ['admin', 'gerente', 'empleado'] },
        { to: '/branches', icon: <Building className="w-5 h-5 mr-2"/>, label: 'Sucursales', roles: ['admin'] },
        { to: '/suppliers', icon: <Users className="w-5 h-5 mr-2"/>, label: 'Proveedores', roles: ['admin'] },
    ];

    const availableLinks = links.filter(link => link.roles.includes(userRole));

    return (
        <div className="mb-6">
            <h2 className="text-xl font-semibold mb-3">Accesos Rápidos</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {availableLinks.map(link => (
                     <Button key={link.to} asChild variant="outline" className="justify-start text-left h-12">
                        <Link to={link.to}>
                            {link.icon}
                            <span>{link.label}</span>
                        </Link>
                    </Button>
                ))}
            </div>
        </div>
    );
};

export default QuickAccess;