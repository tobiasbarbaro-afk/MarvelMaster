import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, AlertCircle, ArrowRight, ShieldAlert } from 'lucide-react';
import { Link } from 'react-router-dom';

const UnverifiedClosings = ({ selectedBranchId, excludedBranches = [] }) => {
  const [count, setCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [unverifiedItems, setUnverifiedItems] = useState([]);

  useEffect(() => {
    const fetchUnverified = async () => {
      setLoading(true);
      try {
        let query = supabase
          .from('cierres_caja')
          .select(`id, fecha, turno, sucursal_id, sucursales ( nombre ), user_profiles ( full_name )`)
          .eq('verificado_por_gerencia', false); // Estrictamente pendientes de Gerencia

        if (selectedBranchId && selectedBranchId !== 'all') {
          query = query.eq('sucursal_id', selectedBranchId);
        }

        const { data, error } = await query;
        if (error) throw error;

        // Filter out excluded branches
        const filteredData = (data || []).filter(item => 
            !excludedBranches.includes(item.sucursales?.nombre)
        );

        setUnverifiedItems(filteredData);
        setCount(filteredData.length);
      } catch (error) {
        console.error('Error fetching unverified closings:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchUnverified();
  }, [selectedBranchId, excludedBranches]);

  if (loading) return <Card><CardHeader><Loader2 className="animate-spin" /></CardHeader></Card>;

  return (
    <Card className={count > 0 ? "border-l-4 border-l-yellow-500" : ""}>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-medium flex items-center justify-between">
          <div className="flex items-center gap-2">
             <AlertCircle className={`h-5 w-5 ${count > 0 ? "text-yellow-500" : "text-muted-foreground"}`} />
             Pendientes de Gerencia
          </div>
          <span className={`text-2xl font-bold ${count > 0 ? "text-yellow-600" : "text-muted-foreground"}`}>{count}</span>
        </CardTitle>
        <CardDescription>Cierres que requieren impacto en planilla.</CardDescription>
      </CardHeader>
      <CardContent>
        {count > 0 ? (
          <div className="space-y-4">
             <div className="space-y-2">
                {unverifiedItems.slice(0, 3).map(item => (
                    <div key={item.id} className="text-sm border-b pb-2 last:border-0">
                        <div className="flex justify-between font-medium">
                            <span>{new Date(item.fecha).toLocaleDateString()} - {item.turno}</span>
                            <span className="text-xs bg-muted px-1 rounded">{item.sucursales?.nombre}</span>
                        </div>
                    </div>
                ))}
             </div>
             <Button asChild className="w-full" variant="outline" size="sm">
                <Link to="/management">Ir a Verificar <ArrowRight className="ml-2 h-4 w-4" /></Link>
             </Button>
          </div>
        ) : (
          <div className="text-center py-6 text-muted-foreground">
            <ShieldAlert className="h-8 w-8 mb-2 opacity-20 mx-auto" />
            <p className="text-sm">Sin pendientes</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default UnverifiedClosings;