import React, { useState, useEffect, useCallback } from 'react';
    import { supabase } from '@/lib/supabaseClient';
    import { useAuth } from '@/hooks/useAuth';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Loader2, Check, Eye, Bike, Paperclip } from 'lucide-react';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
    import { useToast } from '@/components/ui/use-toast';
    import { formatDateForDisplay } from '@/lib/sheetUtils';

    const PendingCadetPayments = ({ selectedBranchId, excludedBranches = [] }) => {
      const { userRole } = useAuth();
      const { toast } = useToast();

      const [pendingPayments, setPendingPayments] = useState([]);
      const [loading, setLoading] = useState(true);
      const [selectedPayment, setSelectedPayment] = useState(null);
      const [isDetailOpen, setIsDetailOpen] = useState(false);
      const [isProcessing, setIsProcessing] = useState(false);

      const fetchPendingPayments = useCallback(async () => {
        setLoading(true);
        let query = supabase
          .from('pagos_cadetes')
          .select('*, sucursales(nombre), user_profiles(full_name)')
          .eq('estado', 'pendiente de verificación')
          .order('fecha_pago', { ascending: true });

        if (selectedBranchId && selectedBranchId !== 'all') {
          query = query.eq('sucursal_id', selectedBranchId);
        }

        const { data, error } = await query;

        if (error) {
          toast({ variant: 'destructive', title: 'Error', description: 'No se pudieron cargar los pagos de cadetes pendientes.' });
        } else {
          // Filter out excluded branches
          const filteredData = (data || []).filter(payment => 
            !excludedBranches.includes(payment.sucursales?.nombre)
          );
          setPendingPayments(filteredData);
        }
        setLoading(false);
      }, [toast, selectedBranchId, excludedBranches]);

      useEffect(() => {
        if (userRole === 'admin') {
          fetchPendingPayments();
          
          const channel = supabase.channel(`pagos_cadetes_changes_sup_${selectedBranchId || 'all'}`)
            .on('postgres_changes', { event: '*', schema: 'public', table: 'pagos_cadetes' }, payload => {
              fetchPendingPayments();
            })
            .subscribe();

          return () => {
            supabase.removeChannel(channel);
          };
        }
      }, [userRole, fetchPendingPayments, selectedBranchId]);

      const handleViewDetail = (payment) => {
        setSelectedPayment(payment);
        setIsDetailOpen(true);
      };

      const handleVerify = async () => {
        if (!selectedPayment) return;
        setIsProcessing(true);
        const { error } = await supabase
          .from('pagos_cadetes')
          .update({ estado: 'verificado' })
          .eq('id', selectedPayment.id);
        
        if (error) {
          toast({ variant: 'destructive', title: 'Error', description: 'No se pudo verificar el lote de pagos.' });
        } else {
          toast({ title: 'Éxito', description: 'Lote de pagos de cadetes verificado.' });
          fetchPendingPayments();
          setIsDetailOpen(false);
        }
        setIsProcessing(false);
      };

      if (userRole !== 'admin') {
        return null;
      }

      return (
        <Card className="shadow-lg border-border h-full flex flex-col">
          <CardHeader>
            <CardTitle className="text-xl font-semibold text-primary flex items-center">
              <Bike className="w-6 h-6 mr-2 text-green-500" />
              Pagos de Cadetes Pendientes
            </CardTitle>
            <CardDescription className="text-sm">
              Lotes de pagos de cadetes que requieren verificación.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex-grow flex flex-col p-0">
            <div className="flex-grow overflow-y-auto">
              {loading ? (
                <div className="flex justify-center items-center h-full py-10">
                  <Loader2 className="h-6 w-6 animate-spin text-primary" />
                </div>
              ) : pendingPayments.length === 0 ? (
                <div className="text-center py-10 px-4">
                  <Check className="mx-auto h-12 w-12 text-green-500" />
                  <p className="mt-4 text-sm font-medium text-muted-foreground">¡Todo en orden!</p>
                  <p className="text-xs text-muted-foreground">No hay pagos de cadetes pendientes de verificar.</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-xs">Fecha</TableHead>
                      <TableHead className="text-xs">Sucursal</TableHead>
                      <TableHead className="text-right text-xs">Acción</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pendingPayments.map((payment) => (
                      <TableRow key={payment.id} className="hover:bg-muted/50">
                        <TableCell className="text-sm font-medium">{formatDateForDisplay(payment.fecha_pago)}</TableCell>
                        <TableCell className="text-xs">{payment.sucursales?.nombre || 'N/A'}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="outline" size="xs" onClick={() => handleViewDetail(payment)}>
                            <Eye className="h-3 w-3 mr-1" /> Ver
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </div>
          </CardContent>

          {selectedPayment && (
            <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
              <DialogContent className="sm:max-w-4xl">
                <DialogHeader>
                  <DialogTitle>Detalle del Lote de Pago de Cadetes</DialogTitle>
                  <DialogDescription>
                    Revisa los pagos para {selectedPayment.sucursales?.nombre} del {formatDateForDisplay(selectedPayment.fecha_pago)}. Procesado por: {selectedPayment.user_profiles?.full_name || 'N/A'}.
                  </DialogDescription>
                </DialogHeader>
                <div className="py-4 max-h-[70vh] overflow-y-auto">
                    <div className="flex justify-between items-center mb-4">
                        <div>
                            <span className="font-semibold">Total del Lote: </span>
                            <span className="text-lg font-bold text-primary">${parseFloat(selectedPayment.total_pagado).toLocaleString('es-AR', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                        </div>
                        {selectedPayment.advertencia && (
                             <a href={selectedPayment.advertencia} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-blue-500 hover:underline">
                                <Paperclip className="h-4 w-4" />
                                Ver Recibo del Bloque
                            </a>
                        )}
                    </div>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Nombre</TableHead>
                                <TableHead>Monto</TableHead>
                                <TableHead>Ad. Piso</TableHead>
                                <TableHead>Extras</TableHead>
                                <TableHead>Desc.</TableHead>
                                <TableHead>Total</TableHead>
                                <TableHead>Justificación</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {selectedPayment.pagos_individuales.map((p, i) => (
                                <TableRow key={`${selectedPayment.id}-detail-${i}`}>
                                    <TableCell>{p.nombre}</TableCell>
                                    <TableCell>${parseFloat(p.monto || 0).toLocaleString('es-AR')}</TableCell>
                                    <TableCell>${parseFloat(p.ad_piso || 0).toLocaleString('es-AR')}</TableCell>
                                    <TableCell>${parseFloat(p.extras || 0).toLocaleString('es-AR')}</TableCell>
                                    <TableCell>${parseFloat(p.descuentos || 0).toLocaleString('es-AR')}</TableCell>
                                    <TableCell className="font-bold">${parseFloat(p.total_a_pagar).toLocaleString('es-AR')}</TableCell>
                                    <TableCell>{p.justificacion}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsDetailOpen(false)}>Cerrar</Button>
                  <Button onClick={handleVerify} disabled={isProcessing}>
                    {isProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Check className="mr-2 h-4 w-4" />}
                    Pagos Verificados
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </Card>
      );
    };

    export default PendingCadetPayments;