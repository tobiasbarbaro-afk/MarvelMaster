import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Loader2, CalendarDays, User, BarChartBig } from 'lucide-react';
import { Label } from '@/components/ui/label';

const ALL_SUPPLIERS_VALUE = "ALL_SUPPLIERS";
const ALL_WEEKS_VALUE = "ALL_WEEKS";

const getWeekNumber = (date) => {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  return weekNo;
};

const getWeekRangeString = (year, weekNumber) => {
  const firstDayOfYear = new Date(year, 0, 1);
  const days = (weekNumber - 1) * 7;
  
  let startDate = new Date(firstDayOfYear.setDate(firstDayOfYear.getDate() + days));
  
  const dayOfWeek = startDate.getDay();
  const diffToMonday = dayOfWeek === 0 ? -6 : 1 - dayOfWeek; 
  startDate.setDate(startDate.getDate() + diffToMonday);

  const endDate = new Date(startDate);
  endDate.setDate(startDate.getDate() + 6);

  const options = { month: 'short', day: 'numeric' };
  return `${startDate.toLocaleDateString('es-AR', options)} - ${endDate.toLocaleDateString('es-AR', options)}, ${year}`;
};


const WeeklyInvoiceSummary = () => {
  const [summaryData, setSummaryData] = useState([]);
  const [allSuppliers, setAllSuppliers] = useState([]);
  const [availableWeeks, setAvailableWeeks] = useState([]);
  
  const [selectedSupplier, setSelectedSupplier] = useState(ALL_SUPPLIERS_VALUE); 
  const [selectedWeek, setSelectedWeek] = useState(ALL_WEEKS_VALUE); 

  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchWeeklySummary = useCallback(async () => {
    setLoading(true);
    try {
      const { data: facturas, error } = await supabase
        .from('facturas')
        .select('fecha, monto, proveedor_id, suppliers(name), orden_compra_id, pdf_fusionado_url, verificado')
        .not('orden_compra_id', 'is', null)
        .not('pdf_fusionado_url', 'is', null)
        .eq('verificado', true);

      if (error) {
        throw error;
      }
      
      const supplierMap = new Map();
      const weekSet = new Set();

      const processedFacturas = facturas.map(f => {
        const date = new Date(f.fecha + 'T00:00:00Z'); 
        const year = date.getUTCFullYear();
        const week = getWeekNumber(date);
        const weekId = `${year}-W${week.toString().padStart(2, '0')}`;
        weekSet.add(weekId);
        
        if (f.suppliers && !supplierMap.has(f.proveedor_id)) {
          supplierMap.set(f.proveedor_id, f.suppliers.name);
        }
        
        return {
          ...f,
          weekId,
          year,
          week,
          supplierName: f.suppliers ? f.suppliers.name : 'Proveedor Desconocido',
        };
      });
      
      const sortedWeeks = Array.from(weekSet).sort((a,b) => b.localeCompare(a)); 
      setAvailableWeeks(sortedWeeks.map(weekId => {
        const [year, weekNumStr] = weekId.split('-W');
        return {
          id: weekId,
          name: getWeekRangeString(parseInt(year), parseInt(weekNumStr))
        };
      }));
      
      setAllSuppliers(Array.from(supplierMap.entries()).map(([id, name]) => ({ id: id.toString(), name })).sort((a,b) => a.name.localeCompare(b.name)));

      const grouped = processedFacturas.reduce((acc, curr) => {
        const key = `${curr.weekId}-${curr.proveedor_id}`;
        if (!acc[key]) {
          acc[key] = {
            weekId: curr.weekId,
            year: curr.year,
            weekNumber: curr.week,
            weekDisplay: getWeekRangeString(curr.year, curr.week),
            proveedorId: curr.proveedor_id,
            proveedorName: curr.supplierName,
            totalMonto: 0,
          };
        }
        acc[key].totalMonto += curr.monto;
        return acc;
      }, {});
      
      setSummaryData(Object.values(grouped).sort((a,b) => b.weekId.localeCompare(a.weekId) || a.proveedorName.localeCompare(b.proveedorName)));

    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Error al cargar resumen semanal',
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchWeeklySummary();
  }, [fetchWeeklySummary]);

  const filteredData = useMemo(() => {
    return summaryData.filter(item => {
      const supplierMatch = selectedSupplier === ALL_SUPPLIERS_VALUE || item.proveedorId.toString() === selectedSupplier;
      const weekMatch = selectedWeek === ALL_WEEKS_VALUE || item.weekId === selectedWeek;
      return supplierMatch && weekMatch;
    });
  }, [summaryData, selectedSupplier, selectedWeek]);

  return (
    <Card className="shadow-lg border-border h-full flex flex-col">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-primary flex items-center">
            <BarChartBig className="w-6 h-6 mr-2 text-indigo-400"/>
            Resumen Semanal
        </CardTitle>
        <CardDescription className="text-sm">
          Facturas verificadas y asociadas.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex-grow flex flex-col">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
            <div>
                <Label htmlFor="supplier-filter-summary" className="text-xs">Proveedor</Label>
                <Select value={selectedSupplier} onValueChange={setSelectedSupplier}>
                    <SelectTrigger id="supplier-filter-summary" className="h-9">
                        <SelectValue placeholder="Todos" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value={ALL_SUPPLIERS_VALUE}>Todos</SelectItem>
                        {allSuppliers.map(supplier => (
                            <SelectItem key={supplier.id} value={supplier.id.toString()}>{supplier.name}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>
            <div>
                <Label htmlFor="week-filter-summary" className="text-xs">Semana</Label>
                <Select value={selectedWeek} onValueChange={setSelectedWeek}>
                    <SelectTrigger id="week-filter-summary" className="h-9">
                        <SelectValue placeholder="Todas" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value={ALL_WEEKS_VALUE}>Todas</SelectItem>
                        {availableWeeks.map(week => (
                            <SelectItem key={week.id} value={week.id}>{week.name}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>
        </div>

        <div className="flex-grow overflow-y-auto">
            {loading ? (
            <div className="flex justify-center items-center h-full">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
            ) : filteredData.length === 0 ? (
            <p className="text-center text-muted-foreground py-6 text-sm">
                No hay datos para los filtros seleccionados.
            </p>
            ) : (
            <Table>
                <TableHeader>
                <TableRow>
                    <TableHead className="text-xs">Semana</TableHead>
                    <TableHead className="text-xs">Proveedor</TableHead>
                    <TableHead className="text-right text-xs">Total</TableHead>
                </TableRow>
                </TableHeader>
                <TableBody>
                {filteredData.map((item, index) => (
                    <TableRow key={`${item.weekId}-${item.proveedorId}-${index}`} className="hover:bg-muted/50">
                    <TableCell className="text-sm">{item.weekDisplay}</TableCell>
                    <TableCell className="text-sm">{item.proveedorName}</TableCell>
                    <TableCell className="text-right font-medium text-sm">
                        ${item.totalMonto.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </TableCell>
                    </TableRow>
                ))}
                </TableBody>
            </Table>
            )}
        </div>
      </CardContent>
    </Card>
  );
};

export default WeeklyInvoiceSummary;