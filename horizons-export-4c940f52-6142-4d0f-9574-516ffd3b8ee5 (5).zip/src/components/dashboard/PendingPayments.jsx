import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Loader2, Check, Eye, WalletCards, MessageSquarePlus } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { formatDateForDisplay } from '@/lib/sheetUtils';

const PendingPayments = ({ selectedBranchId, excludedBranches = [] }) => {
  const { userRole, user } = useAuth();
  const { toast } = useToast();

  const [pendingPayments, setPendingPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedPayment, setSelectedPayment] = useState(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [clarificationMsg, setClarificationMsg] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const fetchPendingPayments = useCallback(async () => {
    setLoading(true);
    let query = supabase
      .from('pagos_empleados')
      .select('*, sucursales(nombre), user_profiles(full_name)')
      .eq('estado', 'pendiente de verificación')
      .order('fecha_pago', { ascending: true });

    if (selectedBranchId && selectedBranchId !== 'all') {
      query = query.eq('sucursal_id', selectedBranchId);
    }

    const { data, error } = await query;

    if (error) {
      toast({ variant: 'destructive', title: 'Error', description: 'No se pudieron cargar los pagos pendientes.' });
      setPendingPayments([]);
    } else {
      // Filter out excluded branches
      const filteredData = (data || []).filter(payment => 
          !excludedBranches.includes(payment.sucursales?.nombre)
      );
      setPendingPayments(filteredData);
    }
    setLoading(false);
  }, [toast, selectedBranchId, excludedBranches]);

  useEffect(() => {
    if (userRole === 'admin') {
      fetchPendingPayments();
    }
  }, [userRole, fetchPendingPayments]);

  const handleViewDetail = (payment) => {
    setSelectedPayment(payment);
    setClarificationMsg('');
    setIsDetailOpen(true);
  };

  const handleVerify = async () => {
    if (!selectedPayment) return;
    setIsProcessing(true);
    const { error } = await supabase
      .from('pagos_empleados')
      .update({ estado: 'verificado', advertencia: null })
      .eq('id', selectedPayment.id);
    
    if (error) {
      toast({ variant: 'destructive', title: 'Error', description: 'No se pudo verificar el lote de pagos.' });
    } else {
      toast({ title: 'Éxito', description: 'Lote de pagos verificado.' });
      fetchPendingPayments();
      setIsDetailOpen(false);
    }
    setIsProcessing(false);
  };

  const handleRequestClarification = async () => {
    if (!selectedPayment || !clarificationMsg.trim()) {
        toast({ variant: 'destructive', title: 'Error', description: 'El mensaje de aclaración no puede estar vacío.' });
        return;
    }
    setIsProcessing(true);
    
    const { error: clarificationError } = await supabase.from('aclaraciones_pagos').insert({
        pago_id: selectedPayment.id,
        solicitado_por_id: user.id,
        dirigido_a_id: selectedPayment.usuario_id,
        mensaje_solicitud: clarificationMsg.trim(),
        estado: 'pendiente_respuesta'
    });

    if (clarificationError) {
        toast({ variant: 'destructive', title: 'Error', description: 'No se pudo enviar la solicitud de aclaración.' });
        setIsProcessing(false);
        return;
    }

    const { error: updateError } = await supabase
        .from('pagos_empleados')
        .update({ advertencia: `Aclaración solicitada: ${clarificationMsg.trim()}` })
        .eq('id', selectedPayment.id);
    
    if (updateError) {
        toast({ variant: 'destructive', title: 'Error', description: 'No se pudo actualizar el estado del pago.' });
    } else {
        toast({ title: 'Éxito', description: 'Solicitud de aclaración enviada.' });
        fetchPendingPayments();
        setIsDetailOpen(false);
    }
    setIsProcessing(false);
  };

  if (userRole !== 'admin') {
    return null;
  }

  return (
    <Card className="shadow-lg border-border h-full flex flex-col">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-primary flex items-center">
          <WalletCards className="w-6 h-6 mr-2 text-blue-400" />
          Pagos de Empleados Pendientes
        </CardTitle>
        <CardDescription className="text-sm">
          Lotes de pagos de empleados que requieren verificación.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex-grow flex flex-col p-0">
        <div className="flex-grow overflow-y-auto">
          {loading ? (
            <div className="flex justify-center items-center h-full py-10">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
          ) : pendingPayments.length === 0 ? (
            <div className="text-center py-10 px-4">
              <Check className="mx-auto h-12 w-12 text-green-500" />
              <p className="mt-4 text-sm font-medium text-muted-foreground">¡Todo en orden!</p>
              <p className="text-xs text-muted-foreground">No hay pagos de empleados pendientes de verificar.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-xs">Fecha</TableHead>
                  <TableHead className="text-xs">Sucursal</TableHead>
                  <TableHead className="text-right text-xs">Acción</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingPayments.map((payment) => (
                  <TableRow key={payment.id} className="hover:bg-muted/50">
                    <TableCell className="text-sm font-medium">{formatDateForDisplay(payment.fecha_pago)}</TableCell>
                    <TableCell className="text-xs">{payment.sucursales?.nombre || 'N/A'}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="xs" onClick={() => handleViewDetail(payment)}>
                        <Eye className="h-3 w-3 mr-1" /> Ver
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </div>
      </CardContent>

      {selectedPayment && (
        <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
          <DialogContent className="sm:max-w-6xl">
            <DialogHeader>
              <DialogTitle>Detalle del Lote de Pago</DialogTitle>
              <DialogDescription>
                Revisa los pagos para {selectedPayment.sucursales?.nombre} del {formatDateForDisplay(selectedPayment.fecha_pago)}. Procesado por: {selectedPayment.user_profiles?.full_name || 'N/A'}.
              </DialogDescription>
            </DialogHeader>
            <div className="py-4 max-h-[70vh] overflow-y-auto">
                <div className="mb-4">
                    <span className="font-semibold">Total del Lote: </span>
                    <span className="text-lg font-bold text-primary">${parseFloat(selectedPayment.total_pagado).toLocaleString('es-AR', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                </div>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Empleado</TableHead>
                            <TableHead>Puesto</TableHead>
                            <TableHead>Horas</TableHead>
                            <TableHead>Efectivo</TableHead>
                            <TableHead>Transf.</TableHead>
                            <TableHead>Extras</TableHead>
                            <TableHead>Desc.</TableHead>
                            <TableHead>Total</TableHead>
                            <TableHead>Detalle</TableHead>
                            <TableHead>Recibo</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {selectedPayment.pagos_individuales.map((p, i) => (
                            <TableRow key={`${selectedPayment.id}-detail-${i}`}>
                                <TableCell>{p.nombre_completo}</TableCell>
                                <TableCell>{p.puesto}</TableCell>
                                <TableCell>{p.tipo_pago === 'Por hora' ? p.horas_trabajadas : 'N/A'}</TableCell>
                                <TableCell>${parseFloat(p.efectivo || 0).toLocaleString('es-AR')}</TableCell>
                                <TableCell>${parseFloat(p.transferencia || 0).toLocaleString('es-AR')}</TableCell>
                                <TableCell>${parseFloat(p.extras || 0).toLocaleString('es-AR')}</TableCell>
                                <TableCell>${parseFloat(p.descuentos || 0).toLocaleString('es-AR')}</TableCell>
                                <TableCell className="font-bold">${parseFloat(p.total_a_pagar).toLocaleString('es-AR')}</TableCell>
                                <TableCell>{p.detalle}</TableCell>
                                <TableCell>
                                    <a href={p.recibo_url} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">Ver</a>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>

              <div className="mt-6">
                <Label htmlFor="clarification-msg">Solicitar Aclaración (Opcional)</Label>
                <Textarea
                  id="clarification-msg"
                  placeholder="Escribe un mensaje para el usuario que procesó el pago..."
                  value={clarificationMsg}
                  onChange={(e) => setClarificationMsg(e.target.value)}
                  className="mt-2"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDetailOpen(false)}>Cerrar</Button>
              <Button onClick={handleRequestClarification} disabled={isProcessing || !clarificationMsg.trim()}>
                {isProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <MessageSquarePlus className="mr-2 h-4 w-4" />}
                Solicitar Aclaración
              </Button>
              <Button onClick={handleVerify} disabled={isProcessing}>
                {isProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Check className="mr-2 h-4 w-4" />}
                Pagos Verificados
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </Card>
  );
};

export default PendingPayments;