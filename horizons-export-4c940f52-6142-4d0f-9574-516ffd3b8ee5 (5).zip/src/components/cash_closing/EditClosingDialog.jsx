import React, { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, Save, Upload, CheckCircle, Trash2 } from 'lucide-react';
import { normalizeAmountString, formatDateForDB, formatDateForDisplay } from '@/lib/sheetUtils';
import { paymentMethods } from './ClosingForm';
import { useAuth } from '@/hooks/useAuth';
import { useBranch } from '@/contexts/BranchContext';
import { calculateAndSaveCurrentMonthBalance } from '@/services/balanceService';
import { logModificationAndNotify } from '@/lib/modificationLogger';

const PELLEGRINI_SUCURSAL_ID = 5;

const EditClosingDialog = ({ record, isOpen, onClose, onRecordUpdate }) => {
  const { toast } = useToast();
  const { user, userRole } = useAuth();
  const { getBranchNameById } = useBranch();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [values, setValues] = useState({});
  const [fotoPosnet, setFotoPosnet] = useState(null);
  const [fotoJarvis, setFotoJarvis] = useState(null);
  const [totalFacturado, setTotalFacturado] = useState('');

  useEffect(() => {
    if (record) {
      const initialValues = {
        mostrador: record.valores_ingresados.mostrador || {},
        cadetes: record.valores_ingresados.cadetes || {},
        salon: record.valores_ingresados.salon || {},
      };
      setValues(initialValues);
      setTotalFacturado(record.total_facturado?.toString() || '');
    }
  }, [record]);

  const handleValueChange = (channel, method, value) => {
    setValues(prev => ({
      ...prev,
      [channel]: { ...prev[channel], [method]: value },
    }));
  };

  const totals = useMemo(() => {
    if (!values.mostrador || !values.cadetes) return { totalEfectivo: 0, totalElectronico: 0, totalGeneral: 0, totalMpCadetes: 0, totalMpMostrador: 0 };
    
    const getNumericValue = (val) => parseFloat(normalizeAmountString(val)) || 0;
    const mostrador = values.mostrador;
    const cadetes = values.cadetes;
    const salon = record?.sucursal_id === PELLEGRINI_SUCURSAL_ID ? values.salon : {};

    const totalEfectivo = getNumericValue(mostrador.efectivo) + getNumericValue(cadetes.efectivo) +
                           getNumericValue(mostrador.pedidosYaEfectivo) + getNumericValue(cadetes.pedidosYaEfectivo) +
                           (getNumericValue(salon?.efectivo) || 0) + (getNumericValue(salon?.pedidosYaEfectivo) || 0);

    const totalMpCadetes = getNumericValue(cadetes.mercadoPagoLink);
    
    const totalMpMostrador = 
        getNumericValue(mostrador.mercadoPagoQR) +
        getNumericValue(mostrador.mercadoPagoCredito) +
        getNumericValue(mostrador.mercadoPagoDebito) +
        getNumericValue(mostrador.transferencia) +
        (getNumericValue(salon?.mercadoPagoQR) || 0) +
        (getNumericValue(salon?.mercadoPagoCredito) || 0) +
        (getNumericValue(salon?.mercadoPagoDebito) || 0) +
        (getNumericValue(salon?.transferencia) || 0);
    
    const totalElectronico = paymentMethods
      .filter(m => m.id !== 'efectivo' && m.id !== 'pedidosYaEfectivo')
      .reduce((sum, method) => {
          let channelSum = getNumericValue(mostrador[method.id]) + getNumericValue(cadetes[method.id]);
          if (record?.sucursal_id === PELLEGRINI_SUCURSAL_ID) {
            channelSum += (getNumericValue(salon?.[method.id]) || 0);
          }
          return sum + channelSum;
      }, 0);

    const totalGeneral = totalEfectivo + totalElectronico;

    return { totalEfectivo, totalElectronico, totalGeneral, totalMpCadetes, totalMpMostrador };
  }, [values, record]);

  const uploadFile = async (file, sucursalId, fecha, turno, type) => {
    if (!file) return null;
    const fileName = `${type}-${Date.now()}.${file.name.split('.').pop()}`;
    const filePath = `cierres_caja/${sucursalId}/${formatDateForDB(fecha)}/${turno}/${fileName}`;
    
    const { error: deleteError } = await supabase.storage.from('cierre-caja-imagenes').remove([`cierres_caja/${sucursalId}/${formatDateForDB(fecha)}/${turno}/${type}`]);

    const { error } = await supabase.storage.from('cierre-caja-imagenes').upload(filePath, file);
    if (error) throw new Error(`Error al subir ${type}: ${error.message}`);
    
    const { data } = supabase.storage.from('cierre-caja-imagenes').getPublicUrl(filePath);
    return data.publicUrl;
  };

  const handleDelete = async () => {
    if (userRole !== 'admin') {
      toast({ variant: 'destructive', title: 'Acción no permitida', description: 'Solo los administradores pueden eliminar cierres.' });
      return;
    }
    setIsDeleting(true);
    try {
      const { data: dailyEntry, error: findError } = await supabase
        .from('entradas_diarias')
        .select('id')
        .eq('sucursal_id', record.sucursal_id)
        .eq('fecha', formatDateForDB(record.fecha))
        .eq('tipo_ioe', `Cierre de Caja ${record.turno}`)
        .limit(1)
        .single();

      if (findError && findError.code !== 'PGRST116') {
        throw new Error(`Error buscando la entrada diaria asociada: ${findError.message}`);
      }

      if (dailyEntry) {
         const { error: deleteEntryError } = await supabase
            .from('entradas_diarias')
            .delete()
            .eq('id', dailyEntry.id);
         if (deleteEntryError) throw new Error(`Error eliminando entrada diaria: ${deleteEntryError.message}`);
      }

      const { error: deleteClosingError } = await supabase
          .from('cierres_caja')
          .delete()
          .eq('id', record.id);
      
      if (deleteClosingError) throw new Error(`Error eliminando cierre de caja: ${deleteClosingError.message}`);

      const monthYear = record.fecha.slice(0, 7);
      await calculateAndSaveCurrentMonthBalance(record.sucursal_id, monthYear, user.email);
      await logModificationAndNotify(supabase, toast, getBranchNameById, record.sucursal_id, monthYear, user.email, 'eliminacion_cierre_caja');

      toast({ title: 'Eliminado', description: 'Cierre de caja eliminado correctamente.' });
      onRecordUpdate(); 
      onClose(); 
    } catch (error) {
      console.error("Error deleting closing:", error);
      toast({ variant: 'destructive', title: 'Error', description: error.message });
    } finally {
      setIsDeleting(false);
    }
  }

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      let url_foto_posnet = record.url_foto_posnet;
      if (fotoPosnet) {
        url_foto_posnet = await uploadFile(fotoPosnet, record.sucursal_id, record.fecha, record.turno, 'posnet');
      }

      let url_foto_jarvis = record.url_foto_jarvis;
      if (fotoJarvis) {
        url_foto_jarvis = await uploadFile(fotoJarvis, record.sucursal_id, record.fecha, record.turno, 'jarvis');
      }

      const updatedCierreData = {
        valores_ingresados: values,
        total_efectivo: totals.totalEfectivo,
        total_mp_cadetes: totals.totalMpCadetes,
        total_mp_mostrador: totals.totalMpMostrador,
        total_electronico: totals.totalElectronico,
        total_general: totals.totalGeneral,
        url_foto_posnet,
        url_foto_jarvis,
        total_facturado: parseFloat(normalizeAmountString(totalFacturado)) || 0,
      };

      const { error: cierreError } = await supabase
        .from('cierres_caja')
        .update(updatedCierreData)
        .eq('id', record.id);

      if (cierreError) throw new Error(`Error al actualizar el cierre: ${cierreError.message}`);

      const { data: dailyEntry, error: findError } = await supabase
        .from('entradas_diarias')
        .select('id')
        .eq('sucursal_id', record.sucursal_id)
        .eq('fecha', formatDateForDB(record.fecha))
        .eq('tipo_ioe', `Cierre de Caja ${record.turno}`)
        .limit(1)
        .single();

      if (findError && findError.code !== 'PGRST116') { 
        throw new Error(`Error buscando la entrada diaria: ${findError.message}`);
      }

      if (dailyEntry) {
        const updatedEntradaData = {
          monto: totals.totalGeneral,
          observaciones: `Cierre de caja automático del turno ${record.turno}. Efectivo: ${totals.totalEfectivo.toLocaleString('es-AR', { style: 'currency', currency: 'ARS' })}, Electrónico: ${totals.totalElectronico.toLocaleString('es-AR', { style: 'currency', currency: 'ARS' })}`,
          debe: totals.totalEfectivo,
        };
        const { error: updateEntradaError } = await supabase
          .from('entradas_diarias')
          .update(updatedEntradaData)
          .eq('id', dailyEntry.id);
        if (updateEntradaError) throw new Error(`Error actualizando la entrada diaria: ${updateEntradaError.message}`);
      }

      const monthYear = record.fecha.slice(0, 7);
      await calculateAndSaveCurrentMonthBalance(record.sucursal_id, monthYear, user.email);
      await logModificationAndNotify(supabase, toast, getBranchNameById, record.sucursal_id, monthYear, user.email, 'edicion_cierre_caja');

      toast({ title: 'Éxito', description: 'Cierre de caja actualizado correctamente.' });
      onRecordUpdate();
      onClose();
    } catch (error) {
      console.error("Error updating closing:", error);
      toast({ variant: 'destructive', title: 'Error', description: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!record || !values.mostrador) return null;

  const channels = ['mostrador'];
  if (record.sucursal_id === PELLEGRINI_SUCURSAL_ID) {
    channels.push('salon');
  }
  channels.push('cadetes');

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Editar Cierre de Caja</DialogTitle>
          <DialogDescription>
            Modifique los valores del cierre del {formatDateForDisplay(record.fecha)} - Turno {record.turno}.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4 max-h-[70vh] overflow-y-auto pr-2">
          {channels.map(channel => (
            <div key={channel} className="space-y-2">
              <h4 className="font-semibold capitalize text-primary">{channel}</h4>
              <div className="grid grid-cols-2 gap-2">
                {paymentMethods.map(method => (
                  <div key={method.id}>
                    <Label htmlFor={`${channel}-${method.id}`}>{method.label}</Label>
                    <Input
                      id={`${channel}-${method.id}`}
                      value={values[channel]?.[method.id] || ''}
                      onChange={(e) => handleValueChange(channel, method.id, e.target.value)}
                      placeholder="0.00"
                    />
                  </div>
                ))}
              </div>
            </div>
          ))}
          <div className="mt-4">
            <Label htmlFor="totalFacturado">Total Facturado</Label>
            <Input
              id="totalFacturado"
              type="text"
              value={totalFacturado}
              onChange={(e) => setTotalFacturado(e.target.value)}
              placeholder="0.00"
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
            <div>
              <Label htmlFor="fotoPosnet" className="flex items-center gap-2">
                <Upload className="w-4 h-4"/> Cambiar Foto Posnet
              </Label>
              <Input id="fotoPosnet" type="file" accept="image/*" onChange={e => setFotoPosnet(e.target.files[0])} />
              {fotoPosnet && <p className="text-xs text-green-500 mt-1 flex items-center gap-1"><CheckCircle className="w-3 h-3"/>{fotoPosnet.name}</p>}
            </div>
            <div>
              <Label htmlFor="fotoJarvis" className="flex items-center gap-2">
                <Upload className="w-4 h-4"/> Cambiar Captura Jarvis
              </Label>
              <Input id="fotoJarvis" type="file" accept="image/*" onChange={e => setFotoJarvis(e.target.files[0])} />
              {fotoJarvis && <p className="text-xs text-green-500 mt-1 flex items-center gap-1"><CheckCircle className="w-3 h-3"/>{fotoJarvis.name}</p>}
            </div>
          </div>
        </div>
        <DialogFooter className="sm:justify-between gap-2">
           {userRole === 'admin' && (
             <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" disabled={isSubmitting || isDeleting} type="button">
                  {isDeleting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Trash2 className="mr-2 h-4 w-4" />}
                  Eliminar
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>¿Estás completamente seguro?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Esta acción no se puede deshacer. Se eliminará permanentemente el registro del cierre de caja y su impacto en la planilla diaria y el saldo.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                    Eliminar
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
          
          <div className="flex gap-2 justify-end flex-1">
            <Button variant="outline" onClick={onClose} disabled={isSubmitting || isDeleting}>Cancelar</Button>
            <Button onClick={handleSubmit} disabled={isSubmitting || isDeleting}>
              {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
              Guardar Cambios
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default EditClosingDialog;