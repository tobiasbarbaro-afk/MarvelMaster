import React, { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/components/ui/use-toast';
import { useBranch } from '@/contexts/BranchContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Loader2, ArrowRight, ArrowLeft, Check, Archive } from 'lucide-react';
import { AnimatePresence } from 'framer-motion';
import StepIndicator from '@/components/cash_closing/StepIndicator';
import InitialStep from '@/components/cash_closing/form_steps/InitialStep';
import ChannelStep from '@/components/cash_closing/form_steps/ChannelStep';
import SummaryStep from '@/components/cash_closing/form_steps/SummaryStep';
import { normalizeAmountString, formatDateForDB, getTodayDateISO } from '@/lib/sheetUtils';
import { calculateAndSaveCurrentMonthBalance } from '@/services/balanceService';
import { logModificationAndNotify } from '@/lib/modificationLogger';

const PELLEGRINI_SUCURSAL_ID = '5';
const TERMINAL_SUCURSAL_ID = '47';

export const paymentMethods = [
  { id: 'efectivo', label: 'Efectivo' },
  { id: 'transferencia', label: 'Transferencia' },
  { id: 'mercadoPagoLink', label: 'Mercado Pago Link' },
  { id: 'mercadoPagoQR', label: 'Mercado Pago QR' },
  { id: 'mercadoPagoCredito', label: 'Mercado Pago Crédito' },
  { id: 'mercadoPagoDebito', label: 'Mercado Pago Débito' },
  { id: 'pedidosYaElectronico', label: 'Rappi Electrónico' },
];

const initialValues = {
  mostrador: paymentMethods.reduce((acc, method) => ({ ...acc, [method.id]: '' }), {}),
  cadetes: paymentMethods.reduce((acc, method) => ({ ...acc, [method.id]: '' }), {}),
  salon: paymentMethods.reduce((acc, method) => ({ ...acc, [method.id]: '' }), {}),
};

const ClosingForm = () => {
  const { user, userRole, userProfile } = useAuth();
  const { toast } = useToast();
  const { getBranchNameById } = useBranch();
  const [currentStep, setCurrentStep] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [sucursalId, setSucursalId] = useState('');
  const [fecha, setFecha] = useState(getTodayDateISO());
  const [turno, setTurno] = useState('Mediodia');
  const [values, setValues] = useState(initialValues);
  const [fotoPosnet, setFotoPosnet] = useState(null);
  const [fotoJarvis, setFotoJarvis] = useState(null);
  const [totalFacturado, setTotalFacturado] = useState('');

  const steps = useMemo(() => {
    const baseSteps = ['initial', 'mostrador'];
    if (sucursalId === PELLEGRINI_SUCURSAL_ID || sucursalId === TERMINAL_SUCURSAL_ID) {
      baseSteps.push('salon');
    }
    baseSteps.push('cadetes', 'summary');
    return baseSteps;
  }, [sucursalId]);

  useEffect(() => {
    if (userRole !== 'admin' && userProfile?.sucursal_id) {
      setSucursalId(userProfile.sucursal_id.toString());
    }
  }, [userProfile, userRole]);

  const handleValueChange = (channel, method, value) => {
    setValues(prev => ({
      ...prev,
      [channel]: { ...prev[channel], [method]: value },
    }));
  };

  const totals = useMemo(() => {
    const getNumericValue = (val) => parseFloat(normalizeAmountString(val)) || 0;

    const mostrador = values.mostrador;
    const cadetes = values.cadetes;
    const salon = sucursalId === PELLEGRINI_SUCURSAL_ID || sucursalId === TERMINAL_SUCURSAL_ID ? values.salon : {};

    const totalEfectivo = getNumericValue(mostrador.efectivo) + getNumericValue(cadetes.efectivo) +
                           getNumericValue(mostrador.pedidosYaEfectivo) + getNumericValue(cadetes.pedidosYaEfectivo) +
                           (getNumericValue(salon.efectivo) || 0) + (getNumericValue(salon.pedidosYaEfectivo) || 0);

    const totalMpCadetes = getNumericValue(cadetes.mercadoPagoLink);
    
    const totalMpMostrador = 
        getNumericValue(mostrador.mercadoPagoQR) +
        getNumericValue(mostrador.mercadoPagoCredito) +
        getNumericValue(mostrador.mercadoPagoDebito) +
        getNumericValue(mostrador.transferencia) +
        (getNumericValue(salon.mercadoPagoQR) || 0) +
        (getNumericValue(salon.mercadoPagoCredito) || 0) +
        (getNumericValue(salon.mercadoPagoDebito) || 0) +
        (getNumericValue(salon.transferencia) || 0);

    const totalElectronico = paymentMethods
      .filter(m => m.id !== 'efectivo')
      .reduce((sum, method) => {
          let channelSum = getNumericValue(mostrador[method.id]) + getNumericValue(cadetes[method.id]);
          if (sucursalId === PELLEGRINI_SUCURSAL_ID || sucursalId === TERMINAL_SUCURSAL_ID) {
            channelSum += (getNumericValue(salon[method.id]) || 0);
          }
          return sum + channelSum;
      }, 0);

    const totalGeneral = totalEfectivo + totalElectronico;

    return { totalEfectivo, totalMpCadetes, totalMpMostrador, totalElectronico, totalGeneral };
  }, [values, sucursalId]);

  const nextStep = () => setCurrentStep(prev => Math.min(prev + 1, steps.length - 1));
  const prevStep = () => setCurrentStep(prev => Math.max(prev - 1, 0));

  const uploadFile = async (file, sucursalId, fecha, turno, type) => {
    if (!file) return null;
    const formattedDate = formatDateForDB(fecha);
    const fileName = `${type}-${Date.now()}.${file.name.split('.').pop()}`;
    const filePath = `cierres_caja/${sucursalId}/${formattedDate}/${turno}/${fileName}`;
    
    const { error } = await supabase.storage.from('cierre-caja-imagenes').upload(filePath, file);
    if (error) throw new Error(`Error al subir ${type}: ${error.message}`);
    
    const { data } = supabase.storage.from('cierre-caja-imagenes').getPublicUrl(filePath);
    return data.publicUrl;
  };

  const handleSubmit = async () => {
    if (!fotoPosnet || !fotoJarvis) {
      toast({ variant: 'destructive', title: 'Faltan archivos', description: 'Debe cargar ambas imágenes para cerrar la caja.' });
      return;
    }
    setIsSubmitting(true);

    try {
      const formattedDate = formatDateForDB(fecha);
      const url_foto_posnet = await uploadFile(fotoPosnet, sucursalId, fecha, turno, 'posnet');
      const url_foto_jarvis = await uploadFile(fotoJarvis, sucursalId, fecha, turno, 'jarvis');

      if (!url_foto_posnet || !url_foto_jarvis) {
        throw new Error('No se pudieron obtener las URLs de las imágenes subidas.');
      }

      const isGerente = userRole === 'gerente';
      const isAdmin = userRole === 'admin';

      let verificadoPorGerencia = false;
      let verificadoPorAdmin = false;
      let impactadoEnPlanilla = false;

      if (isAdmin) {
          verificadoPorGerencia = true;
          verificadoPorAdmin = true;
          impactadoEnPlanilla = true;
      } else if (isGerente) {
          verificadoPorGerencia = true;
          verificadoPorAdmin = false;
          impactadoEnPlanilla = true;
      } else {
          verificadoPorGerencia = false;
          verificadoPorAdmin = false;
          impactadoEnPlanilla = false;
      }

      const legacyVerificado = verificadoPorGerencia;

      const cierreData = {
        sucursal_id: parseInt(sucursalId),
        usuario_id: user.id,
        fecha: formattedDate,
        turno,
        valores_ingresados: values,
        total_efectivo: totals.totalEfectivo,
        total_mp_cadetes: totals.totalMpCadetes,
        total_mp_mostrador: totals.totalMpMostrador,
        total_electronico: totals.totalElectronico,
        total_general: totals.totalGeneral,
        url_foto_posnet,
        url_foto_jarvis,
        verificado: legacyVerificado,
        verificado_por_gerencia: verificadoPorGerencia,
        verificado_por_admin: verificadoPorAdmin,
        impactado_en_planilla: impactadoEnPlanilla,
        advertencia: null,
        total_facturado: parseFloat(normalizeAmountString(totalFacturado)) || 0,
      };

      const { error: cierreError } = await supabase.from('cierres_caja').insert(cierreData);
      if (cierreError) throw new Error(`Error al guardar el cierre de caja: ${cierreError.message}`);

      if (impactadoEnPlanilla) {
        const dailyEntryData = {
          fecha: formattedDate,
          monto: totals.totalGeneral,
          ioe: 'I',
          tipo_ioe: `Cierre de Caja ${turno}`,
          razon_social: 'Caja Diaria',
          observaciones: `Cierre de caja automático del turno ${turno}. Efectivo: ${totals.totalEfectivo.toLocaleString('es-AR', { style: 'currency', currency: 'ARS' })}, Electrónico: ${totals.totalElectronico.toLocaleString('es-AR', { style: 'currency', currency: 'ARS' })}`,
          debe: totals.totalEfectivo,
          haber: 0,
          sucursal_id: parseInt(sucursalId),
          usuario_email: user.email,
          verificado: true,
        };

        const { error: entryError } = await supabase.from('entradas_diarias').insert(dailyEntryData);
        if (entryError) throw new Error(`Cierre guardado, pero error al impactar en planilla diaria: ${entryError.message}`);
        
        const monthYear = formattedDate.slice(0, 7);
        await calculateAndSaveCurrentMonthBalance(parseInt(sucursalId), monthYear, user.email);
        await logModificationAndNotify(supabase, toast, getBranchNameById, parseInt(sucursalId), monthYear, user.email, 'cierre_caja_automatico');

        toast({ title: 'Éxito', description: 'Cierre guardado e impactado en planilla correctamente.' });
      } else {
        toast({ title: 'Éxito', description: 'Cierre guardado. Pendiente de revisión por Gerencia.' });
      }
      
      setCurrentStep(0);
      setValues(initialValues);
      setFotoPosnet(null);
      setFotoJarvis(null);
      setFecha(getTodayDateISO());
      setTurno('Mediodia');
      setTotalFacturado('');
      if (userRole === 'admin') setSucursalId('');

    } catch (error) {
      console.error("Error en cierre de caja:", error);
      toast({ variant: 'destructive', title: 'Error', description: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderStep = () => {
    const stepName = steps[currentStep];

    switch (stepName) {
      case 'initial':
        return <InitialStep {...{ sucursalId, setSucursalId, fecha, setFecha, turno, setTurno }} />;
      case 'mostrador':
      case 'salon':
      case 'cadetes':
        return <ChannelStep channel={stepName} values={values[stepName]} onValueChange={handleValueChange} paymentMethods={paymentMethods} />;
      case 'summary':
        return <SummaryStep {...{ values, totals, fotoPosnet, setFotoPosnet, fotoJarvis, setFotoJarvis, paymentMethods, totalFacturado, setTotalFacturado, sucursalId, PELLEGRINI_SUCURSAL_ID }} />;
      default:
        return null;
    }
  };

  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl flex items-center gap-2"><Archive /> Cierre de Caja</CardTitle>
        <CardDescription>Formulario para el cierre de caja diario por turno.</CardDescription>
      </CardHeader>
      <CardContent>
        <StepIndicator steps={steps} currentStep={currentStep} />
        <AnimatePresence mode="wait">
          {renderStep()}
        </AnimatePresence>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={prevStep} disabled={currentStep === 0 || isSubmitting}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Anterior
        </Button>
        {currentStep < steps.length - 1 ? (
          <Button onClick={nextStep} disabled={currentStep === 0 && !sucursalId}>
            Siguiente <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        ) : (
          <Button onClick={handleSubmit} disabled={isSubmitting || !fotoPosnet || !fotoJarvis}>
            {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Check className="mr-2 h-4 w-4" />}
            Enviar Cierre
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default ClosingForm;