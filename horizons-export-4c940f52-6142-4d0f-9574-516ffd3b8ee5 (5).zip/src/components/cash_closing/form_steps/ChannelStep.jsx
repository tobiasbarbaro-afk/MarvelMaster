import React from 'react';
    import { motion } from 'framer-motion';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { CardTitle } from '@/components/ui/card';

    const motionProps = {
      initial: { opacity: 0, x: 50 },
      animate: { opacity: 1, x: 0 },
      exit: { opacity: 0, x: -50 },
      transition: { duration: 0.3 },
    };
    
    const ChannelStep = ({ channel, values, onValueChange, paymentMethods }) => {
      return (
        <motion.div {...motionProps} className="space-y-4 pt-4">
          <CardTitle className="capitalize">{channel}</CardTitle>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {paymentMethods.map(method => (
              <div key={method.id}>
                <Label htmlFor={`${channel}-${method.id}`}>{method.label}</Label>
                <Input
                  id={`${channel}-${method.id}`}
                  type="text"
                  placeholder="0.00"
                  value={values[method.id]}
                  onChange={e => onValueChange(channel, method.id, e.target.value)}
                />
              </div>
            ))}
          </div>
        </motion.div>
      );
    };
    
    export default ChannelStep;