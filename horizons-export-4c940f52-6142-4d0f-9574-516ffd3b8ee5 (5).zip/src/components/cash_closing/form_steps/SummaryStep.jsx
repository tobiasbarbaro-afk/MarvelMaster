import React from 'react';
    import { motion } from 'framer-motion';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { CardTitle } from '@/components/ui/card';
    import { Upload, Check } from 'lucide-react';
    import { normalizeAmountString } from '@/lib/sheetUtils';
    import { paymentMethods } from '@/components/cash_closing/ClosingForm';
    
    const motionProps = {
      initial: { opacity: 0, x: 50 },
      animate: { opacity: 1, x: 0 },
      exit: { opacity: 0, x: -50 },
      transition: { duration: 0.3 },
    };
    
    const SummaryStep = ({ values, totals, fotoPosnet, setFotoPosnet, fotoJarvis, setFotoJarvis, totalFacturado, setTotalFacturado, sucursalId, PELLEGRINI_SUCURSAL_ID }) => {
      const channels = ['mostrador'];
      if (sucursalId === PELLEGRINI_SUCURSAL_ID) {
        channels.push('salon');
      }
      channels.push('cadetes');

      return (
        <motion.div {...motionProps} className="space-y-6 pt-4">
          <CardTitle>Resumen y Carga de Archivos</CardTitle>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4 p-4 border rounded-lg">
              <h4 className="font-semibold">Valores Ingresados</h4>
              {channels.map((channel) => (
                <div key={channel}>
                  <h5 className="font-medium capitalize text-primary">{channel}</h5>
                  <ul className="text-sm list-disc list-inside">
                    {Object.entries(values[channel]).map(([methodId, value]) => {
                      const methodLabel = paymentMethods.find(m => m.id === methodId)?.label || methodId;
                      const displayValue = parseFloat(normalizeAmountString(value) || '0').toLocaleString('es-AR', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                      if(parseFloat(normalizeAmountString(value) || '0') > 0) {
                        return <li key={methodId}>{methodLabel}: ${displayValue}</li>
                      }
                      return null;
                    })}
                  </ul>
                </div>
              ))}
            </div>
            <div className="space-y-4 p-4 border rounded-lg bg-muted/50">
              <h4 className="font-semibold">Totales</h4>
              <div className="space-y-2 text-sm">
                <p className="flex justify-between"><span>Total Efectivo:</span> <strong>${totals.totalEfectivo.toLocaleString('es-AR', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</strong></p>
                <p className="flex justify-between"><span>Total Electrónico:</span> <strong>${totals.totalElectronico.toLocaleString('es-AR', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</strong></p>
                <hr className="my-2"/>
                <p className="flex justify-between text-lg font-bold text-primary"><span>GRAN TOTAL:</span> <strong>${totals.totalGeneral.toLocaleString('es-AR', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</strong></p>
              </div>
            </div>
          </div>
          <div className="mt-4">
            <Label htmlFor="totalFacturado">Total Facturado</Label>
            <Input
              id="totalFacturado"
              type="text"
              value={totalFacturado}
              onChange={(e) => setTotalFacturado(e.target.value)}
              placeholder="0.00"
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="fotoPosnet" className="flex items-center gap-2">
                <Upload className="w-4 h-4"/> Foto del Resumen de Ventas Posnet *
              </Label>
              <Input id="fotoPosnet" type="file" accept="image/*,application/pdf" onChange={e => setFotoPosnet(e.target.files[0])} />
              {fotoPosnet && <p className="text-xs text-green-500 mt-1 flex items-center gap-1"><Check className="w-3 h-3"/>{fotoPosnet.name}</p>}
            </div>
            <div>
              <Label htmlFor="fotoJarvis" className="flex items-center gap-2">
                <Upload className="w-4 h-4"/> Captura de Jarvis *
              </Label>
              <Input id="fotoJarvis" type="file" accept="image/*,application/pdf" onChange={e => setFotoJarvis(e.target.files[0])} />
              {fotoJarvis && <p className="text-xs text-green-500 mt-1 flex items-center gap-1"><Check className="w-3 h-3"/>{fotoJarvis.name}</p>}
            </div>
          </div>
        </motion.div>
      );
    };
    
    export default SummaryStep;