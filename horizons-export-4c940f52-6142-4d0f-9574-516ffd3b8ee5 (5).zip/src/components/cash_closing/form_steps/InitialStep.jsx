import React from 'react';
    import { motion } from 'framer-motion';
    import { useAuth } from '@/hooks/useAuth';
    import { useBranch } from '@/contexts/BranchContext';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
    import { CardTitle } from '@/components/ui/card';
    
    const motionProps = {
      initial: { opacity: 0, x: 50 },
      animate: { opacity: 1, x: 0 },
      exit: { opacity: 0, x: -50 },
      transition: { duration: 0.3 },
    };

    const InitialStep = ({ sucursalId, setSucursalId, fecha, setFecha, turno, setTurno }) => {
      const { userRole } = useAuth();
      const { availableBranches, loadingBranches } = useBranch();
    
      return (
        <motion.div {...motionProps} className="space-y-6 pt-4">
          <CardTitle>Información General</CardTitle>
          {userRole === 'admin' && (
            <div>
              <Label htmlFor="sucursal">Sucursal</Label>
              <Select value={sucursalId} onValueChange={setSucursalId} disabled={loadingBranches}>
                <SelectTrigger id="sucursal"><SelectValue placeholder="Seleccione una sucursal..." /></SelectTrigger>
                <SelectContent>
                  {availableBranches.map(b => <SelectItem key={b.id} value={b.id.toString()}>{b.nombre}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}
          <div>
            <Label htmlFor="fecha">Fecha</Label>
            <Input id="fecha" type="date" value={fecha} onChange={e => setFecha(e.target.value)} />
          </div>
          <div>
            <Label>Turno</Label>
            <RadioGroup value={turno} onValueChange={setTurno} className="flex gap-4">
              <div className="flex items-center space-x-2"><RadioGroupItem value="Mediodia" id="mediodia" /><Label htmlFor="mediodia">Mediodía</Label></div>
              <div className="flex items-center space-x-2"><RadioGroupItem value="Noche" id="noche" /><Label htmlFor="noche">Noche</Label></div>
            </RadioGroup>
          </div>
        </motion.div>
      );
    };
    
    export default InitialStep;