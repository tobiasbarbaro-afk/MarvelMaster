import React from 'react';
    import { Check } from 'lucide-react';
    
    const StepIndicator = ({ steps, currentStep }) => {
      return (
        <div className="mb-4">
          <div className="flex justify-between items-center">
            {steps.map((step, index) => (
              <React.Fragment key={step}>
                <div className="flex flex-col items-center">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep >= index ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                    {currentStep > index ? <Check /> : index + 1}
                  </div>
                  <p className={`text-xs mt-1 capitalize ${currentStep >= index ? 'text-primary' : 'text-muted-foreground'}`}>{step === 'initial' ? 'Info' : step}</p>
                </div>
                {index < steps.length - 1 && <div className={`flex-1 h-1 mx-2 ${currentStep > index ? 'bg-primary' : 'bg-muted'}`} />}
              </React.Fragment>
            ))}
          </div>
        </div>
      );
    };
    
    export default StepIndicator;