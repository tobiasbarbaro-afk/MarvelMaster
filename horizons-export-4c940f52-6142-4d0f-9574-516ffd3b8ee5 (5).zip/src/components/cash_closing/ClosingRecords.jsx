import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/components/ui/use-toast';
import { useBranch } from '@/contexts/BranchContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Loader2, ExternalLink, Clock, AlertTriangle, ChevronDown, ChevronUp, Edit, ShieldCheck, UserCheck } from 'lucide-react';
import { formatDateForDisplay, normalizeAmountString } from '@/lib/sheetUtils';
import { motion, AnimatePresence } from 'framer-motion';
import { paymentMethods } from '@/components/cash_closing/ClosingForm';
import EditClosingDialog from './EditClosingDialog';

const ClosingRecords = () => {
  const { userRole, userProfile } = useAuth();
  const { availableBranches, loadingBranches } = useBranch();
  const { toast } = useToast();
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(false);
  const defaultMonth = new Date().toISOString().slice(0, 7);
  const [filterMonth, setFilterMonth] = useState(defaultMonth);
  const [filterSucursalId, setFilterSucursalId] = useState('');
  const [expandedRecordId, setExpandedRecordId] = useState(null);
  const [editingRecord, setEditingRecord] = useState(null);

  useEffect(() => {
    if (userRole === 'gerente' && userProfile?.sucursal_id) {
      setFilterSucursalId(userProfile.sucursal_id.toString());
    } else if (userRole === 'admin' && availableBranches.length > 0) {
      if (!filterSucursalId) {
        setFilterSucursalId(availableBranches[0]?.id.toString());
      }
    }
  }, [userRole, userProfile, availableBranches, filterSucursalId]);

  const fetchRecords = useCallback(async () => {
    if (!filterSucursalId || !filterMonth) return;
    setLoading(true);
    const [year, month] = filterMonth.split('-');
    const startDate = `${year}-${month}-01`;
    const endDate = new Date(year, parseInt(month, 10), 0).toISOString().slice(0, 10);
    const { data, error } = await supabase
      .from('cierres_caja')
      .select('*')
      .eq('sucursal_id', filterSucursalId)
      .gte('fecha', startDate)
      .lte('fecha', endDate)
      .order('fecha', { ascending: false })
      .order('turno', { ascending: false });

    if (error) {
      toast({ variant: 'destructive', title: 'Error', description: 'No se pudieron cargar los registros.' });
    } else {
      setRecords(data);
    }
    setLoading(false);
  }, [filterSucursalId, filterMonth, toast]);

  useEffect(() => {
    if (filterSucursalId && filterMonth) {
      fetchRecords();
    }
  }, [fetchRecords, filterSucursalId, filterMonth]);
  
  const toggleExpand = (id) => {
    setExpandedRecordId(expandedRecordId === id ? null : id);
  };

  const handleEdit = (record, e) => {
    e.stopPropagation();
    setEditingRecord(record);
  };

  const formatCurrency = (value) => {
    const num = parseFloat(value);
    return isNaN(num) ? '$0.00' : num.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  const renderStatus = (record) => {
      // ESTADO 3: Verificado por Admin (Completado)
      if (record.verificado_por_admin) {
          return (
              <div className="flex flex-col">
                <div className="flex items-center gap-1 text-blue-600 font-bold text-xs">
                    <ShieldCheck className="h-4 w-4" /> VERIFICADO FINAL
                </div>
                <span className="text-[10px] text-gray-500">Planilla OK</span>
              </div>
          );
      } 
      // ESTADO 2: Verificado por Gerencia (Impactado en planilla, pendiente admin)
      else if (record.verificado_por_gerencia) {
          return (
              <div className="flex flex-col">
                  <div className="flex items-center gap-1 text-green-600 font-medium text-xs">
                       <UserCheck className="h-4 w-4" /> APROBADO GERENCIA
                  </div>
                  <span className="text-[10px] text-orange-500 font-semibold">Pendiente Supervisión</span>
              </div>
          );
      } 
      // ESTADO 1: Pendiente (Creado por Mostrador)
      else {
          return (
              <div className="flex flex-col">
                  <div className="flex items-center gap-1 text-yellow-600 font-medium text-xs">
                      <Clock className="h-4 w-4" /> PENDIENTE
                  </div>
                  <span className="text-[10px] text-gray-500">Requiere Impacto Gerencial</span>
              </div>
          );
      }
  };

  return (
    <>
      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Registros de Cierre</CardTitle>
          <CardDescription>Consulta los cierres de caja y su estado de verificación.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            {userRole === 'admin' && <div className="flex-1">
                <Label htmlFor="filter-sucursal">Sucursal</Label>
                <Select value={filterSucursalId} onValueChange={setFilterSucursalId} disabled={loadingBranches}>
                  <SelectTrigger id="filter-sucursal"><SelectValue placeholder="Seleccione sucursal..." /></SelectTrigger>
                  <SelectContent>
                    {availableBranches.map(b => <SelectItem key={b.id} value={b.id.toString()}>{b.nombre}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>}
            <div className="flex-1">
              <Label htmlFor="filter-month">Mes</Label>
              <Input id="filter-month" type="month" value={filterMonth} onChange={e => setFilterMonth(e.target.value)} />
            </div>
          </div>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]">Ver</TableHead>
                  <TableHead>Fecha</TableHead>
                  <TableHead>Turno</TableHead>
                  <TableHead>Total Gral.</TableHead>
                  <TableHead>Imágenes</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? <TableRow><TableCell colSpan={7} className="text-center"><Loader2 className="mx-auto h-6 w-6 animate-spin" /></TableCell></TableRow> : records.length > 0 ? records.map(record => <React.Fragment key={record.id}>
                      <TableRow className="cursor-pointer hover:bg-muted/50" onClick={() => toggleExpand(record.id)}>
                        <TableCell>{expandedRecordId === record.id ? <ChevronUp className="h-4 w-4"/> : <ChevronDown className="h-4 w-4"/>}</TableCell>
                        <TableCell>{formatDateForDisplay(record.fecha)}</TableCell>
                        <TableCell>{record.turno}</TableCell>
                        <TableCell className="font-bold text-primary">${formatCurrency(record.total_general)}</TableCell>
                        <TableCell className="flex gap-2">
                          <a href={record.url_foto_posnet} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline" onClick={e => e.stopPropagation()}>
                            <ExternalLink className="h-4 w-4" />
                          </a>
                        </TableCell>
                        <TableCell>{renderStatus(record)}</TableCell>
                        <TableCell>
                          {(userRole === 'admin' || (userRole === 'gerente' && !record.verificado_por_admin)) && (
                            <Button variant="outline" size="icon" className="h-8 w-8" onClick={(e) => handleEdit(record, e)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                      <AnimatePresence>
                        {expandedRecordId === record.id && (
                          <motion.tr
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                          >
                            <TableCell colSpan={7} className="p-0 border-b-2 border-primary/10">
                              <div className="p-4 bg-muted/30 grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                                <div>
                                    <h4 className="font-bold text-xs uppercase mb-2 text-muted-foreground">Totales</h4>
                                    <p className="flex justify-between"><span>Efectivo:</span> <strong>${formatCurrency(record.total_efectivo)}</strong></p>
                                    <p className="flex justify-between"><span>Electrónico:</span> <strong>${formatCurrency(record.total_electronico)}</strong></p>
                                </div>
                                <div className="col-span-2">
                                    <h4 className="font-bold text-xs uppercase mb-2 text-muted-foreground">Detalles Ingresados</h4>
                                    <div className="grid grid-cols-2 gap-4">
                                         {Object.entries(record.valores_ingresados || {}).map(([channel, methods]) => (
                                            <div key={channel}>
                                                <span className="capitalize font-semibold text-primary">{channel}</span>
                                                <ul className="text-xs text-muted-foreground">
                                                    {Object.entries(methods).map(([k, v]) => {
                                                        const val = parseFloat(normalizeAmountString(v));
                                                        return val > 0 ? <li key={k} className="flex justify-between"><span>{k}:</span> <span>${formatCurrency(val)}</span></li> : null;
                                                    })}
                                                </ul>
                                            </div>
                                         ))}
                                    </div>
                                </div>
                              </div>
                            </TableCell>
                          </motion.tr>
                        )}
                      </AnimatePresence>
                    </React.Fragment>) : <TableRow><TableCell colSpan={7} className="text-center py-4">No hay registros.</TableCell></TableRow>}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      {editingRecord && (
        <EditClosingDialog
          record={editingRecord}
          isOpen={!!editingRecord}
          onClose={() => setEditingRecord(null)}
          onRecordUpdate={() => {
            fetchRecords();
            setEditingRecord(null);
          }}
        />
      )}
    </>
  );
};
export default ClosingRecords;