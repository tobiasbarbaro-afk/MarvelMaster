import React, { useState } from 'react';
import { Check, ChevronsUpDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';

const RubroCombobox = ({ value, onChange, rubros = [], placeholder = "Seleccionar rubro..." }) => {
  const [open, setOpen] = useState(false);

  const handleSelect = (currentValue) => {
    onChange(currentValue === value ? '' : currentValue);
    setOpen(false);
  };

  const displayValue = value || '';

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="w-full justify-between"
        >
          {displayValue || placeholder}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[var(--radix-popover-trigger-width)] p-0" align="start">
        <Command>
          <CommandInput placeholder="Buscar rubro..." />
          <CommandList>
            <CommandEmpty>
              <div className="p-2 text-sm text-muted-foreground text-center">
                No se encontraron rubros.
              </div>
            </CommandEmpty>
            <CommandGroup className="max-h-[200px] overflow-auto">
              {rubros.map((rubro) => (
                <CommandItem
                  key={rubro}
                  value={rubro}
                  onSelect={handleSelect}
                  className="cursor-pointer"
                >
                  <Check
                    className={cn(
                      "mr-2 h-4 w-4",
                      value === rubro ? "opacity-100" : "opacity-0"
                    )}
                  />
                  {rubro}
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
};

export default RubroCombobox;