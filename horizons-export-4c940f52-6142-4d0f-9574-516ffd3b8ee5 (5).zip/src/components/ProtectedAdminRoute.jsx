import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';

const ProtectedAdminRoute = ({ children }) => {
  const { userRole, loading, isAuthenticated } = useAuth();
  const { toast } = useToast();

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated || userRole !== 'admin') {
    // We defer the toast slightly to avoid state updates during render
    setTimeout(() => {
      toast({
        variant: 'destructive',
        title: 'Acceso denegado',
        description: 'No tienes permisos de administrador para acceder a esta página.',
      });
    }, 0);
    return <Navigate to="/" replace />;
  }

  return children;
};

export default ProtectedAdminRoute;