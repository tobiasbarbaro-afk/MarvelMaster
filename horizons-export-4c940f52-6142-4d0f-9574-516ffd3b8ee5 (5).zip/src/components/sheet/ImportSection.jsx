import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { UploadCloud, Loader2, FileSpreadsheet, AlertTriangle } from 'lucide-react';
import { read, utils } from 'xlsx';
import { isValidDate, formatDateForDB, normalizeAmountString, formatDateForDisplay } from '@/lib/sheetUtils';
import { calculateAndSaveCurrentMonthBalance } from '@/services/balanceService';
import { logModificationAndNotify } from '@/lib/modificationLogger';
import { useAuth } from '@/hooks/useAuth';
const headerMapping = {
  'fecha': 'fecha',
  'monto': 'monto',
  'ioe': 'ioe',
  'tipo ioe': 'tipo_ioe',
  'tipo_ioe': 'tipo_ioe',
  'razón social': 'razon_social',
  'razon_social': 'razon_social',
  'nombre/razón social': 'razon_social',
  'observaciones': 'observaciones',
  'debe': 'debe',
  'haber': 'haber'
};
const requiredInternalHeaders = ['fecha', 'monto', 'ioe', 'tipo_ioe', 'razon_social', 'observaciones'];
const ImportSection = ({
  supabase,
  toast,
  user,
  availableBranches,
  selectedBranchId,
  setSelectedBranchId,
  loadingBranches,
  getBranchNameById
}) => {
  const [file, setFile] = useState(null);
  const [monthYear, setMonthYear] = useState(new Date().toISOString().slice(0, 7));
  const [isProcessing, setIsProcessing] = useState(false);
  const [fileName, setFileName] = useState('');
  const {
    userRole
  } = useAuth();
  const handleFileChange = e => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      setFileName(selectedFile.name);
    } else {
      setFile(null);
      setFileName('');
    }
  };
  const handleBranchChange = value => {
    setSelectedBranchId(value);
  };
  const handleImport = async () => {
    if (!file || !selectedBranchId || !monthYear || !user || !user.email) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Por favor, seleccione un archivo, sucursal, mes y asegúrese de estar autenticado."
      });
      return;
    }
    setIsProcessing(true);
    try {
      const reader = new FileReader();
      reader.onload = async eventReader => {
        try {
          const data = new Uint8Array(eventReader.target.result);
          const workbook = read(data, {
            type: 'array',
            cellDates: true
          });
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          const jsonData = utils.sheet_to_json(worksheet, {
            header: 1,
            raw: false,
            defval: null
          });
          if (jsonData.length <= 1) {
            throw new Error("El archivo Excel no contiene filas de datos válidas o está vacío.");
          }
          const rawHeaders = jsonData[0].map(h => h !== null && h !== undefined ? h.toString().trim().toLowerCase() : '');
          const mappedHeaders = rawHeaders.map(h => headerMapping[h] || h);
          const missingHeaders = requiredInternalHeaders.filter(rh => !mappedHeaders.includes(rh));
          if (missingHeaders.length > 0) {
            throw new Error(`Faltan las siguientes cabeceras requeridas (o sus equivalentes mapeados): ${missingHeaders.join(', ')}.`);
          }
          const year = parseInt(monthYear.slice(0, 4));
          const month = parseInt(monthYear.slice(5, 7));
          const firstDayOfMonth = `${year}-${month.toString().padStart(2, '0')}-01`;
          const lastDayOfMonth = new Date(year, month, 0).getDate();
          const lastDayOfMonthStr = `${year}-${month.toString().padStart(2, '0')}-${lastDayOfMonth.toString().padStart(2, '0')}`;
          const {
            error: deleteError
          } = await supabase.from('entradas_diarias').delete().eq('sucursal_id', parseInt(selectedBranchId)).gte('fecha', firstDayOfMonth).lte('fecha', lastDayOfMonthStr);
          if (deleteError) {
            throw new Error(`Error eliminando entradas existentes: ${deleteError.message}`);
          }
          const entriesToInsert = jsonData.slice(1).map((row, index) => {
            const isSummaryRow = row.some(cell => cell && cell.toString().toLowerCase().includes('saldo'));
            if (isSummaryRow) {
              return null;
            }
            const entry = {};
            mappedHeaders.forEach((internalHeader, i) => {
              if (requiredInternalHeaders.includes(internalHeader) || internalHeader === 'debe' || internalHeader === 'haber') {
                entry[internalHeader] = row[i];
              }
            });
            const originalDateValue = entry.fecha;
            if (originalDateValue === null || originalDateValue === undefined || originalDateValue === '') {
              if (Object.values(entry).every(val => val === null || val === undefined || val === '')) {
                return null;
              }
              throw new Error(`Fecha faltante en fila ${index + 2}. Por favor, ingrese una fecha válida.`);
            }
            if (!isValidDate(originalDateValue)) {
              throw new Error(`Fecha inválida en fila ${index + 2}: '${originalDateValue}'. Use formato DD/MM/AAAA.`);
            }
            entry.fecha = formatDateForDB(originalDateValue);
            if (!entry.fecha || typeof entry.fecha !== 'string') {
              throw new Error(`Error al procesar la fecha en fila ${index + 2}. Fecha obtenida: '${entry.fecha}'`);
            }
            if (entry.fecha.slice(0, 7) !== monthYear) {
              throw new Error(`La fecha ${formatDateForDisplay(entry.fecha)} en la fila ${index + 2} no corresponde al mes seleccionado (${monthYear}).`);
            }
            const originalMontoValue = entry.monto;
            if (originalMontoValue === null || originalMontoValue === undefined || originalMontoValue === '') {
              throw new Error(`Monto faltante en fila ${index + 2}. Por favor, ingrese un monto válido.`);
            }
            const monto = normalizeAmountString(originalMontoValue);
            if (isNaN(monto) || monto <= 0) {
              throw new Error(`Monto inválido o no positivo en fila ${index + 2}: '${originalMontoValue}'.`);
            }
            const ioeValue = entry.ioe !== null && entry.ioe !== undefined ? entry.ioe.toString().toUpperCase() : '';
            if (ioeValue !== 'I' && ioeValue !== 'E') {
              throw new Error(`Valor IOE inválido en fila ${index + 2}: '${entry.ioe}'. Debe ser 'I' o 'E'.`);
            }
            return {
              fecha: entry.fecha,
              monto: monto,
              ioe: ioeValue,
              tipo_ioe: entry.tipo_ioe !== null && entry.tipo_ioe !== undefined ? entry.tipo_ioe.toString() : '',
              razon_social: entry.razon_social !== null && entry.razon_social !== undefined ? entry.razon_social.toString() : '',
              observaciones: entry.observaciones !== null && entry.observaciones !== undefined ? entry.observaciones.toString() : '',
              debe: ioeValue === 'I' ? monto : normalizeAmountString(entry.debe) || 0,
              haber: ioeValue === 'E' ? monto : normalizeAmountString(entry.haber) || 0,
              sucursal_id: parseInt(selectedBranchId),
              usuario_email: user.email
            };
          }).filter(entry => entry !== null);
          if (entriesToInsert.length === 0) {
            await calculateAndSaveCurrentMonthBalance(parseInt(selectedBranchId), monthYear, user.email);
            await logModificationAndNotify(supabase, toast, getBranchNameById, parseInt(selectedBranchId), monthYear, user.email, 'importacion_excel_vacia');
            toast({
              title: "Información",
              description: "No se encontraron datos válidos para importar. La planilla para el mes ha sido vaciada y el saldo recalculado."
            });
            setFile(null);
            setFileName('');
            setIsProcessing(false);
            return;
          }
          const {
            error: insertError
          } = await supabase.from('entradas_diarias').insert(entriesToInsert);
          if (insertError) {
            throw new Error(`Error insertando nuevas entradas: ${insertError.message}`);
          }
          await calculateAndSaveCurrentMonthBalance(parseInt(selectedBranchId), monthYear, user.email);
          await logModificationAndNotify(supabase, toast, getBranchNameById, parseInt(selectedBranchId), monthYear, user.email, 'importacion_excel');
          toast({
            title: "Éxito",
            description: `${entriesToInsert.length} entradas importadas y saldo del mes ${monthYear} recalculado.`
          });
          setFile(null);
          setFileName('');
        } catch (processError) {
          console.error("Error procesando el archivo:", processError);
          toast({
            variant: "destructive",
            title: "Error de Procesamiento",
            description: processError.message
          });
        } finally {
          setIsProcessing(false);
        }
      };
      reader.readAsArrayBuffer(file);
    } catch (error) {
      console.error("Error durante la importación (configuración FileReader):", error);
      toast({
        variant: "destructive",
        title: "Error de Importación",
        description: error.message
      });
      setIsProcessing(false);
    }
  };
  return <Card className="w-full max-w-lg mx-auto shadow-lg">
          <CardHeader>
            <CardTitle className="text-2xl text-primary flex items-center">
              <UploadCloud className="w-6 h-6 mr-2" /> Importar Planilla Excel
            </CardTitle>
            <CardDescription>
              Seleccione la sucursal, el mes (YYYY-MM) y el archivo Excel (.xlsx, .xls) para importar.
              Las entradas existentes para la sucursal y mes seleccionados serán reemplazadas. El saldo mensual se recalculará.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label htmlFor="branch-import" className="text-foreground font-semibold">Sucursal</Label>
              <Select onValueChange={handleBranchChange} value={selectedBranchId || ''} disabled={loadingBranches || isProcessing || userRole === 'gerente'}>
                <SelectTrigger id="branch-import">
                  <SelectValue placeholder={loadingBranches ? "Cargando..." : "Seleccione sucursal"} />
                </SelectTrigger>
                <SelectContent>
                  {availableBranches.map(branch => <SelectItem key={branch.id} value={branch.id.toString()}>{branch.nombre}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="monthYear-import" className="text-foreground font-semibold">Mes y Año </Label>
              <Input type="month" id="monthYear-import" value={monthYear} onChange={e => setMonthYear(e.target.value)} disabled={isProcessing} className="bg-input border-border focus:border-primary" />
            </div>
            <div>
              <Label htmlFor="file-upload" className="text-foreground font-semibold">Archivo Excel</Label>
              <div className="mt-1 flex items-center space-x-2">
                <Label htmlFor="file-upload-input" className="flex items-center justify-center w-full px-4 py-2 border-2 border-dashed rounded-md cursor-pointer border-border hover:border-primary transition-colors bg-background">
                  <FileSpreadsheet className="w-5 h-5 mr-2 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">{fileName || 'Seleccionar archivo (.xlsx, .xls)'}</span>
                </Label>
                <Input id="file-upload-input" type="file" accept=".xlsx, .xls" onChange={handleFileChange} className="sr-only" disabled={isProcessing} />
              </div>
            </div>
            <div className="p-3 rounded-md bg-yellow-50 border border-yellow-300 text-yellow-700">
                <div className="flex">
                    <div className="flex-shrink-0">
                        <AlertTriangle className="h-5 w-5" aria-hidden="true" />
                    </div>
                    <div className="ml-3">
                        <h3 className="text-sm font-medium">Atención</h3>
                        <div className="mt-1 text-sm">
                            <p>Al importar, se eliminarán todas las entradas existentes para la sucursal y el mes seleccionados antes de cargar los nuevos datos.</p>
                        </div>
                    </div>
                </div>
            </div>
            <Button onClick={handleImport} className="w-full bg-primary text-primary-foreground hover:bg-primary/90" disabled={isProcessing || !file || !selectedBranchId || !monthYear}>
              {isProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UploadCloud className="mr-2 h-4 w-4" />}
              {isProcessing ? 'Procesando...' : 'Importar y Recalcular Saldo'}
            </Button>
          </CardContent>
        </Card>;
};
export default ImportSection;