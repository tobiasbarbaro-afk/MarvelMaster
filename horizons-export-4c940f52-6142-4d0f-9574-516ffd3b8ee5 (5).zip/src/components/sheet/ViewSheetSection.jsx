import React, { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Eye, Loader2, ArrowUp, ArrowDown, RefreshCw, ExternalLink, Trash2, Paperclip } from 'lucide-react';
import { motion } from 'framer-motion';
import { calculateAndSaveCurrentMonthBalance } from '@/services/balanceService';
import { useAuth } from '@/hooks/useAuth';
import { formatDateForDisplay, isWithin48Hours } from '@/lib/sheetUtils';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import AttachReceiptDialog from '@/components/sheet/AttachReceiptDialog';

const ViewSheetSection = ({ supabase, toast, availableBranches, selectedBranchId, setSelectedBranchId, loadingBranches }) => {
  const [monthYear, setMonthYear] = useState(new Date().toISOString().slice(0, 7));
  const [entries, setEntries] = useState([]);
  const [currentMonthBalance, setCurrentMonthBalance] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [sortOrder, setSortOrder] = useState('asc');
  const { user, userRole, userProfile } = useAuth();

  // Dialog state
  const [attachDialogOpen, setAttachDialogOpen] = useState(false);
  const [selectedEntryId, setSelectedEntryId] = useState(null);

  useEffect(() => {
    if (userRole === 'gerente' && userProfile?.sucursal_id) {
      setSelectedBranchId(userProfile.sucursal_id.toString());
    }
  }, [userProfile, userRole, setSelectedBranchId]);

  const handleBranchChange = (value) => {
    setSelectedBranchId(value); 
    setEntries([]); 
    setCurrentMonthBalance(null);
  };

  const handleMonthChange = (e) => {
    setMonthYear(e.target.value);
    setEntries([]); 
    setCurrentMonthBalance(null);
  };
  
  const fetchEntriesAndBalance = useCallback(async () => {
    if (!selectedBranchId || !monthYear || !user || !user.email) {
      setEntries([]);
      setCurrentMonthBalance(null);
      if (selectedBranchId && monthYear && (!user || !user.email)) {
        toast({variant: "destructive", title: "Usuario no autenticado", description: "Por favor, inicie sesión para ver los datos."})
      }
      return;
    }
    setIsLoading(true);
    try {
      
      const calculatedBalance = await calculateAndSaveCurrentMonthBalance(parseInt(selectedBranchId), monthYear, user.email);
      setCurrentMonthBalance(calculatedBalance);

      const { data, error } = await supabase
        .from('entradas_diarias')
        .select('id, fecha, monto, ioe, tipo_ioe, razon_social, observaciones, debe, haber, creado_en, comprobante_url') 
        .eq('sucursal_id', parseInt(selectedBranchId))
        .gte('fecha', `${monthYear}-01`)
        .lte('fecha', `${monthYear}-${new Date(parseInt(monthYear.slice(0,4)), parseInt(monthYear.slice(5,7)), 0).getDate()}`)
        .order('fecha', { ascending: sortOrder === 'asc' })
        .order('creado_en', { ascending: sortOrder === 'asc' });

      if (error) {
        throw new Error(`Error obteniendo entradas: ${error.message}`);
      }
      setEntries(data || []);
      if (!data || data.length === 0) {
        toast({ title: "Sin Datos", description: "No se encontraron entradas para la selección actual." });
      }

    } catch (error) {
      console.error("Error al visualizar la planilla:", error);
      toast({ variant: "destructive", title: "Error al Visualizar", description: error.message });
      setEntries([]);
      setCurrentMonthBalance(null);
    } finally {
      setIsLoading(false);
    }
  }, [selectedBranchId, monthYear, supabase, toast, sortOrder, user]);


  useEffect(() => {
    if (selectedBranchId && monthYear && user) {
        fetchEntriesAndBalance();
    }
  }, [fetchEntriesAndBalance, selectedBranchId, monthYear, sortOrder, user]);

  const handleDelete = async (entryId) => {
    try {
      const { error } = await supabase.from('entradas_diarias').delete().eq('id', entryId);
      if (error) throw error;
      
      toast({ title: "Movimiento eliminado", description: "El movimiento ha sido eliminado exitosamente." });
      fetchEntriesAndBalance();
    } catch (error) {
       toast({ variant: "destructive", title: "Error al eliminar", description: "No se pudo eliminar el movimiento. Asegúrese de tener los permisos necesarios." });
       console.error("Error deleting entry:", error);
    }
  };

  const handleAttachClick = (entry) => {
    setSelectedEntryId(entry.id);
    setAttachDialogOpen(true);
  };

  const handleAttachSuccess = () => {
    fetchEntriesAndBalance();
  };

  const toggleSortOrder = () => {
    setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
  };
  
  const formatCurrency = (value) => {
    return value != null ? parseFloat(value).toLocaleString('es-AR', { style: 'currency', currency: 'ARS' }) : '$0,00';
  };

  // Identify automatic movements to exclude from manual receipt attachment
  const isAutomaticMovement = (entry) => {
    const tipo = (entry.tipo_ioe || '').toLowerCase();
    const razon = (entry.razon_social || '').toLowerCase();
    
    // Check for keywords indicating automatic movements
    const autoKeywords = [
      'cierre de caja', 'cierre caja',
      'pago empleados', 'pago sueldos', 'pago nómina', 'pago nomina',
      'pago cadetes', 'pago a cadetes',
      'sistema', 'automático', 'automatico'
    ];
    
    return autoKeywords.some(keyword => tipo.includes(keyword) || razon.includes(keyword));
  };

  return (
    <Card className="w-full shadow-lg">
      <CardHeader>
        <CardTitle className="text-2xl text-primary flex items-center">
          <Eye className="w-6 h-6 mr-2" /> Visualizar Planilla Diaria
        </CardTitle>
        <CardDescription>
          Seleccione la sucursal y el mes (YYYY-MM) para ver los registros. El saldo mensual se muestra al final.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
          <div>
            <Label htmlFor="branch-view" className="text-foreground font-semibold">Sucursal</Label>
            <Select onValueChange={handleBranchChange} value={selectedBranchId || ''} disabled={loadingBranches || isLoading || userRole === 'gerente'}>
              <SelectTrigger id="branch-view">
                <SelectValue placeholder={loadingBranches ? "Cargando..." : "Seleccione sucursal"} />
              </SelectTrigger>
              <SelectContent>
                {availableBranches.map(branch => (
                  <SelectItem key={branch.id} value={branch.id.toString()}>{branch.nombre}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="monthYear-view" className="text-foreground font-semibold">Mes y Año (YYYY-MM)</Label>
            <Input type="month" id="monthYear-view" value={monthYear} onChange={handleMonthChange} disabled={isLoading} className="bg-input border-border focus:border-primary" />
          </div>
          <Button onClick={fetchEntriesAndBalance} className="w-full md:w-auto bg-primary text-primary-foreground hover:bg-primary/90" disabled={isLoading || !selectedBranchId || !monthYear || !user}>
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
            Consultar
          </Button>
        </div>

        {isLoading && (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-10 w-10 animate-spin text-primary" />
            <p className="ml-3 text-lg text-muted-foreground">Cargando entradas...</p>
          </div>
        )}

        {!isLoading && entries.length > 0 && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="overflow-x-auto rounded-lg border border-border">
              <Table>
                <TableHeader className="bg-muted/50">
                  <TableRow>
                    <TableHead className="cursor-pointer hover:bg-muted" onClick={toggleSortOrder}>
                      Fecha {sortOrder === 'asc' ? <ArrowUp className="inline h-4 w-4" /> : <ArrowDown className="inline h-4 w-4" />}
                    </TableHead>
                    <TableHead>Monto</TableHead>
                    <TableHead>IOE</TableHead>
                    <TableHead>Tipo IOE</TableHead>
                    <TableHead>Razón Social</TableHead>
                    <TableHead>Observaciones</TableHead>
                    <TableHead className="text-right">Debe</TableHead>
                    <TableHead className="text-right">Haber</TableHead>
                    <TableHead>Comprobante</TableHead>
                    {(userRole === 'admin' || userRole === 'gerente') && <TableHead>Acciones</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {entries.map((entry) => {
                    const canAttach = !entry.comprobante_url && isWithin48Hours(entry.creado_en) && !isAutomaticMovement(entry);

                    return (
                      <TableRow key={entry.id}>
                        <TableCell>{formatDateForDisplay(entry.fecha)}</TableCell>
                        <TableCell>{formatCurrency(entry.monto)}</TableCell>
                        <TableCell>{entry.ioe}</TableCell>
                        <TableCell>{entry.tipo_ioe}</TableCell>
                        <TableCell>{entry.razon_social}</TableCell>
                        <TableCell>{entry.observaciones}</TableCell>
                        <TableCell className="text-right">{formatCurrency(entry.debe)}</TableCell>
                        <TableCell className="text-right">{formatCurrency(entry.haber)}</TableCell>
                        <TableCell>
                          {entry.comprobante_url ? (
                            <a href={entry.comprobante_url} target="_blank" rel="noopener noreferrer" className="flex items-center text-primary hover:underline">
                              <ExternalLink className="h-4 w-4 mr-1" /> Ver
                            </a>
                          ) : canAttach ? (
                            <Button variant="outline" size="sm" onClick={() => handleAttachClick(entry)}>
                              <Paperclip className="h-3 w-3 mr-1" /> Adjuntar
                            </Button>
                          ) : (
                            <span className="text-muted-foreground text-xs italic">
                              {!isWithin48Hours(entry.creado_en) && !entry.comprobante_url ? 'Expirado' : 
                               isAutomaticMovement(entry) ? 'Automático' : 'N/A'}
                            </span>
                          )}
                        </TableCell>
                        {(userRole === 'admin' || userRole === 'gerente') && (
                          <TableCell>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive/80">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>¿Está seguro?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Esta acción no se puede deshacer. Esto eliminará permanentemente el movimiento de la planilla diaria y recalculará los saldos.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => handleDelete(entry.id)} className="bg-destructive hover:bg-destructive/90">
                                    Eliminar
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </TableCell>
                        )}
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </motion.div>
            <div className="mt-4 p-4 bg-muted rounded-lg text-right">
              <span className="text-lg font-semibold text-primary">Saldo Final del Mes: {formatCurrency(currentMonthBalance)}</span>
            </div>
          </>
        )}
        {!isLoading && entries.length === 0 && selectedBranchId && monthYear && (
             <p className="text-center text-muted-foreground py-6">No hay entradas para mostrar para la sucursal y mes seleccionados. 
             {currentMonthBalance !== null && ` Saldo del mes: ${formatCurrency(currentMonthBalance)}`}
             </p>
        )}
      </CardContent>

      <AttachReceiptDialog 
        isOpen={attachDialogOpen} 
        onClose={() => setAttachDialogOpen(false)}
        entryId={selectedEntryId}
        sucursalId={selectedBranchId}
        onSuccess={handleAttachSuccess}
      />
    </Card>
  );
};

export default ViewSheetSection;