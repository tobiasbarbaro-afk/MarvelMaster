import React, { useState } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
    import { Trash2, Loader2, AlertTriangle } from 'lucide-react';
    import { calculateAndSaveCurrentMonthBalance } from '@/services/balanceService';
    import { logModificationAndNotify } from '@/lib/modificationLogger';
    import { useBranch } from '@/contexts/BranchContext';
    import { useAuth } from '@/hooks/useAuth';

    const ClearSheetSection = ({ supabase, toast, user, availableBranches, selectedBranchId: propSelectedBranchId, setSelectedBranchId: propSetSelectedBranchId, loadingBranches, getBranchNameById }) => {
      
      const contextSelectedBranchId = useBranch().selectedBranchId;
      const contextSetSelectedBranchId = useBranch().setSelectedBranchId;
      
      const selectedBranchId = propSelectedBranchId !== undefined ? propSelectedBranchId : contextSelectedBranchId;
      const setSelectedBranchId = propSetSelectedBranchId !== undefined ? propSetSelectedBranchId : contextSetSelectedBranchId;

      const [monthYear, setMonthYear] = useState(new Date().toISOString().slice(0, 7));
      const [isProcessing, setIsProcessing] = useState(false);
      const { fetchBranches } = useBranch();
      const { userRole } = useAuth();


      const handleBranchChange = (value) => {
        setSelectedBranchId(value); 
      };

      const handleClearSheet = async () => {
        if (!selectedBranchId || !monthYear || !user || !user.email) {
          toast({ variant: "destructive", title: "Error", description: "Por favor, seleccione sucursal, mes y asegúrese de estar autenticado." });
          return;
        }
        setIsProcessing(true);

        try {
          const year = parseInt(monthYear.slice(0, 4));
          const month = parseInt(monthYear.slice(5, 7));
          const firstDayOfMonth = `${year}-${month.toString().padStart(2, '0')}-01`;
          const lastDayOfMonth = new Date(year, month, 0).getDate();
          const lastDayOfMonthStr = `${year}-${month.toString().padStart(2, '0')}-${lastDayOfMonth.toString().padStart(2, '0')}`;

          const { error: deleteError } = await supabase
            .from('entradas_diarias')
            .delete()
            .eq('sucursal_id', parseInt(selectedBranchId))
            .gte('fecha', firstDayOfMonth)
            .lte('fecha', lastDayOfMonthStr);

          if (deleteError) {
            throw new Error(`Error eliminando entradas: ${deleteError.message}`);
          }
          
          await calculateAndSaveCurrentMonthBalance(parseInt(selectedBranchId), monthYear, user.email);
          await logModificationAndNotify(supabase, toast, getBranchNameById, parseInt(selectedBranchId), monthYear, user.email, 'vaciado_manual');
          
          toast({ title: "Éxito", description: `Planilla diaria para la sucursal y mes ${monthYear} vaciada y saldo recalculado.` });
          fetchBranches();

        } catch (error) {
          console.error("Error durante el vaciado:", error);
          toast({ variant: "destructive", title: "Error al Vaciar", description: error.message });
        } finally {
          setIsProcessing(false);
        }
      };

      return (
        <Card className="w-full max-w-lg mx-auto shadow-lg border-destructive/50">
          <CardHeader>
            <CardTitle className="text-2xl text-destructive flex items-center">
              <Trash2 className="w-6 h-6 mr-2" /> Vaciar Planilla Diaria
            </CardTitle>
            <CardDescription>
              Seleccione la sucursal y el mes (YYYY-MM) para eliminar todas las entradas de la planilla diaria.
              Esta acción es irreversible. El saldo del mes se recalculará.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label htmlFor="branch-clear" className="text-foreground font-semibold">Sucursal</Label>
              <Select onValueChange={handleBranchChange} value={selectedBranchId || ''} disabled={loadingBranches || isProcessing || userRole === 'gerente'}>
                <SelectTrigger id="branch-clear">
                  <SelectValue placeholder={loadingBranches ? "Cargando..." : "Seleccione sucursal"} />
                </SelectTrigger>
                <SelectContent>
                  {availableBranches.map(branch => (
                    <SelectItem key={branch.id} value={branch.id.toString()}>{branch.nombre}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="monthYear-clear" className="text-foreground font-semibold">Mes y Año (YYYY-MM)</Label>
              <Input type="month" id="monthYear-clear" value={monthYear} onChange={(e) => setMonthYear(e.target.value)} disabled={isProcessing} className="bg-input border-border focus:border-primary" />
            </div>
            <div className="p-3 rounded-md bg-red-50 border border-red-300 text-red-700">
                <div className="flex">
                    <div className="flex-shrink-0">
                        <AlertTriangle className="h-5 w-5 text-red-400" aria-hidden="true" />
                    </div>
                    <div className="ml-3">
                        <h3 className="text-sm font-medium">¡Advertencia!</h3>
                        <div className="mt-1 text-sm">
                            <p>Esta acción eliminará permanentemente todos los registros de la planilla para la sucursal y el mes seleccionados. No se podrá deshacer.</p>
                        </div>
                    </div>
                </div>
            </div>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" className="w-full" disabled={isProcessing || !selectedBranchId || !monthYear}>
                  {isProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Trash2 className="mr-2 h-4 w-4" />}
                  {isProcessing ? 'Procesando...' : 'Vaciar Planilla'}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent className="bg-card border-border">
                <AlertDialogHeader>
                  <AlertDialogTitle className="text-destructive">¿Está absolutamente seguro?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Esta acción no se puede deshacer. Se eliminarán todos los datos de la planilla para la sucursal <span className="font-semibold">{getBranchNameById(selectedBranchId)}</span> y el mes <span className="font-semibold">{monthYear}</span>. El saldo será recalculado.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel disabled={isProcessing}>Cancelar</AlertDialogCancel>
                  <AlertDialogAction onClick={handleClearSheet} className="bg-destructive hover:bg-destructive/90" disabled={isProcessing}>
                    {isProcessing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Sí, vaciar planilla
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </CardContent>
        </Card>
      );
    };

    export default ClearSheetSection;