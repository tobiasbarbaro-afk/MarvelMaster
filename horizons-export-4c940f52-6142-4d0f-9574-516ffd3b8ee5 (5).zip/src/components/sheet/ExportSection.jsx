import React, { useState } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { DownloadCloud, Loader2 } from 'lucide-react';
    import { exportToExcel } from '@/lib/sheetUtils';
    import { calculateAndSaveCurrentMonthBalance, getMonthlyBalanceForDisplay } from '@/services/balanceService';
    import { useAuth } from '@/hooks/useAuth';
    
    const ExportSection = ({ supabase, toast, availableBranches, selectedBranchId, setSelectedBranchId, loadingBranches }) => {
      const [monthYear, setMonthYear] = useState(new Date().toISOString().slice(0, 7));
      const [isProcessing, setIsProcessing] = useState(false);
      const { user } = useAuth();
    
      const handleBranchChange = (value) => {
        setSelectedBranchId(value); 
      };
    
      const handleExport = async () => {
        if (!selectedBranchId || !monthYear || !user || !user.email) {
          toast({ variant: "destructive", title: "Error", description: "Por favor, seleccione sucursal, mes y asegúrese de estar autenticado." });
          return;
        }
        setIsProcessing(true);
    
        try {
          await calculateAndSaveCurrentMonthBalance(parseInt(selectedBranchId), monthYear, user.email);
          const finalMonthBalance = await getMonthlyBalanceForDisplay(parseInt(selectedBranchId), monthYear);
    
          const { data, error } = await supabase
            .from('entradas_diarias')
            .select('fecha, ioe, tipo_ioe, razon_social, debe, haber, observaciones, saldo, comprobante_url') 
            .eq('sucursal_id', parseInt(selectedBranchId))
            .gte('fecha', `${monthYear}-01`)
            .lte('fecha', `${monthYear}-${new Date(parseInt(monthYear.slice(0,4)), parseInt(monthYear.slice(5,7)), 0).getDate()}`)
            .order('fecha', { ascending: true })
            .order('creado_en', { ascending: true });
    
          if (error) {
            throw new Error(`Error obteniendo datos para exportar: ${error.message}`);
          }
    
          const branchName = availableBranches.find(b => b.id.toString() === selectedBranchId)?.nombre || 'Sucursal';
          const fileName = `Planilla_Diaria_${branchName.replace(/\s+/g, '_')}_${monthYear}`;
          
          let dataForSheet = [];
          if (data && data.length > 0) {
             dataForSheet = data.map(entry => ({
              'Fecha': entry.fecha,
              'IOE': entry.ioe,
              'Tipo': entry.tipo_ioe,
              'Razón Social': entry.razon_social,
              'Debe': entry.debe,
              'Haber': entry.haber,
              'Saldo': entry.saldo,
              'Observaciones': entry.observaciones,
              'Comprobante': entry.comprobante_url,
            }));
          }
    
          dataForSheet.push({}); 
          dataForSheet.push({
            'Fecha': 'SALDO FINAL DEL MES',
            'Saldo': finalMonthBalance !== null ? parseFloat(finalMonthBalance).toLocaleString('es-AR', {style: 'currency', currency: 'ARS'}) : 'N/A'
          });
          
          const sheets = [{
            sheetName: 'Planilla Diaria',
            data: dataForSheet,
          }];
    
          exportToExcel({ sheets, fileName });
    
          toast({ title: "Éxito", description: "Planilla diaria exportada correctamente." });
    
        } catch (error) {
          console.error("Error durante la exportación:", error);
          toast({ variant: "destructive", title: "Error de Exportación", description: error.message });
        } finally {
          setIsProcessing(false);
        }
      };
      
      const { userRole } = useAuth();
    
      return (
        <Card className="w-full max-w-lg mx-auto shadow-lg">
          <CardHeader>
            <CardTitle className="text-2xl text-primary flex items-center">
              <DownloadCloud className="w-6 h-6 mr-2" /> Exportar Planilla Diaria
            </CardTitle>
            <CardDescription>
              Seleccione la sucursal y el mes (YYYY-MM) para exportar la planilla diaria. El saldo del mes se incluirá al final.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label htmlFor="branch-export" className="text-foreground font-semibold">Sucursal</Label>
              <Select onValueChange={handleBranchChange} value={selectedBranchId || ''} disabled={loadingBranches || isProcessing || userRole === 'gerente'}>
                <SelectTrigger id="branch-export">
                    <SelectValue placeholder={loadingBranches ? "Cargando..." : "Seleccione sucursal"} />
                </SelectTrigger>
                <SelectContent>
                    {availableBranches.map(branch => (
                      <SelectItem key={branch.id} value={branch.id.toString()}>{branch.nombre}</SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="monthYear-export" className="text-foreground font-semibold">Mes y Año (YYYY-MM)</Label>
              <Input type="month" id="monthYear-export" value={monthYear} onChange={(e) => setMonthYear(e.target.value)} disabled={isProcessing} className="bg-input border-border focus:border-primary" />
            </div>
            <Button onClick={handleExport} className="w-full bg-primary text-primary-foreground hover:bg-primary/90" disabled={isProcessing || !selectedBranchId || !monthYear}>
              {isProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <DownloadCloud className="mr-2 h-4 w-4" />}
              {isProcessing ? 'Procesando...' : 'Exportar Planilla Diaria'}
            </Button>
          </CardContent>
        </Card>
      );
    };
    
    export default ExportSection;