import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, Upload } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';

const AttachReceiptDialog = ({ isOpen, onClose, entryId, sucursalId, onSuccess }) => {
  const [file, setFile] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleUpload = async () => {
    if (!file || !entryId || !sucursalId) return;

    setIsUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}.${fileExt}`;
      const filePath = `${sucursalId}/${entryId}/${fileName}`;

      // 1. Upload file
      const { error: uploadError } = await supabase.storage
        .from('comprobantes-entradas-diarias')
        .upload(filePath, file);

      if (uploadError) {
        throw new Error(`Error al subir archivo: ${uploadError.message}`);
      }

      // 2. Get Public URL
      const { data: { publicUrl } } = supabase.storage
        .from('comprobantes-entradas-diarias')
        .getPublicUrl(filePath);

      // 3. Update entry
      const { error: updateError } = await supabase
        .from('entradas_diarias')
        .update({ comprobante_url: publicUrl })
        .eq('id', entryId);

      if (updateError) {
         throw new Error(`Error al actualizar registro: ${updateError.message}`);
      }

      toast({
        title: "Éxito",
        description: "Comprobante adjuntado correctamente.",
      });

      if (onSuccess) onSuccess();
      onClose();
      setFile(null);

    } catch (error) {
      console.error('Upload error:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Adjuntar Comprobante</DialogTitle>
          <DialogDescription>
            Seleccione el archivo (PDF o imagen) para adjuntar a este movimiento.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid w-full max-w-sm items-center gap-1.5">
            <Label htmlFor="receipt">Comprobante</Label>
            <Input 
              id="receipt" 
              type="file" 
              accept=".pdf,image/*" 
              onChange={handleFileChange}
              disabled={isUploading}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isUploading}>
            Cancelar
          </Button>
          <Button onClick={handleUpload} disabled={!file || isUploading}>
            {isUploading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Subiendo...
              </>
            ) : (
              <>
                <Upload className="mr-2 h-4 w-4" />
                Adjuntar
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AttachReceiptDialog;