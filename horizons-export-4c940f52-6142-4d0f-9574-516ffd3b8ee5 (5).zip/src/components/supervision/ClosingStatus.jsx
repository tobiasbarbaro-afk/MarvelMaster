import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Loader2, Archive } from 'lucide-react';
import { subDays } from 'date-fns';
import { format as formatTz } from 'date-fns-tz';

const TIMEZONE = 'America/Argentina/Buenos_Aires';

const getShiftToCheck = () => {
    // We use current UTC time as base
    const now = new Date();
    
    // Get the hour in Buenos Aires directly from the timestamp
    const currentHourBA = parseInt(formatTz(now, 'H', { timeZone: TIMEZONE }));

    // Hasta las 15hs (BA time), mostramos Turno Noche del día anterior.
    // Después de las 15hs (BA time), mostramos Turno Mediodía del día corriente.
    if (currentHourBA < 15) { 
        // Subtract 24 hours to get "yesterday" safely
        const yesterday = subDays(now, 1);
        return { 
            // Format strictly in BA timezone to ensure we get the correct YYYY-MM-DD
            dateStr: formatTz(yesterday, 'yyyy-MM-dd', { timeZone: TIMEZONE }), 
            turno: 'Noche', 
            displayDate: yesterday 
        };
    } else { 
        return { 
            dateStr: formatTz(now, 'yyyy-MM-dd', { timeZone: TIMEZONE }), 
            turno: 'Mediodia', 
            displayDate: now 
        };
    }
};

const ClosingStatus = ({ selectedBranchId, branches, excludedBranches = [] }) => {
    const { toast } = useToast();
    const [statuses, setStatuses] = useState([]);
    const [loading, setLoading] = useState(true);
    const [currentShiftInfo, setCurrentShiftInfo] = useState(getShiftToCheck());

    const fetchStatuses = useCallback(async () => {
        setLoading(true);
        const shiftInfo = getShiftToCheck();
        setCurrentShiftInfo(shiftInfo);
        
        const { dateStr, turno } = shiftInfo;

        try {
            const { data, error } = await supabase
                .from('cierres_caja')
                .select('sucursal_id')
                .eq('fecha', dateStr)
                .eq('turno', turno);
            
            if (error) throw error;
            
            // Create a set of processed IDs as strings to ensure reliable comparison
            const processedBranchIds = new Set(data.map(item => String(item.sucursal_id)));

            const allBranchesStatus = branches
                .filter(branch => !excludedBranches.includes(branch.nombre))
                .map(branch => ({
                    id: branch.id,
                    name: branch.nombre,
                    // Convert branch.id to string for comparison
                    isProcessed: processedBranchIds.has(String(branch.id))
                }));

            setStatuses(allBranchesStatus);

        } catch (error) {
            console.error('Error fetching closing status:', error);
            // Only toast on real network errors, not empty data
            toast({ variant: 'destructive', title: 'Error', description: 'No se pudo verificar el estado de los cierres.' });
        } finally {
            setLoading(false);
        }
    }, [toast, branches, excludedBranches]);

    useEffect(() => {
        if (branches.length > 0) {
            const subscription = supabase
                .channel('cierres_caja_status_changes')
                .on('postgres_changes', { event: '*', schema: 'public', table: 'cierres_caja' }, fetchStatuses)
                .subscribe();

            fetchStatuses();
            
            return () => {
                supabase.removeChannel(subscription);
            };
        }
    }, [branches, fetchStatuses]);

    const filteredStatuses = selectedBranchId === 'all'
        ? statuses
        : statuses.filter(s => String(s.id) === String(selectedBranchId));
        
    const { turno, displayDate } = currentShiftInfo;
    
    // Format display date in BA timezone to match the logic
    const displayDateStr = formatTz(displayDate, 'dd/MM', { timeZone: TIMEZONE });

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-xl">
                    <Archive className="text-primary" /> Status Cierre de Caja
                </CardTitle>
                <CardDescription>
                    Verifica si el cierre del turno anterior ({turno} - {displayDateStr}) fue procesado.
                </CardDescription>
            </CardHeader>
            <CardContent>
                {loading ? (
                    <div className="flex justify-center items-center py-4"><Loader2 className="h-6 w-6 animate-spin" /></div>
                ) : (
                    <div className="space-y-3">
                        {filteredStatuses.map(status => (
                            <div key={status.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                                <span className="font-medium">{status.name}</span>
                                {status.isProcessed ? (
                                    <div className="h-6 w-6 rounded-full bg-green-500 shadow-sm ring-2 ring-green-500/20" title="Procesado" />
                                ) : (
                                    <div className="h-6 w-6 rounded-full bg-red-500 shadow-sm ring-2 ring-red-500/20" title="Pendiente" />
                                )}
                            </div>
                        ))}
                        {filteredStatuses.length === 0 && <p className="text-center text-muted-foreground">No hay datos para la sucursal seleccionada.</p>}
                    </div>
                )}
            </CardContent>
        </Card>
    );
};

export default ClosingStatus;