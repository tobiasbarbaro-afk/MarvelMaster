import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Loader2, History, Download, Calendar as CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { cn } from '@/lib/utils';

const OrderHistory = ({ selectedBranchId, excludedBranches = [] }) => {
    const { toast } = useToast();
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [dateFrom, setDateFrom] = useState(null);
    const [dateTo, setDateTo] = useState(null);
    const [productosMap, setProductosMap] = useState({});

    const fetchOrderData = useCallback(async () => {
        setLoading(true);
        try {
            const [productsRes, ordersRes] = await Promise.all([
                supabase.from('productos_centralizada').select('id, nombre, unidad_medida'),
                supabase.from('pedidos_centralizada').select('*, sucursales(nombre)').order('fecha_pedido', { ascending: false })
            ]);

            if (productsRes.error) throw productsRes.error;
            if (ordersRes.error) throw ordersRes.error;

            const pMap = productsRes.data.reduce((acc, p) => {
                acc[p.id] = { nombre: p.nombre, unidad_medida: p.unidad_medida };
                return acc;
            }, {});
            setProductosMap(pMap);

            // Filter out orders from excluded branches
            const filteredData = (ordersRes.data || []).filter(order => 
                !excludedBranches.includes(order.sucursales?.nombre)
            );
            
            setOrders(filteredData);
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: `No se pudo cargar el historial: ${error.message}` });
        } finally {
            setLoading(false);
        }
    }, [toast, excludedBranches]);

    useEffect(() => {
        fetchOrderData();
    }, [fetchOrderData]);

    const filteredOrders = useMemo(() => {
        return orders.filter(order => {
            const branchMatch = selectedBranchId === 'all' || order.sucursal_id.toString() === selectedBranchId;
            const orderDate = new Date(order.fecha_pedido);
            const from = dateFrom ? new Date(dateFrom.setHours(0, 0, 0, 0)) : null;
            const to = dateTo ? new Date(dateTo.setHours(23, 59, 59, 999)) : null;
            const dateMatch = (!from || orderDate >= from) && (!to || orderDate <= to);
            return branchMatch && dateMatch;
        });
    }, [orders, selectedBranchId, dateFrom, dateTo]);

    return (
        <Card className="h-full">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-xl">
                    <History className="text-primary" /> Historial de Pedidos
                </CardTitle>
                <CardDescription>
                    Todos los pedidos realizados a la centralizada.
                </CardDescription>
                <div className="flex flex-col sm:flex-row gap-2 pt-2">
                    <Popover>
                        <PopoverTrigger asChild>
                            <Button variant="outline" className={cn("w-full sm:w-auto justify-start text-left font-normal", !dateFrom && "text-muted-foreground")}>
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {dateFrom ? format(dateFrom, "PPP", { locale: es }) : <span>Desde</span>}
                            </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={dateFrom} onSelect={setDateFrom} initialFocus /></PopoverContent>
                    </Popover>
                    <Popover>
                        <PopoverTrigger asChild>
                            <Button variant="outline" className={cn("w-full sm:w-auto justify-start text-left font-normal", !dateTo && "text-muted-foreground")}>
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {dateTo ? format(dateTo, "PPP", { locale: es }) : <span>Hasta</span>}
                            </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={dateTo} onSelect={setDateTo} initialFocus /></PopoverContent>
                    </Popover>
                </div>
            </CardHeader>
            <CardContent>
                <div className="max-h-[600px] overflow-y-auto">
                    {loading ? (
                        <div className="flex justify-center items-center py-10"><Loader2 className="h-8 w-8 animate-spin" /></div>
                    ) : filteredOrders.length === 0 ? (
                        <p className="text-center text-muted-foreground py-10">No hay pedidos para los filtros seleccionados.</p>
                    ) : (
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Fecha</TableHead>
                                    <TableHead>Sucursal</TableHead>
                                    <TableHead>Productos</TableHead>
                                    <TableHead>Remito Firmado</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {filteredOrders.map(order => (
                                    <TableRow key={order.id}>
                                        <TableCell>{format(new Date(order.fecha_pedido), 'dd/MM/yyyy')}</TableCell>
                                        <TableCell>{order.sucursales.nombre}</TableCell>
                                        <TableCell>
                                            <ul className="text-xs list-disc list-inside">
                                                {order.productos.map((p, index) => (
                                                    <li key={`${order.id}-${p.producto_id}-${index}`}>
                                                        {productosMap[p.producto_id]?.nombre || 'N/A'}: {p.cantidad}
                                                    </li>
                                                ))}
                                            </ul>
                                        </TableCell>
                                        <TableCell>
                                            {order.remito_firmado_url ? (
                                                <Button asChild variant="ghost" size="icon">
                                                    <a href={order.remito_firmado_url} target="_blank" rel="noopener noreferrer">
                                                        <Download className="h-4 w-4 text-primary" />
                                                    </a>
                                                </Button>
                                            ) : (
                                                '-'
                                            )}
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    )}
                </div>
            </CardContent>
        </Card>
    );
};

export default OrderHistory;