import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Loader2, BookCheck } from 'lucide-react';
import { format } from 'date-fns';

const SheetStatus = ({ selectedBranchId, branches, excludedBranches = [] }) => {
    const { toast } = useToast();
    const [statuses, setStatuses] = useState([]);
    const [loading, setLoading] = useState(true);

    const fetchStatuses = useCallback(async () => {
        setLoading(true);
        try {
            const { data, error } = await supabase.rpc('get_last_entry_date_per_branch');
            if (error) throw error;
            
            const today = format(new Date(), 'yyyy-MM-dd');
            const statusMap = data.reduce((acc, item) => {
                acc[item.sucursal_id] = format(new Date(item.last_date), 'yyyy-MM-dd') === today;
                return acc;
            }, {});

            // Filter out excluded branches and map status
            const allBranchesStatus = branches
                .filter(branch => !excludedBranches.includes(branch.nombre))
                .map(branch => ({
                    id: branch.id,
                    name: branch.nombre,
                    isUpToDate: statusMap[branch.id] || false
                }));

            setStatuses(allBranchesStatus);

        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: 'No se pudo verificar el estado de las planillas.' });
        } finally {
            setLoading(false);
        }
    }, [toast, branches, excludedBranches]);

    useEffect(() => {
        if (branches.length > 0) {
            const subscription = supabase
                .channel('entradas_diarias_status_changes')
                .on('postgres_changes', { event: '*', schema: 'public', table: 'entradas_diarias' }, fetchStatuses)
                .subscribe();
            
            fetchStatuses();

            return () => {
                supabase.removeChannel(subscription);
            };
        }
    }, [branches, fetchStatuses]);

    const filteredStatuses = selectedBranchId === 'all'
        ? statuses
        : statuses.filter(s => s.id.toString() === selectedBranchId);

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-xl">
                    <BookCheck className="text-primary" /> Status Planilla Diaria
                </CardTitle>
                <CardDescription>
                    Verifica si la planilla está actualizada al día de hoy.
                </CardDescription>
            </CardHeader>
            <CardContent>
                {loading ? (
                    <div className="flex justify-center items-center py-4"><Loader2 className="h-6 w-6 animate-spin" /></div>
                ) : (
                    <div className="space-y-3">
                        {filteredStatuses.map(status => (
                            <div key={status.id} className="flex items-center justify-between p-3 border rounded-lg">
                                <span className="font-medium">{status.name}</span>
                                {status.isUpToDate ? (
                                    <div className="h-6 w-6 rounded-full bg-green-500" title="Actualizada" />
                                ) : (
                                    <div className="h-6 w-6 rounded-full bg-red-500" title="No Actualizada" />
                                )}
                            </div>
                        ))}
                         {filteredStatuses.length === 0 && <p className="text-center text-muted-foreground">No hay datos para la sucursal seleccionada.</p>}
                    </div>
                )}
            </CardContent>
        </Card>
    );
};

export default SheetStatus;