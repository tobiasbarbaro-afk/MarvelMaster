import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Loader2, CheckCircle, Eye, ShieldCheck } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import ClosingDetailDialog from '@/components/management/ClosingDetailDialog';

const SupervisionClosingList = ({ selectedBranchId, excludedBranches = [] }) => {
    const [closings, setClosings] = useState([]);
    const [loading, setLoading] = useState(true);
    const [verifyingId, setVerifyingId] = useState(null);
    const [selectedClosing, setSelectedClosing] = useState(null);
    const { toast } = useToast();

    // Filtro: Cierres verificados por Gerencia (Instancia 1 OK) pero NO por Admin (Instancia 2 Pendiente)
    const fetchSupervisionClosings = useCallback(async () => {
        setLoading(true);
        try {
            let query = supabase
                .from('cierres_caja')
                .select(`*, sucursales ( nombre ), user_profiles ( full_name )`)
                .eq('verificado_por_gerencia', true) 
                .not('verificado_por_admin', 'eq', true) // Excluir ya verificados por admin
                .order('fecha', { ascending: true });

            if (selectedBranchId !== 'all') {
                query = query.eq('sucursal_id', selectedBranchId);
            }

            const { data, error } = await query;
            if (error) throw error;

            // Filter out excluded branches
            const filteredData = (data || []).filter(item => 
                !excludedBranches.includes(item.sucursales?.nombre)
            );
            
            setClosings(filteredData);
        } catch (err) {
            console.error(err);
            toast({ variant: 'destructive', title: 'Error', description: 'Error cargando lista de supervisión.' });
        } finally {
            setLoading(false);
        }
    }, [selectedBranchId, toast, excludedBranches]);

    useEffect(() => {
        fetchSupervisionClosings();
    }, [fetchSupervisionClosings]);

    const handleVerify = async (closing) => {
        setVerifyingId(closing.id);
        try {
            // AQUÍ NO IMPACTAMOS PLANILLA. Solo marcamos el check final.
            // El dinero ya debió impactarse en el paso anterior (Gerencia) o en la creación si fue admin.
            
            const { error: updateError } = await supabase
                .from('cierres_caja')
                .update({ verificado_por_admin: true })
                .eq('id', closing.id);

            if (updateError) throw new Error(updateError.message);

            toast({ title: 'Verificado', description: `Validación de supervisión completada.` });
            fetchSupervisionClosings();
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: error.message });
        } finally {
            setVerifyingId(null);
        }
    };

    if (loading) return <div className="flex justify-center p-4"><Loader2 className="animate-spin" /></div>;
    if (closings.length === 0) return <p className="text-muted-foreground text-center py-4">Sin pendientes de supervisión.</p>;

    return (
        <div className="space-y-3">
            {closings.map((closing) => (
                <div key={closing.id} className="flex flex-col sm:flex-row justify-between items-center p-4 border rounded-lg bg-background gap-4 border-l-4 border-l-blue-500">
                    <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                            <span className="bg-blue-100 text-blue-800 text-xs px-2 py-0.5 rounded-full font-semibold">{closing.sucursales?.nombre}</span>
                            <p className="font-semibold">{new Date(closing.fecha).toLocaleDateString()} - {closing.turno}</p>
                        </div>
                        <p className="text-sm">Total: <strong>${closing.total_general?.toLocaleString('es-AR')}</strong></p>
                        <div className="mt-1 text-xs text-green-600 flex items-center gap-1">
                            <CheckCircle className="h-3 w-3"/> Aprobado por Gerencia
                        </div>
                    </div>
                    <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => setSelectedClosing(closing)}><Eye className="mr-2 h-4 w-4" /> Ver</Button>
                        <Button size="sm" className="bg-blue-600 hover:bg-blue-700" onClick={() => handleVerify(closing)} disabled={verifyingId === closing.id}>
                            {verifyingId === closing.id ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ShieldCheck className="mr-2 h-4 w-4" />}
                            Validar Final
                        </Button>
                    </div>
                </div>
            ))}
            <ClosingDetailDialog isOpen={!!selectedClosing} onClose={() => setSelectedClosing(null)} closing={selectedClosing} />
        </div>
    );
};

export default SupervisionClosingList;