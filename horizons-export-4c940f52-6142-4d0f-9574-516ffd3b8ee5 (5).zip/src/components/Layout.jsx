
import React, { useState, useEffect } from 'react';
import { Link, useNavigate, Outlet, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Home, LogOut, Users, Building, ShoppingCart, DollarSign, Settings, Menu, X, Package, Archive, Wallet, ClipboardList, Bike, ShieldCheck, LayoutDashboard, Truck, Box, Banknote, Briefcase, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import { Toaster } from '@/components/ui/toaster';

const navItems = [
  // Uncategorized
  { name: 'Módulo de Supervisión', icon: LayoutDashboard, path: '/supervision', roles: ['admin'] },
  { name: 'Panel Principal', icon: Home, path: '/', roles: ['gerente'] },
  { name: 'Gerencia', icon: ShieldCheck, path: '/management', roles: ['admin', 'gerente'] },
  
  // CAJA
  { name: 'Caja Fuerte', icon: DollarSign, path: '/safe-box', roles: ['admin', 'gerente', 'mostrador'], category: 'CAJA' },
  { name: 'Cierre de Caja', icon: Archive, path: '/cash-closing', roles: ['admin', 'gerente', 'mostrador'], category: 'CAJA' },
  { name: 'Préstamos', icon: Banknote, path: '/loans', roles: ['admin', 'gerente'], category: 'CAJA' },
  
  // PAGOS
  { name: 'Pagos Proveedores', icon: DollarSign, path: '/pagos', roles: ['admin'], category: 'PAGOS' },
  { name: 'Pago de Empleados', icon: Wallet, path: '/employee-payments', roles: ['admin', 'gerente'], category: 'PAGOS' },
  { name: 'Pago de Cadetes', icon: Bike, path: '/cadet-payments', roles: ['admin', 'gerente'], category: 'PAGOS' },
  
  // INVENTARIO
  { name: 'Pedidos Centralizada', icon: Package, path: '/centralized-orders', roles: ['admin', 'centralizada', 'gerente', 'cocina'], category: 'INVENTARIO' },
  { name: 'Pedidos Proveedores', icon: Truck, path: '/provider-orders', roles: ['admin', 'centralizada', 'gerente', 'cocina'], category: 'INVENTARIO' },
  { name: 'Stock Fin de Turno', icon: ClipboardList, path: '/stock-turno', roles: ['admin', 'centralizada', 'gerente', 'cocina'], category: 'INVENTARIO' },
  { name: 'Productos e Insumos', icon: Box, path: '/products', roles: ['admin', 'cocina'], category: 'INVENTARIO' },
  
  // ADMINISTRACIÓN
  { name: 'Empleados', icon: Users, path: '/employees', roles: ['admin', 'gerente'], category: 'ADMINISTRACIÓN' },
  { name: 'Sucursales', icon: Building, path: '/branches', roles: ['admin'], category: 'ADMINISTRACIÓN' },
  { name: 'Proveedores', icon: ShoppingCart, path: '/suppliers', roles: ['admin'], category: 'ADMINISTRACIÓN' },
  { name: 'Configuración', icon: Settings, path: '/settings', roles: ['admin'], category: 'ADMINISTRACIÓN' },
];

const CATEGORIES = [
  { id: 'CAJA', name: 'CAJA', icon: Briefcase },
  { id: 'PAGOS', name: 'PAGOS', icon: DollarSign },
  { id: 'INVENTARIO', name: 'INVENTARIO', icon: Package },
  { id: 'ADMINISTRACIÓN', name: 'ADMINISTRACIÓN', icon: Settings },
];

const Layout = () => {
  const { user, userRole, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  const [expandedCategories, setExpandedCategories] = useState(() => {
    try {
      const saved = localStorage.getItem('sidebarCategories');
      return saved ? JSON.parse(saved) : CATEGORIES.map(c => c.id);
    } catch {
      return CATEGORIES.map(c => c.id);
    }
  });

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const toggleCategory = (categoryId) => {
    setExpandedCategories(prev => {
      const newExpanded = prev.includes(categoryId) 
        ? prev.filter(c => c !== categoryId) 
        : [...prev, categoryId];
      localStorage.setItem('sidebarCategories', JSON.stringify(newExpanded));
      return newExpanded;
    });
  };

  const sidebarVariants = {
    open: { x: 0, transition: { type: 'spring', stiffness: 300, damping: 30 } },
    closed: { x: '-100%', transition: { type: 'spring', stiffness: 300, damping: 30 } },
  };

  const NavLink = ({ item, isNested = false }) => (
    <Link
      to={item.path}
      onClick={() => { if (window.innerWidth < 768) setIsSidebarOpen(false);}}
      className={`flex items-center px-4 py-2.5 text-sm font-medium rounded-md transition-colors duration-150 ease-in-out
        ${isNested ? 'ml-6 border-l border-border pl-4 my-0.5' : 'my-1'}
        ${location.pathname === item.path
          ? 'bg-primary text-primary-foreground border-transparent'
          : 'text-foreground hover:bg-muted hover:text-accent-foreground'
        }`}
    >
      <item.icon className={`mr-3 flex-shrink-0 ${isNested ? 'w-4 h-4' : 'w-5 h-5'}`} />
      <span className="truncate">{item.name}</span>
    </Link>
  );
  
  const filteredNavItems = navItems.filter(item => item.roles.includes(userRole));
  
  const uncategorizedItems = filteredNavItems.filter(item => !item.category);
  const itemsByCategory = filteredNavItems.reduce((acc, item) => {
    if (item.category) {
      if (!acc[item.category]) acc[item.category] = [];
      acc[item.category].push(item);
    }
    return acc;
  }, {});

  const pageTitle = filteredNavItems.find(item => item.path === location.pathname)?.name || 
                    (location.pathname.startsWith('/safe-box') ? 'Caja Fuerte' : 
                    userRole === 'centralizada' ? 'Pedidos Centralizada' : 'Panel Principal');

  const displayRoleName = userRole === 'gerente' ? 'Jefe de Sucursal' : (userRole || 'Usuario');

  return (
    <div className="flex h-screen bg-background text-foreground">
      {/* Mobile Backdrop */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 md:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      <motion.aside
        initial={false}
        animate={isSidebarOpen ? 'open' : (window.innerWidth < 768 ? 'closed' : 'open')}
        variants={sidebarVariants}
        className={`fixed inset-y-0 left-0 z-40 flex flex-col w-64 bg-card border-r border-border transform 
                    md:relative md:translate-x-0 md:flex md:z-auto ${isSidebarOpen ? 'flex shadow-xl' : 'hidden md:flex'}`}
      >
        <div className="flex items-center justify-center h-24 border-b border-border px-4 flex-shrink-0">
          <Link to="/" className="flex items-center" onClick={() => {if (window.innerWidth < 768) setIsSidebarOpen(false);}}>
            <img 
              alt="Marvel Master Logo" 
              className="h-16 w-auto max-w-full object-contain" 
              src="https://horizons-cdn.hostinger.com/4c940f52-6142-4d0f-9574-516ffd3b8ee5/9cdf72b69ad1b6e1f7373328801839ef.png" 
            />
          </Link>
        </div>
        
        <nav className="flex-grow p-4 space-y-1 overflow-y-auto overflow-x-hidden custom-scrollbar">
          {uncategorizedItems.map((item) => (
            <NavLink key={item.name} item={item} />
          ))}

          {CATEGORIES.map(category => {
            const categoryItems = itemsByCategory[category.id];
            if (!categoryItems || categoryItems.length === 0) return null;
            
            const isExpanded = expandedCategories.includes(category.id);

            return (
              <div key={category.id} className="pt-2">
                <button
                  onClick={() => toggleCategory(category.id)}
                  className="w-full flex items-center justify-between px-3 py-2 text-sm font-semibold text-muted-foreground uppercase tracking-wider rounded-md hover:bg-muted/50 hover:text-foreground transition-colors group"
                >
                  <div className="flex items-center">
                    <category.icon className="w-4 h-4 mr-2 group-hover:text-primary transition-colors" />
                    {category.name}
                  </div>
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 transition-transform duration-200" />
                  ) : (
                    <ChevronDown className="w-4 h-4 transition-transform duration-200" />
                  )}
                </button>
                
                <AnimatePresence initial={false}>
                  {isExpanded && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.2, ease: "easeInOut" }}
                      className="overflow-hidden"
                    >
                      <div className="py-1">
                        {categoryItems.map((item) => (
                          <NavLink key={item.name} item={item} isNested={true} />
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </nav>

        <div className="p-4 border-t border-border flex-shrink-0 bg-card">
          {user && (
            <div className="mb-4 text-center">
              <p className="text-sm font-medium truncate">{user.email}</p>
              <p className="text-xs text-muted-foreground">Rol: <span className="capitalize">{displayRoleName}</span></p>
            </div>
          )}
          <Button variant="outline" className="w-full text-primary border-primary hover:bg-primary hover:text-primary-foreground group" onClick={handleLogout}>
            <LogOut className="w-4 h-4 mr-2 group-hover:-translate-x-1 transition-transform" />
            Cerrar Sesión
          </Button>
        </div>
      </motion.aside>

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="md:hidden sticky top-0 z-30 flex items-center justify-between p-4 bg-primary text-primary-foreground shadow-md h-20">
            <Button
                variant="ghost"
                size="icon"
                className="text-primary-foreground hover:bg-primary/80"
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                aria-label={isSidebarOpen ? "Cerrar menú" : "Abrir menú"}
            >
                {isSidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
            <h2 className="text-xl font-semibold truncate px-2">{pageTitle}</h2>
            <div className="w-8"></div>
        </header>

        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-background p-4 md:p-8">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="h-full"
          >
            <Outlet />
          </motion.div>
        </main>
      </div>
      <Toaster />
      <style dangerouslySetInnerHTML={{__html: `
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background-color: hsl(var(--border));
          border-radius: 4px;
        }
      `}} />
    </div>
  );
};

export default Layout;
