import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Loader2, CheckCircle2, XCircle, HelpCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { subDays, format } from 'date-fns';
import { es } from 'date-fns/locale';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Button } from '@/components/ui/button';
import { AnimatePresence, motion } from 'framer-motion';

const StatusIcon = ({ status, tooltipText }) => {
  const icons = {
    completed: <CheckCircle2 className="text-green-500" />,
    missing: <XCircle className="text-red-500" />,
    unknown: <HelpCircle className="text-gray-500" />,
  };
  const icon = icons[status] || icons.unknown;

  return (
    <TooltipProvider delayDuration={100}>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className="w-8 h-8 rounded-full flex items-center justify-center bg-muted">
            {icon}
          </div>
        </TooltipTrigger>
        <TooltipContent>
          <p>{tooltipText}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

const StockStatusDashboard = ({ sucursalId }) => {
  const [statusByDay, setStatusByDay] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isExpanded, setIsExpanded] = useState(false);

  const checkStockStatus = useCallback(async () => {
    if (!sucursalId) return;
    setLoading(true);

    const today = new Date();
    // We want to check the last 7 days including today
    const daysToFetch = 7; 
    const dateArray = Array.from({ length: daysToFetch }, (_, i) => subDays(today, i));
    const formattedDates = dateArray.map((d) => format(d, 'yyyy-MM-dd'));

    try {
      // Fetch all stock records for the selected branch and date range
      // We only need to know if ANY record exists for a given date/shift combination
      const { data, error } = await supabase
        .from('stock_turno')
        .select('fecha, turno')
        .eq('sucursal_id', sucursalId)
        .in('fecha', formattedDates);

      if (error) throw error;

      const dailyStatuses = dateArray.map((date) => {
        const dateStr = format(date, 'yyyy-MM-dd');
        
        // Check if we have at least one record for 'Mediodia' on this date
        const hasNoon = data.some(
          (d) => d.fecha === dateStr && d.turno === 'Mediodia'
        );

        // Check if we have at least one record for 'Noche' on this date
        const hasNight = data.some(
          (d) => d.fecha === dateStr && d.turno === 'Noche'
        );

        return {
          date,
          noon: hasNoon ? 'completed' : 'missing',
          night: hasNight ? 'completed' : 'missing',
        };
      });

      setStatusByDay(dailyStatuses);
    } catch (err) {
      console.error('Error checking stock status:', err);
    } finally {
      setLoading(false);
    }
  }, [sucursalId]);

  useEffect(() => {
    checkStockStatus();
  }, [checkStockStatus]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-24">
        <Loader2 className="animate-spin" />
      </div>
    );
  }

  // First 2 days for the main view (Today and Yesterday usually, or just last 2 days in array)
  const last48h = statusByDay.slice(0, 2);
  // The rest for the expanded view
  const last7daysExtra = statusByDay.slice(2);

  return (
    <div className="space-y-4">
      {/* Bloque Últimas 48hs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
        {last48h.map(({ date, noon, night }) => {
          const dateStr = format(date, 'yyyy-MM-dd');
          return (
            <React.Fragment key={dateStr}>
              <div
                key={`${dateStr}-noon`}
                className="flex flex-col items-center gap-2 p-3 rounded-lg bg-background border"
              >
                <p className="font-semibold capitalize">
                  {format(date, 'EEEE dd/MM', { locale: es })}
                </p>
                <p className="text-sm text-muted-foreground -mt-2">Mediodía</p>
                <StatusIcon
                  status={noon}
                  tooltipText={noon === 'completed' ? 'Completado' : 'Pendiente'}
                />
              </div>
              <div
                key={`${dateStr}-night`}
                className="flex flex-col items-center gap-2 p-3 rounded-lg bg-background border"
              >
                <p className="font-semibold capitalize">
                  {format(date, 'EEEE dd/MM', { locale: es })}
                </p>
                <p className="text-sm text-muted-foreground -mt-2">Noche</p>
                <StatusIcon
                  status={night}
                  tooltipText={night === 'completed' ? 'Completado' : 'Pendiente'}
                />
              </div>
            </React.Fragment>
          );
        })}
      </div>

      {/* Bloque “Mostrar más (Últimos 7 días)” */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center pt-4">
              {last7daysExtra.map(({ date, noon, night }) => {
                const dateStr = format(date, 'yyyy-MM-dd');
                return (
                  <React.Fragment key={dateStr}>
                    <div
                      key={`${dateStr}-noon`}
                      className="flex flex-col items-center gap-2 p-3 rounded-lg bg-background border"
                    >
                      <p className="font-semibold capitalize">
                        {format(date, 'EEEE dd/MM', { locale: es })}
                      </p>
                      <p className="text-sm text-muted-foreground -mt-2">Mediodía</p>
                      <StatusIcon
                        status={noon}
                        tooltipText={noon === 'completed' ? 'Completado' : 'Pendiente'}
                      />
                    </div>
                    <div
                      key={`${dateStr}-night`}
                      className="flex flex-col items-center gap-2 p-3 rounded-lg bg-background border"
                    >
                      <p className="font-semibold capitalize">
                        {format(date, 'EEEE dd/MM', { locale: es })}
                      </p>
                      <p className="text-sm text-muted-foreground -mt-2">Noche</p>
                      <StatusIcon
                        status={night}
                        tooltipText={night === 'completed' ? 'Completado' : 'Pendiente'}
                      />
                    </div>
                  </React.Fragment>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex justify-center pt-2">
        <Button variant="ghost" onClick={() => setIsExpanded(!isExpanded)}>
          {isExpanded ? (
            <>
              <ChevronUp className="mr-2 h-4 w-4" />
              Mostrar menos
            </>
          ) : (
            <>
              <ChevronDown className="mr-2 h-4 w-4" />
              Mostrar más (Últimos 7 días)
            </>
          )}
        </Button>
      </div>
    </div>
  );
};

export default StockStatusDashboard;