import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
// ScrollArea ya no es estrictamente necesario si usamos el div nativo
// import { ScrollArea } from '@/components/ui/scroll-area'; 
import { ExternalLink } from 'lucide-react';
import { normalizeAmountString } from '@/lib/sheetUtils';
import { paymentMethods } from '@/components/cash_closing/ClosingForm';

const ClosingDetailDialog = ({ isOpen, onClose, closing }) => {
    if (!closing) return null;

    const formatCurrency = (value) => {
        return new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS' }).format(value || 0);
    };

    const renderChannelValues = (channelName, values) => {
        if (!values) return null;
        // Filter out zero values
        const activeMethods = Object.entries(values).filter(([_, val]) => {
            const numVal = parseFloat(normalizeAmountString(val));
            return numVal > 0;
        });

        if (activeMethods.length === 0) return null;

        return (
            <div className="mb-4">
                <h4 className="font-semibold text-sm text-muted-foreground mb-2 uppercase">{channelName}</h4>
                <div className="space-y-1">
                    {activeMethods.map(([methodId, value]) => {
                        const label = paymentMethods.find(m => m.id === methodId)?.label || methodId;
                        const numVal = parseFloat(normalizeAmountString(value));
                        return (
                            <div key={methodId} className="flex justify-between text-sm">
                                <span>{label}:</span>
                                <span className="font-medium">{formatCurrency(numVal)}</span>
                            </div>
                        );
                    })}
                </div>
            </div>
        );
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            {/* max-h-[90vh] limita la altura del modal al 90% de la pantalla */}
            <DialogContent className="max-w-3xl max-h-[90vh] flex flex-col p-0 overflow-hidden gap-0">
                <DialogHeader className="p-6 pb-4 border-b">
                    <DialogTitle>Detalle del Cierre de Caja</DialogTitle>
                    <DialogDescription>
                        Revisa los detalles de {closing.user_profiles?.full_name || 'Usuario'} del {new Date(closing.fecha).toLocaleDateString('es-AR', { timeZone: 'UTC' })} - {closing.turno}.
                    </DialogDescription>
                </DialogHeader>

                {/* CAMBIO AQUÍ: Usamos un div con overflow-y-auto en lugar de ScrollArea */}
                <div className="flex-1 w-full overflow-y-auto">
                    <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Left Column: Values */}
                        <div>
                            {renderChannelValues('Valores Ingresados (Mostrador)', closing.valores_ingresados?.mostrador)}
                            {renderChannelValues('Valores Ingresados (Cadetes)', closing.valores_ingresados?.cadetes)}
                            {renderChannelValues('Valores Ingresados (Salón)', closing.valores_ingresados?.salon)}

                            <div className="mt-6 pt-4 border-t bg-muted/30 p-4 rounded-lg">
                                <h4 className="font-bold mb-3">Totales Calculados</h4>
                                <div className="space-y-2 text-sm">
                                    <div className="flex justify-between">
                                        <span>Total Efectivo:</span>
                                        <span className="font-bold">{formatCurrency(closing.total_efectivo)}</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span>MP Cadetes:</span>
                                        <span className="font-bold">{formatCurrency(closing.total_mp_cadetes)}</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span>MP Mostrador:</span>
                                        <span className="font-bold">{formatCurrency(closing.total_mp_mostrador)}</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span>Total Electrónico:</span>
                                        <span className="font-bold">{formatCurrency(closing.total_electronico)}</span>
                                    </div>
                                    <div className="flex justify-between text-lg text-primary mt-2 pt-2 border-t border-dashed">
                                        <span className="font-bold">Total General:</span>
                                        <span className="font-bold">{formatCurrency(closing.total_general)}</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Right Column: Images */}
                        <div className="space-y-4">
                            <h4 className="font-semibold text-sm text-muted-foreground uppercase">Comprobantes</h4>
                            
                            <div className="border rounded-lg p-2 bg-muted/10">
                                <div className="flex justify-between items-center mb-2">
                                    <span className="text-sm font-medium">Foto Posnet</span>
                                    <a 
                                        href={closing.url_foto_posnet} 
                                        target="_blank" 
                                        rel="noopener noreferrer"
                                        className="text-xs flex items-center text-blue-500 hover:underline"
                                    >
                                        Abrir original <ExternalLink className="h-3 w-3 ml-1" />
                                    </a>
                                </div>
                                <div className="aspect-video bg-black/5 rounded overflow-hidden flex items-center justify-center">
                                    {closing.url_foto_posnet ? (
                                        <img 
                                            src={closing.url_foto_posnet} 
                                            alt="Foto Posnet" 
                                            className="w-full h-full object-contain"
                                        />
                                    ) : (
                                        <span className="text-xs text-muted-foreground">No disponible</span>
                                    )}
                                </div>
                            </div>

                            <div className="border rounded-lg p-2 bg-muted/10">
                                <div className="flex justify-between items-center mb-2">
                                    <span className="text-sm font-medium">Captura Jarvis</span>
                                    <a 
                                        href={closing.url_foto_jarvis} 
                                        target="_blank" 
                                        rel="noopener noreferrer"
                                        className="text-xs flex items-center text-blue-500 hover:underline"
                                    >
                                        Abrir original <ExternalLink className="h-3 w-3 ml-1" />
                                    </a>
                                </div>
                                <div className="aspect-video bg-black/5 rounded overflow-hidden flex items-center justify-center">
                                    {closing.url_foto_jarvis ? (
                                        <img 
                                            src={closing.url_foto_jarvis} 
                                            alt="Captura Jarvis" 
                                            className="w-full h-full object-contain"
                                        />
                                    ) : (
                                        <span className="text-xs text-muted-foreground">No disponible</span>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default ClosingDetailDialog;