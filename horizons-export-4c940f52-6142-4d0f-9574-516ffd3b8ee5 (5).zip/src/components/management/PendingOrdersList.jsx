import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const PendingOrdersList = ({ sucursalId }) => {
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const { toast } = useToast();

    const fetchPendingOrders = useCallback(async () => {
        if (!sucursalId) return;
        setLoading(true);
        try {
            const { data, error } = await supabase
                .from('pedidos_centralizada')
                .select('id, fecha_pedido, estado, usuario_id, user_profiles(full_name)')
                .eq('sucursal_id', sucursalId)
                .not('estado', 'in', '(cerrado,cerrado_proveedor)') // Fixed syntax: added parentheses around the list
                .order('fecha_pedido', { ascending: false });

            if (error) throw error;
            setOrders(data);
        } catch (err) {
            console.error("Error fetching pending orders:", err);
            toast({ variant: 'destructive', title: 'Error', description: 'No se pudieron cargar los pedidos pendientes.' });
        } finally {
            setLoading(false);
        }
    }, [sucursalId, toast]);

    useEffect(() => {
        fetchPendingOrders();
    }, [fetchPendingOrders]);

    const getStatusInfo = (status) => {
        const baseClasses = 'px-2 py-1 text-xs font-medium rounded-full inline-flex items-center gap-1.5';
        switch (status) {
            case 'pendiente':
                return { text: 'Pendiente', className: `${baseClasses} bg-yellow-500/20 text-yellow-400` };
            case 'gestionado':
                return { text: 'Gestionado', className: `${baseClasses} bg-blue-500/20 text-blue-400` };
            case 'confirmado':
                return { text: 'Confirmado a Sucursal', className: `${baseClasses} bg-teal-500/20 text-teal-400` };
            case 'firma_pendiente':
                return { text: 'Firma Pendiente', className: `${baseClasses} bg-purple-500/20 text-purple-400` };
            default:
                return { text: status, className: `${baseClasses} bg-gray-500/20 text-gray-400` };
        }
    };

    if (loading) {
        return <div className="flex justify-center items-center h-24"><Loader2 className="animate-spin" /></div>;
    }

    if (orders.length === 0) {
        return <p className="text-muted-foreground text-center py-4">No hay pedidos activos para esta sucursal.</p>;
    }

    return (
        <div className="space-y-3">
            {orders.map(order => {
                const statusInfo = getStatusInfo(order.estado);
                return (
                    <div key={order.id} className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-3 border rounded-lg bg-background">
                        <div className="mb-2 sm:mb-0">
                            <p className="font-semibold">
                                Pedido del {new Date(order.fecha_pedido).toLocaleDateString('es-AR', { timeZone: 'UTC' })}
                            </p>
                            <p className="text-sm text-muted-foreground">
                                Realizado por: {order.user_profiles?.full_name || 'Sistema'}
                            </p>
                        </div>
                         <Badge variant="outline" className={statusInfo.className}>{statusInfo.text}</Badge>
                    </div>
                );
            })}
        </div>
    );
};

export default PendingOrdersList;