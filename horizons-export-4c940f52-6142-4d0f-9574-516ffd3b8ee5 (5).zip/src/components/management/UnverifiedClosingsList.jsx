import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Loader2, CheckCircle2, Eye } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useBranch } from '@/contexts/BranchContext';
import { calculateAndSaveCurrentMonthBalance } from '@/services/balanceService';
import { logModificationAndNotify } from '@/lib/modificationLogger';
import ClosingDetailDialog from '@/components/management/ClosingDetailDialog';
import { formatShortDate } from '@/lib/sheetUtils';

const UnverifiedClosingsList = ({ sucursalId, onActionComplete }) => {
    const [closings, setClosings] = useState([]);
    const [loading, setLoading] = useState(true);
    const [verifyingId, setVerifyingId] = useState(null);
    const [selectedClosing, setSelectedClosing] = useState(null);
    const { toast } = useToast();
    const { user } = useAuth();
    const { getBranchNameById } = useBranch();

    // Filtro: Cierres pendientes de la PRIMERA instancia (Gerencia)
    const fetchUnverifiedClosings = useCallback(async () => {
        if (!sucursalId) return;
        setLoading(true);
        try {
            const { data, error } = await supabase
                .from('cierres_caja')
                .select(`*, user_profiles ( full_name )`)
                .eq('sucursal_id', sucursalId)
                .eq('verificado_por_gerencia', false) // NO verificado por gerencia
                .order('fecha', { ascending: true });

            if (error) throw error;

            setClosings(data ?? []);
        } catch (err) {
            console.error('Error fetching unverified closings:', err);
            toast({ variant: 'destructive', title: 'Error', description: 'No se pudieron cargar los cierres pendientes.' });
        } finally {
            setLoading(false);
        }
    }, [sucursalId, toast]);

    useEffect(() => {
        fetchUnverifiedClosings();
    }, [fetchUnverifiedClosings]);

    const handleVerify = async (closing) => {
        // Seguridad: Si ya impactó en planilla, no permitir verificar de nuevo desde esta lista
        if (closing.impactado_en_planilla) {
            toast({ variant: 'destructive', title: 'Error', description: 'Este cierre ya ha impactado en la planilla.' });
            return;
        }

        setVerifyingId(closing.id);
        try {
            const verifierEmail = user?.email ?? 'sin-email@local';

            // Ensure we use the date string exactly as provided (YYYY-MM-DD)
            // If Supabase returns ISO timestamp for some reason, slice it.
            // Normally for date columns it returns "YYYY-MM-DD".
            const dateStr = typeof closing.fecha === 'string' 
                ? closing.fecha.split('T')[0] 
                : new Date().toISOString().split('T')[0];

            // 1. Crear entrada diaria (IMPACTO FINANCIERO)
            const entradaDiariaData = {
                fecha: dateStr, 
                monto: closing.total_general,
                ioe: 'I',
                tipo_ioe: `Cierre de Caja ${closing.turno}`,
                razon_social: `Cierre de Caja ${closing.turno}`,
                observaciones: `Cierre de caja verificado por Gerencia. Efectivo: ${closing.total_efectivo.toFixed(2)}`,
                debe: closing.total_efectivo,
                haber: 0,
                sucursal_id: closing.sucursal_id,
                usuario_email: verifierEmail,
                verificado: true,
            };

            const { error: insertError } = await supabase.from('entradas_diarias').insert(entradaDiariaData);
            if (insertError) throw new Error(`Error registrando en planilla: ${insertError.message}`);

            // 2. Actualizar cierre: Marcar como verificado por gerencia E impactado
            const { error: updateError } = await supabase
                .from('cierres_caja')
                .update({ 
                    verificado: true, 
                    verificado_por_gerencia: true,
                    impactado_en_planilla: true // FLAG CRÍTICO
                })
                .eq('id', closing.id);
                
            if (updateError) throw new Error(`Error actualizando el cierre: ${updateError.message}`);

            // 3. Recálculos y logs
            const monthYear = dateStr.slice(0, 7);
            await calculateAndSaveCurrentMonthBalance(closing.sucursal_id, monthYear, verifierEmail);
            await logModificationAndNotify(supabase, toast, getBranchNameById, closing.sucursal_id, monthYear, verifierEmail, 'verificacion_cierre_gerencia');

            toast({ title: 'Verificado', description: `Cierre impactado en planilla. Pasa a supervisión.` });
            fetchUnverifiedClosings();
            if (onActionComplete) onActionComplete();
        } catch (error) {
            console.error(error);
            toast({ variant: 'destructive', title: 'Error de Verificación', description: error.message });
        } finally {
            setVerifyingId(null);
        }
    };

    if (loading) return <div className="flex justify-center p-4"><Loader2 className="animate-spin" /></div>;
    if (closings.length === 0) return <p className="text-muted-foreground text-center py-4">Todo al día en Gerencia.</p>;

    return (
        <div className="space-y-3">
            {closings.map((closing) => (
                <div key={closing.id} className="flex flex-col sm:flex-row justify-between items-center p-4 border rounded-lg bg-background gap-4 border-l-4 border-l-yellow-500">
                    <div className="flex-1">
                        <div className="flex items-baseline gap-2">
                            {/* We use our robust formatter here to ensure consistent display */}
                            <p className="font-semibold">{formatShortDate(closing.fecha)} - {closing.turno}</p>
                            <span className="text-xs text-muted-foreground">por {closing.user_profiles?.full_name}</span>
                        </div>
                        <p className="text-sm">Total: <strong>${closing.total_general?.toLocaleString('es-AR')}</strong> (Efec: ${closing.total_efectivo?.toLocaleString('es-AR')})</p>
                    </div>
                    <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => setSelectedClosing(closing)}><Eye className="mr-2 h-4 w-4" /> Ver</Button>
                        <Button size="sm" onClick={() => handleVerify(closing)} disabled={verifyingId === closing.id}>
                            {verifyingId === closing.id ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CheckCircle2 className="mr-2 h-4 w-4" />}
                            Verificar (Impactar)
                        </Button>
                    </div>
                </div>
            ))}
            <ClosingDetailDialog isOpen={!!selectedClosing} onClose={() => setSelectedClosing(null)} closing={selectedClosing} />
        </div>
    );
};

export default UnverifiedClosingsList;