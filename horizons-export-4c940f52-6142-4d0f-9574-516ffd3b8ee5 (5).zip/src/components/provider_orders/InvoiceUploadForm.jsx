import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, UploadCloud } from 'lucide-react';

const InvoiceUploadForm = ({ onUploadSuccess }) => {
    const { userProfile } = useAuth();
    const { toast } = useToast();
    const [loading, setLoading] = useState(false);
    const [suppliers, setSuppliers] = useState([]);
    
    const [fecha, setFecha] = useState(new Date().toISOString().split('T')[0]);
    const [proveedorId, setProveedorId] = useState('');
    const [monto, setMonto] = useState('');
    const [file, setFile] = useState(null);

    useEffect(() => {
        const fetchSuppliers = async () => {
            const { data, error } = await supabase.from('suppliers').select('id, name').order('name');
            if (!error && data) {
                setSuppliers(data);
            }
        };
        fetchSuppliers();
    }, []);

    const handleFileChange = (e) => {
        if (e.target.files && e.target.files.length > 0) {
            setFile(e.target.files[0]);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (!fecha || !proveedorId || !monto || !file) {
            toast({ variant: 'destructive', title: 'Error', description: 'Por favor completa todos los campos y adjunta un archivo.' });
            return;
        }

        setLoading(true);
        try {
            // Upload file
            const fileExt = file.name.split('.').pop();
            const fileName = `factura_${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;
            const filePath = `facturas/${fileName}`;

            const { error: uploadError } = await supabase.storage
                .from('pagos-proveedores')
                .upload(filePath, file);

            if (uploadError) throw uploadError;

            const { data: publicUrlData } = supabase.storage
                .from('pagos-proveedores')
                .getPublicUrl(filePath);

            const fileUrl = publicUrlData.publicUrl;

            // Insert into facturas table
            const { error: insertError } = await supabase.from('facturas').insert([{
                fecha: fecha,
                sucursal_id: userProfile?.sucursal_id || 1, // Fallback if admin has no branch
                proveedor_id: parseInt(proveedorId),
                numero_pedido: `FACT-${Date.now()}`, // Temporary pseudo-id
                monto: parseFloat(monto),
                archivo_url: fileUrl,
                verificado: false,
                cargado_en_sistema: false,
                creado_por: userProfile?.id
            }]);

            if (insertError) throw insertError;

            toast({ title: 'Éxito', description: 'Factura cargada correctamente.' });
            
            // Reset form
            setFecha(new Date().toISOString().split('T')[0]);
            setProveedorId('');
            setMonto('');
            setFile(null);
            
            if (onUploadSuccess) onUploadSuccess();

        } catch (error) {
            console.error('Error uploading invoice:', error);
            toast({ variant: 'destructive', title: 'Error', description: 'No se pudo cargar la factura.' });
        } finally {
            setLoading(false);
        }
    };

    return (
        <Card className="w-full">
            <form onSubmit={handleSubmit} className="flex flex-col h-full">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                        <UploadCloud className="h-5 w-5 text-primary" />
                        Cargar Nueva Factura
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-5 flex-1">
                    <div className="space-y-2">
                        <Label htmlFor="fecha" className="text-sm font-medium">Fecha</Label>
                        <Input id="fecha" type="date" value={fecha} onChange={(e) => setFecha(e.target.value)} required className="w-full" />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="proveedor" className="text-sm font-medium">Proveedor</Label>
                        <Select value={proveedorId} onValueChange={setProveedorId} required>
                            <SelectTrigger id="proveedor" className="w-full">
                                <SelectValue placeholder="Selecciona proveedor" />
                            </SelectTrigger>
                            <SelectContent>
                                {suppliers.map(s => (
                                    <SelectItem key={s.id} value={s.id.toString()}>{s.name}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="monto" className="text-sm font-medium">Monto ($)</Label>
                        <Input id="monto" type="number" step="0.01" min="0" placeholder="0.00" value={monto} onChange={(e) => setMonto(e.target.value)} required className="w-full" />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="archivo" className="text-sm font-medium">Archivo (PDF/Imagen)</Label>
                        <Input id="archivo" type="file" accept=".pdf,image/*" onChange={handleFileChange} required className="w-full cursor-pointer" />
                    </div>
                </CardContent>
                <CardFooter className="pt-4 border-t">
                    <Button type="submit" disabled={loading} className="w-full text-white bg-blue-600 hover:bg-blue-700">
                        {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UploadCloud className="mr-2 h-4 w-4" />}
                        {loading ? 'Subiendo...' : 'Subir Factura'}
                    </Button>
                </CardFooter>
            </form>
        </Card>
    );
};

export default InvoiceUploadForm;