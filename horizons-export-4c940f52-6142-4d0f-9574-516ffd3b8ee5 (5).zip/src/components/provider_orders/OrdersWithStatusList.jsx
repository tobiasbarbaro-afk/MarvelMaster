import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Package, Eye } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';

const OrdersWithStatusList = ({ orders, selectedOrderId, onSelectOrder }) => {
    const { userRole } = useAuth();
    // Checkboxes hidden for gerente and cocina (read-only view)
    const hideCheckboxes = ['gerente', 'cocina'].includes(userRole);

    return (
        <Card className="h-full flex flex-col overflow-hidden">
            <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                    <Package className="h-5 w-5" />
                    Órdenes Generadas
                </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 overflow-auto">
                {orders.length === 0 ? (
                    <div className="text-center text-muted-foreground py-8">
                        No hay órdenes con estado "OC Generada".
                    </div>
                ) : (
                    <div className="space-y-3">
                        {orders.map((order) => (
                            <div 
                                key={order.id} 
                                className={`p-3 border rounded-md flex flex-col gap-3 transition-colors ${selectedOrderId === order.id ? 'border-primary bg-primary/5' : 'hover:bg-muted/50'}`}
                            >
                                <div className="flex flex-col">
                                    <div className="font-medium text-sm text-primary mb-1">
                                        {order.suppliers?.name || 'Proveedor Desconocido'}
                                    </div>
                                    <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-muted-foreground">
                                        <div><span className="font-medium">Pedido:</span> {new Date(order.fecha_pedido).toLocaleDateString()}</div>
                                        <div><span className="font-medium">Sucursal:</span> {order.sucursales?.nombre || 'Central'}</div>
                                        <div><span className="font-medium">Items:</span> {order.productos?.length || 0} prod(s)</div>
                                    </div>
                                </div>
                                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pt-2 border-t mt-1 gap-2">
                                    <div className="flex items-center gap-2">
                                        {!hideCheckboxes && (
                                            <div className="flex items-center gap-2">
                                                <Checkbox 
                                                    id={`checkbox-order-${order.id}`}
                                                    checked={selectedOrderId === order.id}
                                                    onCheckedChange={() => onSelectOrder(order.id)}
                                                />
                                                <label htmlFor={`checkbox-order-${order.id}`} className="text-sm font-medium leading-none cursor-pointer">
                                                    Seleccionar
                                                </label>
                                            </div>
                                        )}
                                    </div>
                                    <div className="flex flex-wrap items-center justify-end gap-2 w-full sm:w-auto">
                                        <Badge variant="outline" className="bg-blue-500/10 text-blue-500 border-blue-500/20 whitespace-nowrap">OC Generada</Badge>
                                        {order.orden_compra_url && (
                                            <Button asChild size="sm" variant="secondary" className="whitespace-nowrap">
                                                <a href={order.orden_compra_url} target="_blank" rel="noopener noreferrer">
                                                    <Eye className="h-4 w-4 sm:mr-1" /> <span className="hidden sm:inline">Ver OC</span>
                                                </a>
                                            </Button>
                                        )}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </CardContent>
        </Card>
    );
};

export default OrdersWithStatusList;