import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FileText, Eye } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';

const InvoiceListDisplay = ({ invoices, selectedInvoiceId, onSelectInvoice, isReadOnly }) => {
    // Filter out invoices that are already associated with an order
    const pendingInvoices = invoices.filter(inv => !inv.orden_compra_asociada_id);

    return (
        <Card className="h-full flex flex-col overflow-hidden">
            <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Facturas Cargadas
                </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 overflow-auto">
                {pendingInvoices.length === 0 ? (
                    <div className="text-center text-muted-foreground py-8">
                        No hay facturas pendientes disponibles.
                    </div>
                ) : (
                    <div className="space-y-3">
                        {pendingInvoices.map((inv) => (
                            <div 
                                key={inv.id} 
                                className={`p-3 border rounded-md flex flex-col gap-3 transition-colors ${selectedInvoiceId === inv.id ? 'border-primary bg-primary/5' : 'hover:bg-muted/50'}`}
                            >
                                <div className="flex items-start justify-between gap-3">
                                    <div className="w-full">
                                        <div className="font-medium text-sm">{inv.suppliers?.name || 'Proveedor Desconocido'}</div>
                                        <div className="text-xs text-muted-foreground flex gap-2 flex-wrap mt-1">
                                            <span>Fecha: {new Date(inv.fecha).toLocaleDateString()}</span>
                                            <span>| Sucursal: {inv.sucursales?.nombre || 'Central'}</span>
                                            <span className="font-semibold text-foreground">| ${inv.monto || '0.00'}</span>
                                        </div>
                                    </div>
                                </div>
                                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pt-2 border-t mt-1 gap-2">
                                    <div className="flex items-center gap-2">
                                        {!isReadOnly && (
                                            <div className="flex items-center gap-2">
                                                <Checkbox 
                                                    id={`checkbox-invoice-${inv.id}`}
                                                    checked={selectedInvoiceId === inv.id}
                                                    onCheckedChange={() => onSelectInvoice(inv.id)}
                                                />
                                                <label htmlFor={`checkbox-invoice-${inv.id}`} className="text-sm font-medium leading-none cursor-pointer">
                                                    Seleccionar
                                                </label>
                                            </div>
                                        )}
                                    </div>
                                    <div className="flex flex-wrap items-center justify-end gap-2 w-full sm:w-auto">
                                        <Badge variant="outline" className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20 whitespace-nowrap">Pendiente</Badge>
                                        <Button asChild size="sm" variant="secondary" className="whitespace-nowrap">
                                            <a href={inv.archivo_url} target="_blank" rel="noopener noreferrer">
                                                <Eye className="h-4 w-4 sm:mr-1" /> <span className="hidden sm:inline">Ver</span>
                                            </a>
                                        </Button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </CardContent>
        </Card>
    );
};

export default InvoiceListDisplay;