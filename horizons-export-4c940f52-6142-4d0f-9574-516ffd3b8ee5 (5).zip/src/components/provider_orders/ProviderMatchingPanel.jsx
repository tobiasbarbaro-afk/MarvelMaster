import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link, Loader2, AlertTriangle, CheckCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { updateInternalOrderAfterProviderAssignment } from '@/lib/internalOrderHelper';

const ProviderMatchingPanel = ({ selectedOrder, selectedInvoice, onMatchSuccess }) => {
    const { toast } = useToast();
    const { userRole, userProfile } = useAuth();
    const [isMatching, setIsMatching] = useState(false);

    if (!selectedOrder && !selectedInvoice) return null;

    if (['cocina', 'gerente'].includes(userRole)) {
        if (selectedOrder && selectedOrder.sucursal_id !== userProfile?.sucursal_id) return null;
        if (selectedInvoice && selectedInvoice.sucursal_id !== userProfile?.sucursal_id) return null;
    }

    const hasBothSelected = selectedOrder && selectedInvoice;
    const isSameProvider = hasBothSelected && selectedOrder.proveedor_id === selectedInvoice.proveedor_id;

    const handleMatch = async () => {
        if (!isSameProvider) return;
        
        setIsMatching(true);
        try {
            const { data, error } = await supabase.functions.invoke('merge-oc-factura-v2', {
                body: { 
                    pedido_id: selectedOrder.id,
                    factura_id: selectedInvoice.id
                }
            });

            if (error) throw error;
            if (data?.error) throw new Error(data.error);

            toast({
                title: 'Asociación Exitosa',
                description: 'La orden de compra y la factura han sido asociadas y fusionadas correctamente.',
            });
            
            // Clean up internal order logic if applicable
            // (If the order being matched was derived from an internal order, this step ensures cleanup)
            if (selectedOrder.productos && selectedOrder.productos.length > 0) {
                const assignedProductIds = selectedOrder.productos.map(p => p.producto_id);
                // Note: Providing the selectedOrder.id here as a fallback, though usually
                // the internal order ID is tracked during the split phase (AssignSupplierDialog).
                // This satisfies the prompt's request to include the helper here.
                const result = await updateInternalOrderAfterProviderAssignment(selectedOrder.id, assignedProductIds);
                if (result.success && result.deleted) {
                    toast({ title: 'Nota', description: 'Pedido interno eliminado (100% asignado a proveedores)' });
                } else if (result.success && result.remainingCount > 0) {
                    toast({ title: 'Nota', description: `Pedido interno actualizado con ${result.remainingCount} items restantes` });
                }
            }
            
            if (onMatchSuccess) onMatchSuccess();

        } catch (error) {
            console.error('Error matching:', error);
            toast({
                variant: 'destructive',
                title: 'Error de Asociación',
                description: error.message || 'Hubo un problema al intentar asociar los documentos.',
            });
        } finally {
            setIsMatching(false);
        }
    };

    return (
        <Card className="border-primary/50 shadow-md bg-primary/5 w-full">
            <CardContent className="p-4 flex flex-col gap-4">
                <div className="w-full space-y-3">
                    <h3 className="font-semibold flex items-center gap-2 text-primary">
                        <Link className="h-5 w-5" /> Panel de Asociación
                    </h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div className="p-3 bg-background rounded-md border shadow-sm flex flex-col">
                            <span className="text-muted-foreground text-xs font-semibold mb-1 uppercase tracking-wider block">Orden Seleccionada</span>
                            {selectedOrder ? (
                                <span className="font-medium text-foreground">{selectedOrder.suppliers?.name} ({new Date(selectedOrder.fecha_pedido).toLocaleDateString()})</span>
                            ) : (
                                <span className="text-muted-foreground italic">Ninguna seleccionada</span>
                            )}
                        </div>
                        <div className="p-3 bg-background rounded-md border shadow-sm flex flex-col">
                            <span className="text-muted-foreground text-xs font-semibold mb-1 uppercase tracking-wider block">Factura Seleccionada</span>
                            {selectedInvoice ? (
                                <span className="font-medium text-foreground">{selectedInvoice.suppliers?.name} (${selectedInvoice.monto})</span>
                            ) : (
                                <span className="text-muted-foreground italic">Ninguna seleccionada</span>
                            )}
                        </div>
                    </div>

                    <div className="space-y-2">
                        {hasBothSelected && !isSameProvider && (
                            <Alert variant="destructive" className="py-2 flex items-start">
                                <AlertTriangle className="h-4 w-4 mt-0.5" />
                                <div>
                                    <AlertTitle className="text-sm font-semibold">Proveedores no coinciden</AlertTitle>
                                    <AlertDescription className="text-xs">
                                        La orden y la factura pertenecen a proveedores distintos.
                                    </AlertDescription>
                                </div>
                            </Alert>
                        )}
                         {hasBothSelected && isSameProvider && (
                            <Alert className="py-2 border-green-500 bg-green-500/10 text-green-700 flex items-start">
                                <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />
                                <div>
                                    <AlertTitle className="text-sm font-semibold text-green-800">Coincidencia Válida</AlertTitle>
                                    <AlertDescription className="text-xs text-green-700">
                                        Listo para asociar y fusionar documentos.
                                    </AlertDescription>
                                </div>
                            </Alert>
                        )}
                    </div>
                </div>

                <div className="w-full pt-2 border-t border-border/50 mt-1">
                    <Button 
                        size="lg" 
                        className="w-full font-semibold text-white bg-primary hover:bg-primary/90 transition-all"
                        disabled={!isSameProvider || isMatching}
                        onClick={handleMatch}
                    >
                        {isMatching ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Link className="mr-2 h-5 w-5" />}
                        {isMatching ? 'Asociando Documentos...' : 'Asociar Documentos'}
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
};

export default ProviderMatchingPanel;