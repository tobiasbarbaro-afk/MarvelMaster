import React, { useState, useEffect, useCallback, useContext } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Info, Loader2, Paperclip, CheckCircle } from 'lucide-react';
import { mergePDFs, uploadMergedPDF } from '@/lib/pdfUtils';
import { AuthContext } from '@/contexts/AuthContext';

const AssociateDocumentsDialog = ({ isOpen, onClose, onAssociationSuccess, branchId, supplierId }) => {
  const { user } = useContext(AuthContext);
  const [ordenesCompra, setOrdenesCompra] = useState([]);
  const [facturas, setFacturas] = useState([]);
  const [selectedOC, setSelectedOC] = useState(null);
  const [selectedFactura, setSelectedFactura] = useState(null);
  const [loadingOC, setLoadingOC] = useState(false);
  const [loadingFacturas, setLoadingFacturas] = useState(false);
  const [isAssociating, setIsAssociating] = useState(false);
  const { toast } = useToast();

  const formatDateForDisplay = (dateString) => {
    if (!dateString) return 'Fecha no disponible';
    // Asegurarse que la fecha se interpreta correctamente como UTC para evitar problemas de zona horaria
    const date = new Date(dateString + 'T00:00:00Z');
    return date.toLocaleDateString('es-AR', { year: 'numeric', month: '2-digit', day: '2-digit', timeZone: 'UTC' });
  };

  const fetchUnassociatedDocuments = useCallback(async () => {
    if (!branchId || !supplierId) return;

    setLoadingOC(true);
    const { data: ocData, error: ocError } = await supabase
      .from('ordenes_compra')
      .select('id, numero_pedido, archivo_url, fecha')
      .eq('sucursal_id', branchId)
      .eq('proveedor_id', supplierId)
      .is('factura_id', null) 
      .order('fecha', { ascending: false });

    if (ocError) {
      toast({ variant: 'destructive', title: 'Error', description: 'No se pudieron cargar las órdenes de compra.' });
    } else {
      setOrdenesCompra(ocData || []);
    }
    setLoadingOC(false);

    setLoadingFacturas(true);
    const { data: facturaData, error: facturaError } = await supabase
      .from('facturas')
      .select('id, numero_pedido, archivo_url, fecha')
      .eq('sucursal_id', branchId)
      .eq('proveedor_id', supplierId)
      .is('orden_compra_id', null)
      .order('fecha', { ascending: false });

    if (facturaError) {
      toast({ variant: 'destructive', title: 'Error', description: 'No se pudieron cargar las facturas.' });
    } else {
      setFacturas(facturaData || []);
    }
    setLoadingFacturas(false);
  }, [branchId, supplierId, toast]);

  useEffect(() => {
    if (isOpen) {
      fetchUnassociatedDocuments();
      setSelectedOC(null);
      setSelectedFactura(null);
    }
  }, [isOpen, fetchUnassociatedDocuments]);

  const handleAssociate = async () => {
    if (!selectedOC || !selectedFactura) {
      toast({ variant: 'destructive', title: 'Selección requerida', description: 'Debe seleccionar una OC y una Factura.' });
      return;
    }
    if (!user || !user.id) {
        toast({ variant: 'destructive', title: 'Error de autenticación', description: 'No se pudo identificar al usuario.' });
        return;
    }
    setIsAssociating(true);

    try {
      const ocRecord = ordenesCompra.find(oc => oc.id === selectedOC);
      const facturaRecord = facturas.find(f => f.id === selectedFactura);

      if (!ocRecord || !ocRecord.archivo_url || !facturaRecord || !facturaRecord.archivo_url) {
        throw new Error("No se encontraron los URLs de los archivos originales para fusionar.");
      }
      
      toast({ title: 'Procesando...', description: 'Fusionando PDFs, por favor espere.' });
      const mergedPdfBlob = await mergePDFs(ocRecord.archivo_url, facturaRecord.archivo_url);
      
      const mergedFileName = `OC${ocRecord.numero_pedido}-FAC${facturaRecord.numero_pedido}_fusionado.pdf`;
      
      toast({ title: 'Subiendo...', description: 'Subiendo PDF fusionado.' });
      const uploadResult = await uploadMergedPDF(mergedPdfBlob, mergedFileName, user.id, branchId, supplierId);
      const mergedPdfUrl = uploadResult.publicUrl;

      const fechaFusionado = new Date().toISOString();
      const eliminarOriginalEn = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();

      const { error: updateOcError } = await supabase
        .from('ordenes_compra')
        .update({ 
          factura_id: selectedFactura,
          pdf_fusionado_url: mergedPdfUrl,
          fecha_fusionado: fechaFusionado,
          eliminar_original_en: eliminarOriginalEn
        })
        .eq('id', selectedOC);

      if (updateOcError) throw updateOcError;

      const { error: updateFacturaError } = await supabase
        .from('facturas')
        .update({ 
          orden_compra_id: selectedOC,
          pdf_fusionado_url: mergedPdfUrl,
          fecha_fusionado: fechaFusionado,
          eliminar_original_en: eliminarOriginalEn
        })
        .eq('id', selectedFactura);

      if (updateFacturaError) throw updateFacturaError;

      toast({ title: 'Éxito', description: 'Documentos asociados y PDF fusionado y subido correctamente.' });
      onAssociationSuccess();
      onClose();
    } catch (error) {
      console.error("Error associating documents:", error);
      toast({ variant: 'destructive', title: 'Error en Asociación', description: `Detalle: ${error.message}` });
    } finally {
      setIsAssociating(false);
    }
  };
  
  const renderPreview = (doc) => {
    if (!doc) return <p className="text-sm text-muted-foreground">No seleccionado</p>;
    return (
      <div className="mt-1 p-2 border rounded-md bg-muted/50">
        <p className="text-sm font-medium">Nº: {doc.numero_pedido}</p>
        <p className="text-xs text-muted-foreground">Fecha: {formatDateForDisplay(doc.fecha)}</p>
        {doc.archivo_url && (
          <a href={doc.archivo_url} target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline flex items-center">
            <Paperclip size={12} className="mr-1"/> Ver PDF Original
          </a>
        )}
      </div>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-2xl bg-card border-border text-card-foreground">
        <DialogHeader>
          <DialogTitle className="text-2xl text-primary">Asociar y Fusionar Documentos</DialogTitle>
          <DialogDescription>
            Seleccione una Orden de Compra y una Factura por su fecha de emisión. Se generará un PDF combinado.
          </DialogDescription>
        </DialogHeader>
        
        {!branchId || !supplierId ? (
            <div className="p-4 my-4 text-center bg-yellow-900/20 border border-yellow-700 rounded-md">
                <Info className="inline-block w-5 h-5 mr-2 text-yellow-400" />
                <span className="text-yellow-300">Por favor, seleccione una sucursal y un proveedor en la página principal para habilitar la asociación.</span>
            </div>
        ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4">
            <div>
                <Label htmlFor="select-oc" className="text-foreground">Orden de Compra (por fecha de emisión)</Label>
                <Select
                value={selectedOC || ''}
                onValueChange={(value) => setSelectedOC(value ? parseInt(value) : null)}
                disabled={loadingOC || isAssociating}
                >
                <SelectTrigger id="select-oc" className="mt-1">
                    <SelectValue placeholder={loadingOC ? "Cargando OCs..." : "Seleccione OC"} />
                </SelectTrigger>
                <SelectContent>
                    {ordenesCompra.length === 0 && !loadingOC && <SelectItem value="no-oc" disabled>No hay OCs disponibles</SelectItem>}
                    {ordenesCompra.map(oc => (
                    <SelectItem key={oc.id} value={oc.id.toString()}>
                        {formatDateForDisplay(oc.fecha)} (Nº: {oc.numero_pedido})
                    </SelectItem>
                    ))}
                </SelectContent>
                </Select>
                {renderPreview(ordenesCompra.find(oc => oc.id === selectedOC))}
            </div>

            <div>
                <Label htmlFor="select-factura" className="text-foreground">Factura (por fecha de emisión)</Label>
                <Select
                value={selectedFactura || ''}
                onValueChange={(value) => setSelectedFactura(value ? parseInt(value) : null)}
                disabled={loadingFacturas || isAssociating}
                >
                <SelectTrigger id="select-factura" className="mt-1">
                    <SelectValue placeholder={loadingFacturas ? "Cargando Facturas..." : "Seleccione Factura"} />
                </SelectTrigger>
                <SelectContent>
                    {facturas.length === 0 && !loadingFacturas && <SelectItem value="no-factura" disabled>No hay Facturas disponibles</SelectItem>}
                    {facturas.map(f => (
                    <SelectItem key={f.id} value={f.id.toString()}>
                        {formatDateForDisplay(f.fecha)} (Nº: {f.numero_pedido})
                    </SelectItem>
                    ))}
                </SelectContent>
                </Select>
                {renderPreview(facturas.find(f => f.id === selectedFactura))}
            </div>
            </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isAssociating}>Cancelar</Button>
          <Button 
            onClick={handleAssociate} 
            disabled={!selectedOC || !selectedFactura || isAssociating || !branchId || !supplierId}
            className="bg-gradient-to-r from-primary to-accent text-primary-foreground"
          >
            {isAssociating ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CheckCircle className="mr-2 h-4 w-4" />}
            {isAssociating ? 'Procesando...' : 'Asociar y Fusionar'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AssociateDocumentsDialog;