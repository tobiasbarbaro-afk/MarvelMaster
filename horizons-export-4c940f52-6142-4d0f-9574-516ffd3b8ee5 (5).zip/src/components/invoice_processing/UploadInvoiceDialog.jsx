import React, { useState, useContext } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { UploadCloud, Loader2, FilePlus2, CalendarDays, DollarSign, Info } from 'lucide-react';
import { mergePDFs, uploadMergedPDF } from '@/lib/pdfUtils';
import { AuthContext } from '@/contexts/AuthContext';
import { formatDateForDB, getTodayDateISO } from '@/lib/sheetUtils';
import { cn } from '@/lib/utils';

const BUCKET_NAME = 'documentos.facturacion';

const UploadInvoiceDialog = ({ isOpen, onClose, onUploadSuccess, ordenDeCompra }) => {
  const { user } = useContext(AuthContext);
  const { toast } = useToast();

  const [invoiceFile, setInvoiceFile] = useState(null);
  const [invoiceFileName, setInvoiceFileName] = useState('');
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [invoiceDate, setInvoiceDate] = useState(getTodayDateISO());
  const [invoiceAmount, setInvoiceAmount] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDraggingOver, setIsDraggingOver] = useState(false);

  const resetForm = () => {
    setInvoiceFile(null);
    setInvoiceFileName('');
    setInvoiceNumber('');
    setInvoiceDate(getTodayDateISO());
    setInvoiceAmount('');
    setIsSubmitting(false);
    const fileInput = document.getElementById('invoiceFile-input');
    if (fileInput) fileInput.value = null;
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  const processFile = (file) => {
    if (file) {
      if (file.type !== 'application/pdf') {
        toast({ variant: "destructive", title: "Archivo no válido", description: "Por favor, suba solo archivos PDF para la factura." });
        setInvoiceFile(null);
        setInvoiceFileName('');
        return false;
      }
      if (file.size > 10 * 1024 * 1024) { // 10MB
        toast({ variant: "destructive", title: "Archivo demasiado grande", description: "El PDF de la factura no debe exceder los 10MB." });
        setInvoiceFile(null);
        setInvoiceFileName('');
        return false;
      }
      setInvoiceFile(file);
      setInvoiceFileName(file.name);
      return true;
    }
    setInvoiceFile(null);
    setInvoiceFileName('');
    return false;
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    processFile(file);
     if (!file && e.target) { 
        e.target.value = null;
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      if(processFile(files[0])) {
        const fileInput = document.getElementById('invoiceFile-input');
        if (fileInput) fileInput.value = null;
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!invoiceFile || !invoiceNumber.trim() || !invoiceDate || !invoiceAmount.trim() || !ordenDeCompra) {
      toast({ variant: "destructive", title: "Campos requeridos", description: "Complete todos los campos y seleccione el archivo de factura." });
      return;
    }
    if (parseFloat(invoiceAmount) <= 0) {
        toast({ variant: "destructive", title: "Monto no válido", description: "El monto de la factura debe ser mayor a cero." });
        return;
    }

    if (invoiceDate > getTodayDateISO()) {
      toast({ variant: "destructive", title: "Fecha no válida", description: "La fecha de emisión de la factura no puede ser futura." });
      return;
    }

    const formattedInvoiceDate = formatDateForDB(invoiceDate);
    if (!formattedInvoiceDate) {
      toast({ variant: "destructive", title: "Fecha no válida", description: "Formato de fecha de factura incorrecto." });
      return;
    }

    setIsSubmitting(true);

    const timestamp = new Date().toISOString();
    const uniqueInvoiceFileName = `${timestamp}-FAC-${invoiceFile.name.replace(/\s+/g, '_')}`;
    const invoiceFilePath = `${user.id}/factura/${ordenDeCompra.sucursal_id}/${ordenDeCompra.proveedor_id}/${uniqueInvoiceFileName}`;

    try {
      toast({ title: 'Subiendo factura...', description: 'Por favor espere.'});
      const { error: uploadError } = await supabase.storage
        .from(BUCKET_NAME)
        .upload(invoiceFilePath, invoiceFile);

      if (uploadError) throw new Error(`Error al subir factura: ${uploadError.message}`);

      const { data: publicUrlData } = supabase.storage.from(BUCKET_NAME).getPublicUrl(invoiceFilePath);
      if (!publicUrlData || !publicUrlData.publicUrl) throw new Error("No se pudo obtener la URL pública de la factura.");
      const factura_archivo_url = publicUrlData.publicUrl;

      const { data: insertedFactura, error: insertFacturaError } = await supabase
        .from('facturas')
        .insert({
          fecha: formattedInvoiceDate,
          sucursal_id: ordenDeCompra.sucursal_id,
          proveedor_id: ordenDeCompra.proveedor_id,
          numero_pedido: invoiceNumber,
          archivo_url: factura_archivo_url,
          monto: parseFloat(invoiceAmount),
          verificado: false,
          cargado_en_sistema: false,
          creado_por: user.id,
          orden_compra_id: ordenDeCompra.id // Asociar con la OC
        })
        .select()
        .single();

      if (insertFacturaError) {
        await supabase.storage.from(BUCKET_NAME).remove([invoiceFilePath]);
        throw new Error(`Error al guardar factura: ${insertFacturaError.message}`);
      }
      
      if (!insertedFactura) {
          throw new Error("No se pudo obtener el ID de la factura insertada.");
      }

      toast({ title: 'Fusionando PDFs...', description: 'Combinando OC y factura.'});
      const mergedPdfBlob = await mergePDFs(ordenDeCompra.archivo_url, factura_archivo_url);
      const mergedFileName = `OC${ordenDeCompra.numero_pedido}-FAC${invoiceNumber}_fusionado.pdf`;
      
      toast({ title: 'Subiendo PDF fusionado...', description: 'Guardando el documento combinado.'});
      const mergedUploadResult = await uploadMergedPDF(mergedPdfBlob, mergedFileName, user.id, ordenDeCompra.sucursal_id, ordenDeCompra.proveedor_id);
      const mergedPdfUrl = mergedUploadResult.publicUrl;

      const fechaFusionado = new Date().toISOString();
      const eliminarOriginalEn = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();

      const { error: updateOcError } = await supabase
        .from('ordenes_compra')
        .update({ 
          factura_id: insertedFactura.id,
          pdf_fusionado_url: mergedPdfUrl,
          fecha_fusionado: fechaFusionado,
          eliminar_original_en: eliminarOriginalEn
        })
        .eq('id', ordenDeCompra.id);

      if (updateOcError) throw new Error(`Error al actualizar OC: ${updateOcError.message}`);
      
       const { error: updateFacturaError } = await supabase
        .from('facturas')
        .update({ 
          pdf_fusionado_url: mergedPdfUrl,
          fecha_fusionado: fechaFusionado,
          eliminar_original_en: eliminarOriginalEn
        })
        .eq('id', insertedFactura.id);

      if (updateFacturaError) throw new Error(`Error al actualizar Factura con PDF fusionado: ${updateFacturaError.message}`);


      toast({ title: "Éxito", description: `Factura "${invoiceNumber}" cargada y asociada a OC "${ordenDeCompra.numero_pedido}".` });
      onUploadSuccess();
      handleClose();

    } catch (error) {
      toast({ variant: "destructive", title: "Error en el proceso", description: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const isSubmitDisabled = !invoiceFile || !invoiceNumber.trim() || !invoiceDate || !invoiceAmount.trim() || isSubmitting || !ordenDeCompra;

  if (!ordenDeCompra) return null;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && handleClose()}>
      <DialogContent className="sm:max-w-lg bg-card border-border text-card-foreground">
        <DialogHeader>
          <DialogTitle className="text-2xl text-primary">Cargar Factura para OC: {ordenDeCompra.numero_pedido}</DialogTitle>
          <DialogDescription>
            Adjunte la factura correspondiente a la Orden de Compra <span className="font-semibold">{ordenDeCompra.numero_pedido}</span> (Fecha OC: {formatDateForDB(ordenDeCompra.fecha)}).
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
            <div>
                <Label htmlFor="invoiceFile-input" className="text-foreground">Archivo Factura (PDF) *</Label>
                <div 
                className={cn(
                    "mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-dashed rounded-md border-border hover:border-primary transition-all duration-300 ease-in-out",
                    isDraggingOver && "border-primary bg-primary/10 scale-105 shadow-lg",
                    isSubmitting && "bg-muted/50 cursor-not-allowed"
                )}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                >
                <div className="space-y-1 text-center">
                    <UploadCloud className={cn("mx-auto h-10 w-10 text-muted-foreground", isDraggingOver && "text-primary animate-bounce")} />
                    <div className="flex text-sm text-muted-foreground">
                    <Label
                        htmlFor="invoiceFile-input"
                        className={cn(
                            "relative cursor-pointer rounded-md font-medium text-primary hover:text-primary/80 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-ring",
                            isSubmitting && "cursor-not-allowed opacity-50"
                        )}
                    >
                        <span>{invoiceFileName || 'Subir archivo de Factura'}</span>
                        <Input id="invoiceFile-input" name="invoiceFile" type="file" accept=".pdf" className="sr-only" onChange={handleFileChange} disabled={isSubmitting} />
                    </Label>
                    {!invoiceFileName && <p className="pl-1">o arrastrar y soltar</p>}
                    </div>
                    <p className="text-xs text-muted-foreground">PDF hasta 10MB</p>
                </div>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <Label htmlFor="invoiceNumber" className="text-foreground">Número de Factura *</Label>
                    <Input id="invoiceNumber" value={invoiceNumber} onChange={(e) => setInvoiceNumber(e.target.value)} placeholder="Ej: 0001-00004321" required disabled={isSubmitting} />
                </div>
                <div>
                    <Label htmlFor="invoiceDate" className="text-foreground flex items-center">
                    <CalendarDays className="w-4 h-4 mr-1.5" />
                    Fecha Emisión Factura *
                    </Label>
                    <Input id="invoiceDate" type="date" value={invoiceDate} onChange={(e) => setInvoiceDate(e.target.value)} required disabled={isSubmitting} max={getTodayDateISO()} />
                </div>
            </div>

            <div>
                <Label htmlFor="invoiceAmount" className="text-foreground flex items-center">
                    <DollarSign className="w-4 h-4 mr-1.5" />
                    Monto Factura *
                </Label>
                <Input 
                    id="invoiceAmount" 
                    type="number" 
                    value={invoiceAmount} 
                    onChange={(e) => setInvoiceAmount(e.target.value)} 
                    placeholder="Ej: 12345.67" 
                    required 
                    disabled={isSubmitting}
                    step="0.01"
                    min="0.01"
                />
            </div>

            <div className="p-3 my-2 text-sm bg-blue-900/20 border border-blue-700 rounded-md">
                <Info className="inline-block w-4 h-4 mr-2 text-blue-400" />
                <span className="text-blue-300">Sucursal: {ordenDeCompra.sucursales?.nombre || 'N/A'}, Proveedor: {ordenDeCompra.suppliers?.name || 'N/A'}</span>
            </div>

            <DialogFooter className="pt-4">
            <Button variant="outline" onClick={handleClose} disabled={isSubmitting}>Cancelar</Button>
            <Button type="submit" className="bg-gradient-to-r from-primary to-accent text-primary-foreground" disabled={isSubmitDisabled}>
                {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FilePlus2 className="mr-2 h-4 w-4" />}
                {isSubmitting ? 'Procesando...' : 'Cargar y Asociar Factura'}
            </Button>
            </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default UploadInvoiceDialog;