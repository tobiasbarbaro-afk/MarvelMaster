import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from '@/components/ui/button';
import { FileText, AlertTriangle, CheckCircle2, Loader2, Link as LinkIcon, UploadCloud } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

const DocumentList = ({ 
  documents, 
  loading, 
  isSubmitting, 
  onFlagChange,
  onUploadInvoiceClick,
  hasSearched
}) => {
  const { userRole } = useAuth();
  const canVerify = ['admin', 'gerente', 'centralizada'].includes(userRole);

  if (loading) {
    return (
      <div className="flex justify-center items-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2 text-muted-foreground">Buscando documentos...</p>
      </div>
    );
  }

  if (!hasSearched) {
    return (
      <div className="text-center text-muted-foreground py-12 flex flex-col items-center">
        <FileText size={48} className="mb-4 text-gray-500" />
        <p className="font-semibold text-lg">Listo para buscar</p>
        <p className="text-sm">Seleccione los filtros y presione "Buscar" para ver los documentos.</p>
      </div>
    );
  }

  if (documents.length === 0) {
    return (
      <p className="text-center text-muted-foreground py-8">
        No hay documentos que coincidan con los filtros seleccionados.
      </p>
    );
  }
  
  const formatDateForDisplay = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString + 'T00:00:00Z');
    return date.toLocaleDateString('es-AR', { year: 'numeric', month: '2-digit', day: '2-digit', timeZone: 'UTC' });
  };

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Tipo</TableHead>
            <TableHead>Número(s)</TableHead>
            <TableHead>Fecha Emisión</TableHead>
            <TableHead>Archivo</TableHead>
            <TableHead className="text-center">Verificado</TableHead>
            <TableHead className="text-center">Carg. Sistema</TableHead>
            <TableHead className="text-center">Acciones</TableHead> 
          </TableRow>
        </TableHeader>
        <TableBody>
          {documents.map((doc) => (
            <TableRow key={doc.unique_id} className={doc.is_merged_document ? 'bg-green-900/40 hover:bg-green-900/50' : 'hover:bg-muted/50'}>
              <TableCell>
                {doc.is_merged_document ? (
                    <span className="flex items-center font-semibold text-green-400">
                        <LinkIcon size={16} className="mr-1.5" /> Documento Fusionado
                    </span>
                ) : doc.tipo_documento}
              </TableCell>
              <TableCell>{doc.numero_pedido_display}</TableCell>
              <TableCell>{formatDateForDisplay(doc.fecha_display)}</TableCell>
              <TableCell>
                <a href={doc.archivo_url_display} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline flex items-center">
                  <FileText size={18} className="mr-1" /> Ver PDF {doc.is_merged_document ? '(Fusionado)' : ''}
                </a>
              </TableCell>
              <TableCell className="text-center">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onFlagChange(doc.id_for_flags, 'verificado', doc.verificado, doc.tipo_for_flags)}
                  disabled={isSubmitting || !canVerify}
                  className={`hover:bg-opacity-20 ${doc.verificado ? "text-green-400 hover:bg-green-500/20" : "text-red-400 hover:bg-red-500/20"}`}
                >
                  {doc.verificado ? <CheckCircle2 size={20} /> : <AlertTriangle size={20} />}
                </Button>
              </TableCell>
              <TableCell className="text-center">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onFlagChange(doc.id_for_flags, 'cargado_en_sistema', doc.cargado_en_sistema, doc.tipo_for_flags)}
                  disabled={isSubmitting || !canVerify}
                  className={`hover:bg-opacity-20 ${doc.cargado_en_sistema ? "text-green-400 hover:bg-green-500/20" : "text-red-400 hover:bg-red-500/20"}`}
                >
                  {doc.cargado_en_sistema ? <CheckCircle2 size={20} /> : <AlertTriangle size={20} />}
                </Button>
              </TableCell>
              <TableCell className="text-center">
                {doc.tipo_documento === 'Orden de Compra' && !doc.factura_id && !doc.is_merged_document && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onUploadInvoiceClick(doc)}
                    disabled={isSubmitting}
                    className="text-blue-500 border-blue-500 hover:bg-blue-500 hover:text-white"
                    title="Cargar Factura para esta OC"
                  >
                    <UploadCloud size={16} className="mr-1.5" /> Cargar Factura
                  </Button>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default DocumentList;