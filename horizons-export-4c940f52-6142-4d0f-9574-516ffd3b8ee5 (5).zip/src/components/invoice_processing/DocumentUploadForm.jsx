import React, { useState, useContext } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { UploadCloud, Loader2, FilePlus2, CalendarDays } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { AuthContext } from '@/contexts/AuthContext';
import { formatDateForDB, getTodayDateISO, getBuenosAiresTime } from '@/lib/sheetUtils';
import { cn } from '@/lib/utils';
import { useAuth } from '@/hooks/useAuth';

const BUCKET_NAME = 'documentos.facturacion';

const DocumentUploadForm = ({ 
  suppliers, 
  loadingSuppliers, 
  availableBranches, 
  loadingBranches, 
  selectedBranchId, 
  selectedSupplierId, 
  onBranchChange, 
  onSupplierChange, 
  onUploadSuccess 
}) => {
  const [documentFile, setDocumentFile] = useState(null);
  const [fileName, setFileName] = useState('');
  const [documentNumber, setDocumentNumber] = useState('');
  const [documentDate, setDocumentDate] = useState(getTodayDateISO());
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDraggingOver, setIsDraggingOver] = useState(false);
  const { user } = useContext(AuthContext);
  const { userRole } = useAuth();
  const { toast } = useToast();
  const documentType = 'orden_compra';

  const processFile = (file) => {
    if (file) {
      if (file.type !== 'application/pdf') {
        toast({ variant: "destructive", title: "Archivo no válido", description: "Por favor, suba solo archivos PDF." });
        setDocumentFile(null); setFileName(''); return false;
      }
      if (file.size > 10 * 1024 * 1024) {
        toast({ variant: "destructive", title: "Archivo demasiado grande", description: "El PDF no debe exceder los 10MB." });
        setDocumentFile(null); setFileName(''); return false;
      }
      setDocumentFile(file); setFileName(file.name); return true;
    }
    setDocumentFile(null); setFileName(''); return false;
  };

  const handleFileChange = (e) => {
    processFile(e.target.files[0]);
    if (!e.target.files[0] && e.target) e.target.value = null;
  };

  const handleDragOver = (e) => { e.preventDefault(); e.stopPropagation(); setIsDraggingOver(true); };
  const handleDragLeave = (e) => { e.preventDefault(); e.stopPropagation(); setIsDraggingOver(false); };

  const handleDrop = (e) => {
    e.preventDefault(); e.stopPropagation(); setIsDraggingOver(false);
    const files = e.dataTransfer.files;
    if (files && files.length > 0 && processFile(files[0])) {
      const fileInput = document.getElementById('documentFile-input-oc');
      if (fileInput) fileInput.value = null; 
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!documentFile || !selectedBranchId || !selectedSupplierId || !documentNumber.trim() || !documentDate) {
      toast({ variant: "destructive", title: "Campos requeridos", description: "Por favor, complete todos los campos y seleccione un archivo." });
      return;
    }

    const today = getBuenosAiresTime();
    today.setHours(0, 0, 0, 0); 
    const selectedDate = new Date(documentDate);
    // documentDate is YYYY-MM-DD, parsing it as local might be wrong if browser is not in BA. 
    // We should parse it as BA time components
    // Simple fix: Compare YYYY-MM-DD strings directly if just checking not future.
    if (documentDate > getTodayDateISO()) {
        toast({ variant: "destructive", title: "Fecha no válida", description: "La fecha de emisión no puede ser futura." });
        return;
    }
    
    const formattedDate = formatDateForDB(documentDate);
    if (!formattedDate) {
        toast({ variant: "destructive", title: "Fecha no válida", description: "El formato de la fecha de emisión no es correcto." });
        return;
    }

    setIsSubmitting(true);
    const timestamp = new Date().toISOString();
    const uniqueFileName = `${timestamp}-${documentFile.name.replace(/\s+/g, '_')}`;
    const filePath = `${user.id}/${documentType}/${selectedBranchId}/${selectedSupplierId}/${uniqueFileName}`;

    try {
      const { error: uploadError } = await supabase.storage.from(BUCKET_NAME).upload(filePath, documentFile);
      if (uploadError) throw new Error(`Error al subir archivo: ${uploadError.message}`);
      
      const { data: { publicUrl } } = supabase.storage.from(BUCKET_NAME).getPublicUrl(filePath);
      if (!publicUrl) throw new Error("No se pudo obtener la URL pública del archivo.");
      
      const { error: insertError } = await supabase.from('ordenes_compra').insert({
          fecha: formattedDate, 
          sucursal_id: parseInt(selectedBranchId),
          proveedor_id: parseInt(selectedSupplierId),
          numero_pedido: documentNumber,
          archivo_url: publicUrl,
          verificado: false, cargado_en_sistema: false, creado_por: user.id
        });
      if (insertError) {
        await supabase.storage.from(BUCKET_NAME).remove([filePath]);
        throw new Error(`Error al guardar en base de datos: ${insertError.message}`);
      }

      toast({ title: "Éxito", description: `Orden de Compra "${documentNumber}" cargada correctamente.` });
      setDocumentFile(null); setFileName(''); setDocumentNumber('');
      setDocumentDate(getTodayDateISO());
      const fileInput = document.getElementById('documentFile-input-oc');
      if (fileInput) fileInput.value = null;
      onUploadSuccess(); 

    } catch (error) {
      toast({ variant: "destructive", title: "Error en el proceso", description: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  const isSubmitDisabled = !documentFile || !selectedBranchId || !selectedSupplierId || !documentNumber.trim() || !documentDate || isSubmitting;
  const canSelectBranch = ['admin', 'centralizada'].includes(userRole);

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <Label htmlFor="documentFile-input-oc" className="text-foreground">Archivo Orden de Compra (PDF) *</Label>
        <div 
          className={cn("mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-dashed rounded-md border-border hover:border-primary transition-all", isDraggingOver && "border-primary bg-primary/10 scale-105", isSubmitting && "bg-muted/50 cursor-not-allowed")}
          onDragOver={handleDragOver} onDragLeave={handleDragLeave} onDrop={handleDrop}
        >
          <div className="space-y-1 text-center">
            <UploadCloud className={cn("mx-auto h-12 w-12 text-muted-foreground", isDraggingOver && "text-primary animate-bounce")} />
            <div className="flex text-sm text-muted-foreground">
              <Label htmlFor="documentFile-input-oc" className={cn("relative cursor-pointer rounded-md font-medium text-primary hover:text-primary/80", isSubmitting && "cursor-not-allowed opacity-50")}>
                <span>{fileName || 'Subir un archivo'}</span>
                <Input id="documentFile-input-oc" name="documentFileOC" type="file" accept=".pdf" className="sr-only" onChange={handleFileChange} disabled={isSubmitting} />
              </Label>
              {!fileName && <p className="pl-1">o arrastrar y soltar</p>}
            </div>
            <p className="text-xs text-muted-foreground">PDF hasta 10MB</p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="documentNumber-oc" className="text-foreground">Número de Orden de Compra *</Label>
          <Input id="documentNumber-oc" value={documentNumber} onChange={(e) => setDocumentNumber(e.target.value)} placeholder="Ej: OC-5678" required disabled={isSubmitting} />
        </div>
        <div>
          <Label htmlFor="documentDate-oc" className="text-foreground flex items-center"><CalendarDays className="w-4 h-4 mr-1.5" />Fecha de Emisión OC *</Label>
          <Input id="documentDate-oc" type="date" value={documentDate} onChange={(e) => setDocumentDate(e.target.value)} required disabled={isSubmitting} max={getTodayDateISO()} />
        </div>
      </div>

      <div>
        <Label htmlFor="branch-doc-oc" className="text-foreground">Sucursal *</Label>
        <Select onValueChange={onBranchChange} value={selectedBranchId} disabled={loadingBranches || isSubmitting || !canSelectBranch}>
          <SelectTrigger id="branch-doc-oc"><SelectValue placeholder={loadingBranches ? "Cargando..." : "Seleccione sucursal"} /></SelectTrigger>
          <SelectContent>
            {availableBranches.map(branch => (<SelectItem key={branch.id} value={branch.id.toString()}>{branch.nombre}</SelectItem>))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="supplier-doc-oc" className="text-foreground">Proveedor *</Label>
        <Select onValueChange={onSupplierChange} value={selectedSupplierId} disabled={loadingSuppliers || suppliers.length === 0 || isSubmitting}>
          <SelectTrigger id="supplier-doc-oc"><SelectValue placeholder={loadingSuppliers ? "Cargando..." : (suppliers.length === 0 ? "No hay proveedores" : "Seleccione proveedor")} /></SelectTrigger>
          <SelectContent>
            {suppliers.map(supplier => (<SelectItem key={supplier.id} value={supplier.id.toString()}>{supplier.name}</SelectItem>))}
          </SelectContent>
        </Select>
      </div>
      <Button type="submit" className="w-full bg-gradient-to-r from-primary to-accent text-primary-foreground" disabled={isSubmitDisabled}>
         {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FilePlus2 className="mr-2 h-4 w-4" />}
        {isSubmitting ? 'Cargando OC...' : 'Cargar Orden de Compra'}
      </Button>
    </form>
  );
};

export default DocumentUploadForm;