import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { CalendarPlus as CalendarIcon, DollarSign, FileText, User, Building, Save, Loader2, Paperclip, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { useBranch } from '@/contexts/BranchContext';
import { calculateAndSaveCurrentMonthBalance } from '@/services/balanceService';
import { logModificationAndNotify } from '@/lib/modificationLogger';
import { formatDateForDB, getTodayDateISO } from '@/lib/sheetUtils';

const EntryForm = () => {
  const { toast } = useToast();
  const { user, userRole, userProfile } = useAuth();
  const { availableBranches, loadingBranches, getBranchNameById } = useBranch();
  
  const [selectedBranchId, setSelectedBranchId] = useState('');
  const [comprobanteFile, setComprobanteFile] = useState(null);

  const [formData, setFormData] = useState({
    fecha: getTodayDateISO(),
    monto: '',
    ioe: 'E',
    tipo_ioe: '',
    razon_social: '',
    observaciones: '',
    verificado: false,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (userRole !== 'admin' && userProfile?.sucursal_id) {
      setSelectedBranchId(userProfile.sucursal_id.toString());
    }
  }, [userProfile, userRole]);

  useEffect(() => {
    const isVerified = userRole === 'gerente' || userRole === 'admin';
    setFormData(prev => ({ 
      ...prev, 
      sucursal_id: selectedBranchId, 
      verificado: isVerified,
    }));
  }, [selectedBranchId, userRole]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const parseCurrency = (value) => {
    if (!value) return '';
    let str = String(value).trim();
    if (str.includes(',')) {
      const cleanStr = str.replace(/[$\s\.]/g, '');
      return cleanStr.replace(',', '.');
    }
    return str.replace(/[$\s]/g, '');
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;
    if (name === 'monto' && value.trim() !== '') {
      const rawValue = parseCurrency(value);
      const numericValue = parseFloat(rawValue);
      
      if (!isNaN(numericValue)) {
        const formatted = new Intl.NumberFormat('es-AR', {
          style: 'currency',
          currency: 'ARS',
          minimumFractionDigits: 2,
          maximumFractionDigits: 2
        }).format(numericValue);
        setFormData(prev => ({ ...prev, monto: formatted }));
      }
    }
  };

  const handleFocus = (e) => {
    const { name, value } = e.target;
    if (name === 'monto' && value.trim() !== '') {
      const rawValue = parseCurrency(value);
      const numericValue = parseFloat(rawValue);
      if (!isNaN(numericValue)) {
        setFormData(prev => ({ ...prev, monto: numericValue.toString() }));
      }
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setComprobanteFile(file);
    }
  };

  const handleRadioChange = (value) => {
    setFormData(prev => ({ ...prev, ioe: value, tipo_ioe: '', razon_social: '' }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!user || !user.email) {
      toast({ variant: "destructive", title: "Error de autenticación", description: "No se pudo verificar el usuario." });
      return;
    }
    if (!selectedBranchId) {
      toast({ variant: "destructive", title: "Error de validación", description: "Por favor, seleccione una sucursal." });
      return;
    }

    setIsSubmitting(true);

    const rawMonto = parseCurrency(formData.monto);
    const normalizedMonto = parseFloat(rawMonto);

    if (isNaN(normalizedMonto) || normalizedMonto <= 0) {
      toast({ variant: "destructive", title: "Error de validación", description: "El monto debe ser un número positivo." });
      setIsSubmitting(false);
      return;
    }
    
    const formattedDate = formatDateForDB(formData.fecha);
    if (!formattedDate) {
        toast({ variant: "destructive", title: "Error de validación", description: "La fecha ingresada no es válida." });
        setIsSubmitting(false);
        return;
    }

    let comprobanteUrl = null;
    try {
      if (comprobanteFile) {
        const sanitizedFileName = comprobanteFile.name.replace(/\s+/g, '_').replace(/[^a-zA-Z0-9-._]/g, '');
        const filePath = `${selectedBranchId}/${formattedDate}/${Date.now()}-${sanitizedFileName}`;
        
        const { error: uploadError } = await supabase.storage
          .from('comprobantes-entradas-diarias')
          .upload(filePath, comprobanteFile);

        if (uploadError) {
          throw new Error(`Error al subir el comprobante: ${uploadError.message}`);
        }

        const { data: urlData } = supabase.storage.from('comprobantes-entradas-diarias').getPublicUrl(filePath);
        comprobanteUrl = urlData.publicUrl;
      }

      const isEntryVerified = userRole === 'gerente' || userRole === 'admin';

      const entryData = {
        fecha: formattedDate,
        monto: normalizedMonto, 
        ioe: formData.ioe,
        tipo_ioe: formData.tipo_ioe,
        razon_social: formData.razon_social,
        observaciones: formData.observaciones,
        debe: formData.ioe === 'I' ? normalizedMonto : 0,
        haber: formData.ioe === 'E' ? normalizedMonto : 0,
        sucursal_id: parseInt(selectedBranchId),
        usuario_email: user.email,
        comprobante_url: comprobanteUrl,
        verificado: isEntryVerified,
      };

      const { error: insertError } = await supabase.from('entradas_diarias').insert([entryData]);

      if (insertError) {
        throw new Error(`Error al guardar la entrada: ${insertError.message}`);
      }
      
      if(isEntryVerified){
        const monthYear = entryData.fecha.slice(0, 7);
        await calculateAndSaveCurrentMonthBalance(parseInt(selectedBranchId), monthYear, user.email);
        await logModificationAndNotify(supabase, toast, getBranchNameById, parseInt(selectedBranchId), monthYear, user.email, 'entrada_manual');
        toast({ title: "Éxito", description: "Movimiento guardado y saldo recalculado." });
      } else {
        toast({ title: "Éxito", description: "Movimiento guardado y pendiente de verificación por gerencia." });
      }

      const isNextVerified = userRole === 'gerente' || userRole === 'admin';
      setFormData({
        fecha: getTodayDateISO(),
        monto: '',
        ioe: 'E',
        tipo_ioe: '',
        razon_social: '',
        observaciones: '',
        sucursal_id: selectedBranchId,
        verificado: isNextVerified,
      });
      setComprobanteFile(null);

    } catch (error) {
      console.error("Error en handleSubmit:", error);
      toast({ variant: "destructive", title: "Error", description: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <motion.div initial="hidden" animate="visible" variants={cardVariants} className="container mx-auto p-4 md:p-8 max-w-3xl">
      <Card className="shadow-2xl overflow-hidden bg-gradient-to-br from-background to-muted/30">
        <CardHeader className="bg-primary/10 p-6">
          <CardTitle className="text-3xl font-bold text-primary flex items-center">
            <FileText className="w-8 h-8 mr-3 text-primary" />
            Registrar Movimiento en Planilla
          </CardTitle>
          <CardDescription className="text-muted-foreground text-base">
            Complete los detalles de la transacción. Los campos marcados con * son obligatorios.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6 md:p-8">
          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="sucursal_id" className="text-lg font-semibold text-foreground flex items-center mb-2">
                  <Building className="w-5 h-5 mr-2 text-primary" /> Sucursal *
                </Label>
                <Select onValueChange={value => setSelectedBranchId(value)} value={selectedBranchId || ''} disabled={loadingBranches || isSubmitting || userRole !== 'admin'}>
                    <SelectTrigger id="sucursal_id">
                        <SelectValue placeholder={loadingBranches ? "Cargando sucursales..." : "Seleccione una sucursal"} />
                    </SelectTrigger>
                    <SelectContent>
                        {availableBranches.map(branch => (
                        <SelectItem key={branch.id} value={branch.id.toString()}>{branch.nombre}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="fecha" className="text-lg font-semibold text-foreground flex items-center mb-2">
                  <CalendarIcon className="w-5 h-5 mr-2 text-primary" /> Fecha *
                </Label>
                <Input type="date" id="fecha" name="fecha" value={formData.fecha} onChange={handleChange} required disabled={isSubmitting} className="text-base p-3 bg-input border-border focus:border-primary" />
              </div>
            </div>

            <div>
              <Label htmlFor="monto" className="text-lg font-semibold text-foreground flex items-center mb-2">
                <DollarSign className="w-5 h-5 mr-2 text-primary" /> Monto *
              </Label>
              <Input 
                type="text" 
                id="monto" 
                name="monto" 
                placeholder="Ej: 1500.50 o $1,500.50" 
                value={formData.monto} 
                onChange={handleChange} 
                onBlur={handleBlur}
                onFocus={handleFocus}
                required 
                disabled={isSubmitting} 
                className="text-base p-3 bg-input border-border focus:border-primary text-black" 
              />
            </div>

            <div>
              <Label className="text-lg font-semibold text-foreground mb-2 block">Tipo de Movimiento *</Label>
              <RadioGroup name="ioe" value={formData.ioe} onValueChange={handleRadioChange} className="flex space-x-4" disabled={isSubmitting}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="E" id="egreso" />
                  <Label htmlFor="egreso" className="text-base">Egreso</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="I" id="ingreso" />
                  <Label htmlFor="ingreso" className="text-base">Ingreso</Label>
                </div>
              </RadioGroup>
            </div>

            <div>
              <Label htmlFor="tipo_ioe" className="text-lg font-semibold text-foreground flex items-center mb-2">
                <FileText className="w-5 h-5 mr-2 text-primary" /> Tipo de {formData.ioe === 'I' ? 'Ingreso' : 'Egreso'} *
              </Label>
              <Input type="text" id="tipo_ioe" name="tipo_ioe" placeholder={formData.ioe === 'I' ? "Ej: Venta de Mercadería" : "Ej: Compra de Insumos"} value={formData.tipo_ioe} onChange={handleChange} required disabled={isSubmitting} className="text-base p-3 bg-input border-border focus:border-primary text-black" />
            </div>

            <div>
              <Label htmlFor="razon_social" className="text-lg font-semibold text-foreground flex items-center mb-2">
                <User className="w-5 h-5 mr-2 text-primary" /> Nombre/Razón Social *
              </Label>
              <Input type="text" id="razon_social" name="razon_social" placeholder={formData.ioe === 'I' ? "Cliente" : "Proveedor"} value={formData.razon_social} onChange={handleChange} required disabled={isSubmitting} className="text-base p-3 bg-input border-border focus:border-primary text-black" />
            </div>

            <div>
              <Label htmlFor="observaciones" className="text-lg font-semibold text-foreground flex items-center mb-2">
                Observaciones
              </Label>
              <Textarea id="observaciones" name="observaciones" placeholder="Detalles adicionales de la transacción..." value={formData.observaciones} onChange={handleChange} disabled={isSubmitting} className="text-base p-3 bg-input border-border focus:border-primary min-h-[100px] text-black" />
            </div>

            <div>
              <Label htmlFor="comprobante" className="text-lg font-semibold text-foreground flex items-center mb-2">
                <Paperclip className="w-5 h-5 mr-2 text-primary" /> Comprobante (Opcional)
              </Label>
              <Input id="comprobante" type="file" accept="image/*,application/pdf" onChange={handleFileChange} disabled={isSubmitting} className="text-base file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20" />
              {comprobanteFile && (
                <p className="text-sm text-green-500 mt-2 flex items-center">
                  <CheckCircle className="w-4 h-4 mr-2" /> Archivo seleccionado: {comprobanteFile.name}
                </p>
              )}
            </div>

            <Button type="submit" className="w-full text-lg py-3 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 text-primary-foreground font-semibold rounded-lg shadow-md hover:shadow-lg transition-all duration-300 ease-in-out transform hover:-translate-y-0.5" disabled={isSubmitting || loadingBranches}>
              {isSubmitting ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Save className="mr-2 h-5 w-5" />}
              {isSubmitting ? 'Guardando...' : 'Guardar Movimiento'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default EntryForm;