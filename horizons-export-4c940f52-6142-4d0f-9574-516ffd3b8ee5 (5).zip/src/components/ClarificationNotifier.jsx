import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Loader2, MessageCircle } from 'lucide-react';

const ClarificationNotifier = () => {
    const { user } = useAuth();
    const { toast } = useToast();
    const [pendingClarification, setPendingClarification] = useState(null);
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [response, setResponse] = useState('');
    const [isProcessing, setIsProcessing] = useState(false);

    const checkClarifications = useCallback(async () => {
        if (!user) return;

        // Check for requests needing response from the current user
        // Changed from .single() to .limit(1) to avoid PGRST116 error when no rows exist
        const { data: requests, error: requestError } = await supabase
            .from('aclaraciones_pagos')
            .select('*, solicitado_por:user_profiles!aclaraciones_pagos_solicitado_por_id_fkey(full_name)')
            .eq('dirigido_a_id', user.id)
            .eq('estado', 'pendiente_respuesta')
            .limit(1);
        
        if (requestError) {
            console.error("Error checking for clarifications:", requestError);
            return;
        }

        if (requests && requests.length > 0) {
            setPendingClarification(requests[0]);
            setIsDialogOpen(true);
        } else {
            // If no pending requests, check for responses for the current user (if admin)
            // Changed from .single() to .limit(1) to avoid PGRST116 error
             const { data: responses, error: responseError } = await supabase
                .from('aclaraciones_pagos')
                .select('*, dirigido_a:user_profiles!aclaraciones_pagos_dirigido_a_id_fkey(full_name)')
                .eq('solicitado_por_id', user.id)
                .eq('estado', 'respondido')
                .limit(1);

            if (responses && responses.length > 0) {
                 setPendingClarification(responses[0]);
                 setIsDialogOpen(true);
            } else if(responseError){
                 console.error("Error checking for responses:", responseError);
            }
        }

    }, [user]);

    useEffect(() => {
        // Check for notifications shortly after login
        const timer = setTimeout(() => {
            checkClarifications();
        }, 3000); // 3-second delay to not be too intrusive
        return () => clearTimeout(timer);
    }, [checkClarifications]);

    const handleSubmitResponse = async () => {
        if (!pendingClarification || !response.trim()) {
            toast({ variant: 'destructive', title: 'Error', description: 'La respuesta no puede estar vacía.' });
            return;
        }
        setIsProcessing(true);

        const { error } = await supabase
            .from('aclaraciones_pagos')
            .update({ 
                respuesta_aclaracion: response.trim(),
                estado: 'respondido',
                respondido_en: new Date().toISOString()
            })
            .eq('id', pendingClarification.id);
        
        if (error) {
            toast({ variant: 'destructive', title: 'Error', description: 'No se pudo enviar la respuesta.' });
        } else {
            toast({ title: 'Éxito', description: 'Respuesta enviada correctamente.' });
            setIsDialogOpen(false);
            setPendingClarification(null);
        }
        setIsProcessing(false);
    };

    const handleAcknowledgeResponse = async () => {
         if (!pendingClarification) return;
         setIsProcessing(true);
         const { error } = await supabase
            .from('aclaraciones_pagos')
            .update({ estado: 'cerrado' })
            .eq('id', pendingClarification.id);

         if (error) {
            toast({ variant: 'destructive', title: 'Error', description: 'No se pudo cerrar la aclaración.' });
         } else {
            toast({ title: 'Aclaración Cerrada', description: 'El ciclo de aclaración ha sido completado.' });
            setIsDialogOpen(false);
            setPendingClarification(null);
         }
         setIsProcessing(false);
    }

    if (!pendingClarification) return null;

    const isAwaitingResponse = pendingClarification.estado === 'pendiente_respuesta' && pendingClarification.dirigido_a_id === user?.id;
    const isViewingResponse = pendingClarification.estado === 'respondido' && pendingClarification.solicitado_por_id === user?.id;

    return (
        <Dialog open={isDialogOpen} onOpenChange={(open) => { if (!open) setPendingClarification(null); setIsDialogOpen(open); }}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle className="flex items-center">
                        <MessageCircle className="mr-2 h-6 w-6 text-primary" />
                        {isAwaitingResponse ? 'Solicitud de Aclaración' : 'Respuesta Recibida'}
                    </DialogTitle>
                    <DialogDescription>
                        {isAwaitingResponse 
                            ? `El administrador ${pendingClarification.solicitado_por?.full_name || 'Desconocido'} solicita una aclaración sobre un lote de pago que procesaste.`
                            : `El usuario ${pendingClarification.dirigido_a?.full_name || 'Desconocido'} ha respondido a tu solicitud.`
                        }
                    </DialogDescription>
                </DialogHeader>
                <div className="py-4 space-y-4">
                    <div>
                        <Label>Mensaje Original:</Label>
                        <p className="p-3 bg-muted rounded-md text-sm">{pendingClarification.mensaje_solicitud}</p>
                    </div>

                    {isViewingResponse && (
                         <div>
                            <Label>Respuesta:</Label>
                            <p className="p-3 bg-blue-100 dark:bg-blue-900/50 rounded-md text-sm">{pendingClarification.respuesta_aclaracion}</p>
                        </div>
                    )}

                    {isAwaitingResponse && (
                        <div>
                            <Label htmlFor="clarification-response">Tu Respuesta:</Label>
                            <Textarea
                                id="clarification-response"
                                placeholder="Escribe tu respuesta aquí..."
                                value={response}
                                onChange={(e) => setResponse(e.target.value)}
                            />
                        </div>
                    )}
                </div>
                <DialogFooter>
                   {isAwaitingResponse && (
                     <Button onClick={handleSubmitResponse} disabled={isProcessing}>
                        {isProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                        Enviar Respuesta
                     </Button>
                   )}
                   {isViewingResponse && (
                     <Button onClick={handleAcknowledgeResponse} disabled={isProcessing}>
                        {isProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                        Entendido, Cerrar
                     </Button>
                   )}
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

export default ClarificationNotifier;