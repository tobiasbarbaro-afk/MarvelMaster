import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';

const ProtectedSafeBoxRoute = ({ children }) => {
  const { isAuthenticated, loading, userRole } = useAuth();
  
  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <div className="text-primary text-xl">Cargando...</div>
      </div>
    );
  }
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // Deny Cocina, allow Admin, Gerente, Centralizada, Mostrador
  const allowedRoles = ['admin', 'gerente', 'centralizada', 'mostrador'];
  
  if (!allowedRoles.includes(userRole)) {
    return <Navigate to="/" replace />;
  }

  return children;
};

export default ProtectedSafeBoxRoute;