import React, { useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, UploadCloud } from 'lucide-react';

const UploadSignedRemitoDialog = ({ order, isOpen, onClose, onOrderManaged }) => {
    const { toast } = useToast();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [signedRemitoFile, setSignedRemitoFile] = useState(null);
    const [observaciones, setObservaciones] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!signedRemitoFile) {
            toast({ variant: 'destructive', title: 'Falta archivo', description: 'Debes cargar el remito firmado.' });
            return;
        }
        setIsSubmitting(true);

        try {
            const filePath = `remitos_firmados/${order.id}/${signedRemitoFile.name}`;
            const { error: uploadError } = await supabase.storage
                .from('remitos_centralizada')
                .upload(filePath, signedRemitoFile, { upsert: true });

            if (uploadError) throw uploadError;

            const { data: urlData } = supabase.storage.from('remitos_centralizada').getPublicUrl(filePath);
            if (!urlData) throw new Error('No se pudo obtener la URL del remito firmado.');

            const { error: updateError } = await supabase
                .from('pedidos_centralizada')
                .update({
                    estado: 'firma_pendiente',
                    remito_firmado_url: urlData.publicUrl,
                    observaciones: observaciones || null,
                })
                .eq('id', order.id);

            if (updateError) throw updateError;

            toast({ title: 'Éxito', description: 'Remito firmado cargado y recepción confirmada.' });
            onOrderManaged();
            onClose();
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: `No se pudo cargar el remito: ${error.message}` });
        } finally {
            setIsSubmitting(false);
        }
    };

    if (!order) return null;

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Cargar Remito Firmado y Confirmar Recepción</DialogTitle>
                    <DialogDescription>
                        Sube el archivo PDF del remito firmado para el pedido de la sucursal {order.sucursales.nombre}. Esto notificará a la central.
                    </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4 pt-4">
                    <div>
                        <Label htmlFor="remito_firmado">Archivo PDF del remito firmado</Label>
                        <Input id="remito_firmado" type="file" accept="application/pdf" onChange={(e) => setSignedRemitoFile(e.target.files[0])} />
                    </div>
                    <div>
                        <Label htmlFor="observaciones">Observaciones (opcional)</Label>
                        <Textarea 
                            id="observaciones"
                            placeholder="Ej: Llegó con una caja rota, faltaron 2 unidades de ketchup..."
                            value={observaciones}
                            onChange={(e) => setObservaciones(e.target.value)}
                        />
                    </div>
                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
                        <Button type="submit" disabled={isSubmitting || !signedRemitoFile}>
                            {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UploadCloud className="mr-2 h-4 w-4" />}
                            Cargar y Confirmar
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default UploadSignedRemitoDialog;