import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2, PackageCheck, Calendar as CalendarIcon, Truck, FileText } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import AssignSupplierDialog from './AssignSupplierDialog';
import { checkFaltantesForPedido, resolveFaltantesForPedido, safeUpdatePedidoStatus } from '@/lib/orderConstraintHelper';
import { updateInternalOrderAfterProviderAssignment } from '@/lib/internalOrderHelper';

const ManageOrderDialog = ({ order, isOpen, onClose, onOrderUpdated, productosMap }) => {
    const { toast } = useToast();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [sentProducts, setSentProducts] = useState([]);
    const [shippingDate, setShippingDate] = useState('');
    const [productsForSupplier, setProductsForSupplier] = useState(new Set());
    const [isAssignSupplierOpen, setIsAssignSupplierOpen] = useState(false);

    const { userRole } = useAuth();
    const { user } = useAuth();

    const isProviderOrder = order?.tipo_pedido === 'proveedor';
    const canAssignToSupplier = !isProviderOrder && ['admin', 'centralizada', 'gerente'].includes(userRole);

    useEffect(() => {
        if (order) {
            setSentProducts(order.productos.map(p => ({
                ...p,
                cantidad_enviada: p.cantidad_enviada || 0,
            })));
            
            const dateToSet = order.fecha_envio ? new Date(order.fecha_envio) : new Date();
            dateToSet.setMinutes(dateToSet.getMinutes() - dateToSet.getTimezoneOffset());
            setShippingDate(dateToSet.toISOString().split('T')[0]);
            setProductsForSupplier(new Set());
        }
    }, [order]);

    const handleProductQuantityChange = (producto_id, cantidad_enviada) => {
        const originalProduct = order.productos.find(p => p.producto_id === producto_id);
        const requestedQuantity = originalProduct.cantidad;
        
        let finalQuantity = parseInt(cantidad_enviada, 10);
        if (isNaN(finalQuantity) || finalQuantity < 0) {
            finalQuantity = 0;
        } else if (finalQuantity > requestedQuantity) {
            finalQuantity = requestedQuantity;
            toast({
                variant: 'destructive',
                title: 'Cantidad excedida',
                description: `No puedes enviar más de la cantidad solicitada (${requestedQuantity}).`
            });
        }

        setSentProducts(sentProducts.map(p =>
            p.producto_id === producto_id ? { ...p, cantidad_enviada: finalQuantity } : p
        ));
    };

    const handleSupplierCheckboxChange = (productId) => {
        setProductsForSupplier(prev => {
            const newSet = new Set(prev);
            if (newSet.has(productId)) {
                newSet.delete(productId);
            } else {
                newSet.add(productId);
            }
            return newSet;
        });
    };

    const handleOpenAssignSupplier = () => {
        if (productsForSupplier.size === 0) {
            toast({ variant: 'destructive', title: 'Error', description: 'Seleccione al menos un producto para pedir a un proveedor.' });
            return;
        }
        setIsAssignSupplierOpen(true);
    };

    const handleProviderSubmit = async () => {
        if (!shippingDate) {
            toast({ variant: 'destructive', title: 'Error', description: 'Por favor, selecciona una fecha.' });
            return;
        }
        setIsSubmitting(true);

        try {
            const updateResult = await safeUpdatePedidoStatus(order.id, {
                estado: 'orden_generada',
                fecha_envio: new Date(shippingDate).toISOString(),
            });

            if (!updateResult || !updateResult.success) {
                throw new Error('Falló la actualización inicial del estado del pedido.');
            }

            const { data, error: funcError } = await supabase.functions.invoke('generate-orden-compra', {
                body: { orderId: order.id }
            });

            if (funcError) throw funcError;
            if (data && !data.success) throw new Error(data.error || 'Error desconocido al generar OC.');

            const { error: confirmError } = await supabase
                .from('pedidos_centralizada')
                .update({ estado: 'confirmado' })
                .eq('id', order.id);
            
            if (confirmError) throw confirmError;

            toast({ title: 'Éxito', description: 'Orden de Compra generada y pedido confirmado.' });
            if (onOrderUpdated) onOrderUpdated();
            onClose();

        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: `No se pudo procesar la orden: ${error.message}` });
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleInternalSubmit = async (e) => {
        e.preventDefault();
        if (!shippingDate) {
            toast({ variant: 'destructive', title: 'Error', description: 'Por favor, selecciona una fecha de envío.' });
            return;
        }
        setIsSubmitting(true);

        try {
            const { hasFaltantes } = await checkFaltantesForPedido(order.id);
            if (hasFaltantes) {
                await resolveFaltantesForPedido(order.id);
            }

            const updatedProducts = order.productos.map(p => {
                const sentProduct = sentProducts.find(sp => sp.producto_id === p.producto_id);
                return {
                    ...p,
                    cantidad_enviada: sentProduct ? sentProduct.cantidad_enviada : p.cantidad_enviada || 0,
                };
            });

            await safeUpdatePedidoStatus(order.id, {
                estado: 'gestionado',
                productos: updatedProducts,
                fecha_envio: new Date(shippingDate).toISOString(),
            });

            const missingItems = [];
            for (const product of updatedProducts) {
                const requested = product.cantidad;
                const sent = product.cantidad_enviada;
                if (sent < requested) {
                    missingItems.push({
                        sucursal_id: order.sucursal_id,
                        pedido_id: order.id,
                        producto_id: product.producto_id,
                        cantidad_faltante: requested - sent,
                        fecha_pedido: new Date(order.fecha_pedido).toISOString().split('T')[0],
                        estado: 'pendiente',
                        creado_por: user.id,
                    });
                }
            }

            if (missingItems.length > 0) {
                const { error: missingError } = await supabase
                    .from('faltantes_centralizada')
                    .insert(missingItems);
                if (missingError) console.error('Missing items err:', missingError);
            }

            toast({ title: 'Éxito', description: 'Pedido gestionado correctamente.' });
            if (onOrderUpdated) onOrderUpdated();
            onClose();
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: `No se pudo actualizar el pedido: ${error.message}` });
        } finally {
            setIsSubmitting(false);
        }
    };

    if (!order) return null;

    const selectedProductsForSupplier = sentProducts
        .filter(p => productsForSupplier.has(p.producto_id))
        .map(p => ({
            ...p,
            cantidad_gestionada: p.cantidad_enviada
        }));

    return (
        <>
            <Dialog open={isOpen} onOpenChange={onClose}>
                <DialogContent className="sm:max-w-2xl max-h-[90vh] flex flex-col">
                    <DialogHeader className="flex-shrink-0">
                        <DialogTitle>{isProviderOrder ? 'Confirmar Orden de Compra' : 'Gestionar Pedido'}</DialogTitle>
                        <DialogDescription>
                            {isProviderOrder 
                                ? `Proveedor: ${order.suppliers?.name || 'Desconocido'} - Fecha: ${new Date(order.fecha_pedido).toLocaleDateString()}`
                                : `Sucursal: ${order.sucursales?.nombre} - Fecha Pedido: ${new Date(order.fecha_pedido).toLocaleDateString()}`
                            }
                        </DialogDescription>
                    </DialogHeader>
                    <div className="flex-grow overflow-y-auto pr-6 space-y-4">
                        <form onSubmit={isProviderOrder ? (e) => e.preventDefault() : handleInternalSubmit} className="flex flex-col h-full">
                            <div className="space-y-4 flex-grow">
                                <div className="space-y-2">
                                    <Label htmlFor="shippingDate" className="flex items-center">
                                        <CalendarIcon className="mr-2 h-4 w-4" />
                                        {isProviderOrder ? 'Fecha de Generación' : 'Fecha de Envío'}
                                    </Label>
                                    <Input
                                        id="shippingDate"
                                        type="date"
                                        value={shippingDate}
                                        onChange={(e) => setShippingDate(e.target.value)}
                                        className="w-full"
                                        required
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>{isProviderOrder ? 'Productos en Orden' : 'Productos a Enviar / Pedir'}</Label>
                                    {sentProducts.map(p => (
                                        <div key={p.producto_id} className="flex items-center justify-between gap-4 p-2 border rounded-md">
                                            {canAssignToSupplier && (
                                                <Checkbox
                                                    id={`supplier-check-${p.producto_id}`}
                                                    checked={productsForSupplier.has(p.producto_id)}
                                                    onCheckedChange={() => handleSupplierCheckboxChange(p.producto_id)}
                                                    className="w-5 h-5"
                                                />
                                            )}
                                            <div className="flex-1">
                                                <p className="font-medium">{productosMap[p.producto_id]?.nombre || 'Producto desconocido'}</p>
                                                <p className="text-sm text-muted-foreground">Solicitado: {p.cantidad} {productosMap[p.producto_id]?.unidad_medida}</p>
                                            </div>
                                            {!isProviderOrder && (
                                                <div className="w-32">
                                                    <Label htmlFor={`sent-${p.producto_id}`} className="text-xs">
                                                        {productsForSupplier.has(p.producto_id) ? 'Cantidad a pedir' : 'Cantidad a enviar'}
                                                    </Label>
                                                    <Input
                                                        id={`sent-${p.producto_id}`}
                                                        type="number"
                                                        min="0"
                                                        max={p.cantidad}
                                                        value={p.cantidad_enviada}
                                                        onChange={(e) => handleProductQuantityChange(p.producto_id, e.target.value)}
                                                    />
                                                </div>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </div>
                            <DialogFooter className="pt-4 flex-shrink-0 sticky bottom-0 bg-card pb-0 pr-0">
                                {isProviderOrder ? (
                                    <>
                                        <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>Cancelar</Button>
                                        <Button type="button" onClick={handleProviderSubmit} disabled={isSubmitting}>
                                            {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileText className="mr-2 h-4 w-4" />}
                                            Confirmar y Generar OC
                                        </Button>
                                    </>
                                ) : (
                                    <>
                                        {canAssignToSupplier && (
                                            <Button type="button" variant="secondary" onClick={handleOpenAssignSupplier} disabled={productsForSupplier.size === 0}>
                                                <Truck className="mr-2 h-4 w-4" />
                                                Pedir a Proveedor ({productsForSupplier.size})
                                            </Button>
                                        )}
                                        <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
                                        <Button type="submit" disabled={isSubmitting}>
                                            {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <PackageCheck className="mr-2 h-4 w-4" />}
                                            Gestionar Envío Interno
                                        </Button>
                                    </>
                                )}
                            </DialogFooter>
                        </form>
                    </div>
                </DialogContent>
            </Dialog>
            {canAssignToSupplier && (
                <AssignSupplierDialog
                    isOpen={isAssignSupplierOpen}
                    onClose={() => setIsAssignSupplierOpen(false)}
                    originalOrder={order}
                    productsToAssign={selectedProductsForSupplier}
                    productosMap={productosMap}
                    onAssignmentComplete={(assignedIds) => {
                        setIsAssignSupplierOpen(false);
                        if (onOrderUpdated) onOrderUpdated();
                        onClose();
                    }}
                />
            )}
        </>
    );
};

export default ManageOrderDialog;