import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useBranch } from '@/contexts/BranchContext';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { PlusCircle, Loader2, ShoppingCart, XCircle, Building, Truck } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

const NewOrderForm = ({ onOrderCreated }) => {
    const { availableBranches, loadingBranches } = useBranch();
    const { toast } = useToast();
    const { user, userProfile, userRole } = useAuth();

    const [sucursalId, setSucursalId] = useState('');
    const [tipoPedido, setTipoPedido] = useState('interno'); // 'interno' or 'proveedor'
    const [proveedorId, setProveedorId] = useState('');
    
    const [productosList, setProductosList] = useState([]);
    const [rubros, setRubros] = useState([]);
    const [proveedores, setProveedores] = useState([]);
    const [selectedRubro, setSelectedRubro] = useState('');
    
    const [orderItems, setOrderItems] = useState({});
    const [productQuantities, setProductQuantities] = useState({});

    const [loadingData, setLoadingData] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const isCentral = userRole === 'admin' || userRole === 'centralizada';

    useEffect(() => {
        if (!isCentral && userProfile?.sucursal_id) {
            setSucursalId(userProfile.sucursal_id.toString());
            setTipoPedido('interno'); // Branches can usually only make internal requests
        }
    }, [userProfile, userRole, isCentral]);

    useEffect(() => {
        const fetchData = async () => {
            setLoadingData(true);
            try {
                // Fetch Products
                const { data: productsData, error: productsError } = await supabase
                    .from('productos_centralizada')
                    .select('id, nombre, unidad_medida, unidad_medida_stock, Rubro')
                    .order('Rubro', { ascending: true })
                    .order('nombre', { ascending: true });

                if (productsError) throw productsError;

                setProductosList(productsData);
                const uniqueRubros = [...new Set(productsData.map(p => p.Rubro).filter(Boolean))];
                setRubros(uniqueRubros);

                // Fetch Suppliers if Central
                if (isCentral) {
                    const { data: suppliersData, error: suppliersError } = await supabase
                        .from('suppliers')
                        .select('id, name')
                        .order('name');
                    
                    if (suppliersError) throw suppliersError;
                    setProveedores(suppliersData || []);
                }

            } catch (error) {
                toast({ variant: 'destructive', title: 'Error', description: 'No se pudieron cargar los datos necesarios.' });
                console.error(error);
            } finally {
                setLoadingData(false);
            }
        };
        fetchData();
    }, [toast, isCentral]);

    const productsInSelectedRubro = useMemo(() => {
        if (!selectedRubro) return [];
        return productosList.filter(p => p.Rubro === selectedRubro);
    }, [selectedRubro, productosList]);

    const handleQuantityChange = (productId, quantity) => {
        let parsedQuantity = parseInt(quantity, 10);
        if (isNaN(parsedQuantity) || parsedQuantity < 0) {
            parsedQuantity = parsedQuantity < 0 ? 0 : '';
        }
        setProductQuantities(prev => ({
            ...prev,
            [productId]: parsedQuantity,
        }));
    };

    const handleAddProductsToOrder = () => {
        const newItems = { ...orderItems };
        let itemsAdded = 0;

        productsInSelectedRubro.forEach(product => {
            const quantity = productQuantities[product.id];
            if (quantity > 0) {
                newItems[product.id] = {
                    ...product,
                    cantidad: (newItems[product.id]?.cantidad || 0) + quantity,
                };
                itemsAdded++;
            }
        });

        if (itemsAdded > 0) {
            setOrderItems(newItems);
            toast({ title: 'Éxito', description: `${itemsAdded} producto(s) agregados.` });
        } else {
            toast({ variant: 'destructive', title: 'Sin cambios', description: 'Ingrese una cantidad mayor a 0.' });
        }
        
        setProductQuantities({});
        setSelectedRubro('');
    };
    
    const handleRemoveFromOrder = (productId) => {
        const newItems = { ...orderItems };
        delete newItems[productId];
        setOrderItems(newItems);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (!sucursalId) {
            toast({ variant: 'destructive', title: 'Error', description: 'Selecciona una sucursal.' });
            return;
        }

        if (tipoPedido === 'proveedor' && !proveedorId) {
            toast({ variant: 'destructive', title: 'Error', description: 'Selecciona un proveedor para este pedido.' });
            return;
        }

        const validItems = Object.values(orderItems).filter(item => item.cantidad > 0);
        if (validItems.length === 0) {
            toast({ variant: 'destructive', title: 'Error', description: 'El pedido debe tener al menos un producto.' });
            return;
        }
        
        const productosParaEnviar = validItems.map(({ id, cantidad }) => ({
            producto_id: id,
            cantidad: Number(cantidad)
        }));

        setIsSubmitting(true);
        try {
            const payload = {
                sucursal_id: Number(sucursalId),
                productos: productosParaEnviar,
                usuario_id: user.id,
                tipo_pedido: tipoPedido,
                estado: tipoPedido === 'proveedor' ? 'pendiente_proveedor' : 'pendiente'
            };

            if (tipoPedido === 'proveedor') {
                payload.proveedor_id = Number(proveedorId);
            }

            const { error } = await supabase
                .from('pedidos_centralizada')
                .insert([payload]);

            if (error) throw error;

            toast({ title: 'Pedido Creado', description: 'El pedido se ha registrado correctamente.' });
            
            // Reset form
            if (isCentral) setSucursalId('');
            setOrderItems({});
            setProductQuantities({});
            setSelectedRubro('');
            setProveedorId('');
            
            if (onOrderCreated) onOrderCreated();

        } catch (error) {
            console.error(error);
            toast({ variant: 'destructive', title: 'Error al crear pedido', description: error.message });
        } finally {
            setIsSubmitting(false);
        }
    };
    
    const orderItemsArray = Object.values(orderItems);

    return (
        <Card>
            <form onSubmit={handleSubmit}>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        {tipoPedido === 'interno' ? <Building className="h-6 w-6" /> : <Truck className="h-6 w-6" />}
                        {isCentral ? 'Generar Nuevo Pedido' : 'Solicitar a Central'}
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                    
                    {/* Order Type Selector (Only for Central/Admin) */}
                    {isCentral && (
                        <div className="space-y-3">
                            <Label>Tipo de Pedido</Label>
                            <RadioGroup defaultValue="interno" value={tipoPedido} onValueChange={setTipoPedido} className="flex gap-4">
                                <div className="flex items-center space-x-2 border p-3 rounded-md cursor-pointer hover:bg-muted/50 w-full">
                                    <RadioGroupItem value="interno" id="type-internal" />
                                    <Label htmlFor="type-internal" className="cursor-pointer flex items-center gap-2">
                                        <Building className="h-4 w-4" /> Interno (Central)
                                    </Label>
                                </div>
                                <div className="flex items-center space-x-2 border p-3 rounded-md cursor-pointer hover:bg-muted/50 w-full">
                                    <RadioGroupItem value="proveedor" id="type-supplier" />
                                    <Label htmlFor="type-supplier" className="cursor-pointer flex items-center gap-2">
                                        <Truck className="h-4 w-4" /> A Proveedor
                                    </Label>
                                </div>
                            </RadioGroup>
                        </div>
                    )}

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="sucursal">Sucursal Destino</Label>
                            <Select onValueChange={setSucursalId} value={sucursalId} disabled={loadingBranches || !isCentral}>
                                <SelectTrigger id="sucursal">
                                    <SelectValue placeholder={loadingBranches ? "Cargando..." : "Selecciona sucursal"} />
                                </SelectTrigger>
                                <SelectContent>
                                    {availableBranches.map(branch => (
                                        <SelectItem key={branch.id} value={String(branch.id)}>{branch.nombre}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>

                        {tipoPedido === 'proveedor' && isCentral && (
                            <div className="space-y-2">
                                <Label htmlFor="proveedor">Proveedor</Label>
                                <Select onValueChange={setProveedorId} value={proveedorId}>
                                    <SelectTrigger id="proveedor">
                                        <SelectValue placeholder="Selecciona proveedor" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {proveedores.map(prov => (
                                            <SelectItem key={prov.id} value={String(prov.id)}>{prov.name}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                        )}
                    </div>
                    
                    <div className="space-y-4 pt-4 border-t">
                        <Label htmlFor="rubro">Seleccionar Productos</Label>
                        <Select onValueChange={setSelectedRubro} value={selectedRubro} disabled={loadingData}>
                            <SelectTrigger id="rubro">
                                <SelectValue placeholder={loadingData ? "Cargando productos..." : "Filtrar por Rubro"} />
                            </SelectTrigger>
                            <SelectContent className="max-h-60 overflow-y-auto">
                                {rubros.map(rubro => (
                                    <SelectItem key={rubro} value={rubro}>{rubro}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    <AnimatePresence>
                    {selectedRubro && (
                        <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="space-y-3 border p-4 rounded-md bg-muted/50"
                        >
                            <h3 className="font-semibold text-sm uppercase text-muted-foreground mb-2">{selectedRubro}</h3>
                            {productsInSelectedRubro.map(product => (
                                <div key={product.id} className="flex items-center gap-3">
                                    <Label htmlFor={`prod-${product.id}`} className="flex-1 text-sm font-medium">{product.nombre}</Label>
                                    <div className="flex items-center">
                                        <Input
                                            id={`prod-${product.id}`}
                                            type="number"
                                            min="0"
                                            placeholder="0"
                                            value={productQuantities[product.id] || ''}
                                            onChange={(e) => handleQuantityChange(product.id, e.target.value)}
                                            className="w-20 h-8 rounded-r-none text-right" 
                                        />
                                        <div className="bg-background text-muted-foreground text-xs px-2 h-8 flex items-center border border-l-0 rounded-r-md min-w-[3rem] justify-center">
                                            {product.unidad_medida || 'Unid.'}
                                        </div>
                                    </div>
                                </div>
                            ))}
                            <Button type="button" size="sm" onClick={handleAddProductsToOrder} className="mt-2 w-full">
                                <PlusCircle className="mr-2 h-4 w-4" />
                                Agregar Items Seleccionados
                            </Button>
                        </motion.div>
                    )}
                    </AnimatePresence>

                    {orderItemsArray.length > 0 && (
                        <div className="space-y-4 pt-4 border-t">
                            <h3 className="font-semibold text-lg flex items-center gap-2"><ShoppingCart className="h-5 w-5 text-primary" /> Resumen del Pedido</h3>
                            <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
                                {orderItemsArray.map(item => (
                                    <motion.div
                                        key={item.id}
                                        layout
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        className="flex justify-between items-center p-3 bg-background rounded-md border shadow-sm"
                                    >
                                        <div>
                                            <p className="font-medium text-sm">{item.nombre}</p>
                                            <p className="text-xs text-muted-foreground">
                                                Cant: <span className="font-bold text-foreground">{item.cantidad}</span> {item.unidad_medida}
                                            </p>
                                        </div>
                                        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:bg-destructive/10" onClick={() => handleRemoveFromOrder(item.id)}>
                                            <XCircle className="h-5 w-5" />
                                        </Button>
                                    </motion.div>
                                ))}
                            </div>
                        </div>
                    )}

                </CardContent>
                <CardFooter>
                    <Button type="submit" className="w-full" disabled={isSubmitting || orderItemsArray.length === 0}>
                        {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : (tipoPedido === 'proveedor' ? <Truck className="mr-2 h-4 w-4" /> : <Building className="mr-2 h-4 w-4" />)}
                        {isSubmitting ? 'Procesando...' : (tipoPedido === 'proveedor' ? 'Crear Pedido a Proveedor' : 'Crear Pedido Interno')}
                    </Button>
                </CardFooter>
            </form>
        </Card>
    );
};

export default NewOrderForm;