import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const getStatusInfo = (status) => {
  switch (status) {
    case 'pendiente':
      return { text: 'Pendiente', variant: 'destructive' };
    case 'gestionado':
      return { text: 'Gestionado', variant: 'default' };
    default:
      return { text: status, variant: 'secondary' };
  }
};

const PlacedOrdersDialog = ({ 
    isOpen, 
    onClose, 
    productosMap,
    filterStatus = 'all',
    filterBranch = 'all'
}) => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { userProfile } = useAuth();

  const fetchPlacedOrders = useCallback(async () => {
    if (!userProfile?.sucursal_id) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('pedidos_centralizada')
        .select('*')
        .eq('sucursal_id', userProfile.sucursal_id)
        .in('estado', ['pendiente', 'gestionado'])
        .neq('estado', 'cerrado')
        .neq('estado', 'cerrado_proveedor')
        .order('fecha_pedido', { ascending: false });

      if (error) throw error;
      setOrders(data || []);
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: `No se pudieron cargar los pedidos realizados: ${error.message}`,
      });
    } finally {
      setLoading(false);
    }
  }, [userProfile?.sucursal_id, toast]);

  useEffect(() => {
    if (isOpen) fetchPlacedOrders();
  }, [isOpen, fetchPlacedOrders]);

  const filteredOrders = useMemo(() => {
    return orders.filter(order => {
        const matchesStatus = filterStatus === 'all' || order.estado === filterStatus;
        // Branch filter is technically redundant if the fetch is already scoped to the user's branch, 
        // but robust if 'all' or explicit ID matches.
        const matchesBranch = filterBranch === 'all' || (order.sucursal_id && order.sucursal_id.toString() === filterBranch);
        return matchesStatus && matchesBranch;
    });
  }, [orders, filterStatus, filterBranch]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-3xl w-[95vw] max-h-[85vh] flex flex-col p-0">
        <DialogHeader className="px-6 pt-6 pb-4 flex-shrink-0">
          <DialogTitle>Pedidos Realizados Pendientes</DialogTitle>
          <DialogDescription>
            Estos son los pedidos de tu sucursal que están esperando ser gestionados por la central.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-auto px-6">
          {loading ? (
            <div className="flex items-center justify-center h-full min-h-[200px]">
              <Loader2 className="h-8 w-8 animate-spin" />
            </div>
          ) : filteredOrders.length === 0 ? (
            <p className="text-center text-muted-foreground py-10">
                {orders.length > 0 ? "No hay pedidos que coincidan con los filtros." : "No hay pedidos pendientes."}
            </p>
          ) : (
            <div className="space-y-4 pb-6">
              {filteredOrders.map((order) => {
                const statusInfo = getStatusInfo(order.estado);
                return (
                  <div key={order.id} className="p-4 border rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <p className="font-semibold">
                        Fecha: {new Date(order.fecha_pedido).toLocaleDateString()}
                      </p>
                      <Badge variant={statusInfo.variant}>{statusInfo.text}</Badge>
                    </div>

                    <ul className="list-disc list-inside text-sm space-y-1 pl-2">
                      {order.productos.map((p, index) => (
                        <li key={`${p.producto_id}-${index}`}>
                          <span className="font-medium">
                            {productosMap[p.producto_id]?.nombre || 'N/A'}
                          </span>
                          :&nbsp;{p.cantidad} {productosMap[p.producto_id]?.unidad_medida || ''}
                          {order.estado === 'gestionado' && p.cantidad_enviada !== undefined && (
                            <span className="text-blue-400 ml-2">(A enviar: {p.cantidad_enviada})</span>
                          )}
                        </li>
                      ))}
                    </ul>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <DialogFooter className="px-6 py-4 flex-shrink-0 border-t">
          <Button type="button" variant="outline" onClick={onClose}>
            Cerrar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default PlacedOrdersDialog;