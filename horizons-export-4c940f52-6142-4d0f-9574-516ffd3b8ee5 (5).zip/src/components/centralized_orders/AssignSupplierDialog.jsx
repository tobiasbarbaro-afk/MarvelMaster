import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2 } from 'lucide-react';
import { checkFaltantesForPedido, resolveFaltantesForPedido } from '@/lib/orderConstraintHelper';
import { updateInternalOrderAfterProviderAssignment } from '@/lib/internalOrderHelper';

const AssignSupplierDialog = ({ isOpen, onClose, originalOrder, productsToAssign, productosMap, onAssignmentComplete }) => {
    const { toast } = useToast();
    const { user } = useAuth();
    const [suppliers, setSuppliers] = useState([]);
    const [loadingSuppliers, setLoadingSuppliers] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [productSuppliers, setProductSuppliers] = useState({});

    useEffect(() => {
        const fetchSuppliers = async () => {
            setLoadingSuppliers(true);
            const { data, error } = await supabase.from('suppliers').select('id, name');
            if (error) {
                toast({ variant: 'destructive', title: 'Error', description: 'No se pudieron cargar los proveedores.' });
            } else {
                setSuppliers(data);
            }
            setLoadingSuppliers(false);
        };
        if (isOpen) {
            fetchSuppliers();
            setProductSuppliers({});
        }
    }, [isOpen, toast]);

    const handleSupplierChange = (productId, supplierId) => {
        setProductSuppliers(prev => ({ ...prev, [productId]: supplierId }));
    };

    const handleSubmit = async () => {
        setIsSubmitting(true);

        const assignedProducts = productsToAssign.filter(p => productSuppliers[p.producto_id]);
        if (assignedProducts.length === 0) {
            toast({ variant: 'destructive', title: 'Error', description: 'Debe asignar al menos un proveedor.' });
            setIsSubmitting(false);
            return;
        }

        try {
            // Group new products by supplier
            const supplierGroups = {};
            assignedProducts.forEach(product => {
                const supplierId = productSuppliers[product.producto_id];
                if (!supplierGroups[supplierId]) {
                    supplierGroups[supplierId] = [];
                }
                
                const finalQuantity = product.cantidad_gestionada !== undefined && product.cantidad_gestionada !== null 
                    ? parseFloat(product.cantidad_gestionada) 
                    : parseFloat(product.cantidad);

                supplierGroups[supplierId].push({
                    producto_id: product.producto_id,
                    cantidad: finalQuantity,
                    cantidad_enviada: 0,
                });
            });

            // Create/Merge Provider Orders
            for (const [supplierIdStr, newProducts] of Object.entries(supplierGroups)) {
                const supplierId = parseInt(supplierIdStr);

                const { data: existingOrders, error: fetchError } = await supabase
                    .from('pedidos_centralizada')
                    .select('id, productos')
                    .eq('sucursal_id', originalOrder.sucursal_id)
                    .eq('proveedor_id', supplierId)
                    .eq('tipo_pedido', 'proveedor')
                    .eq('estado', 'pendiente_proveedor')
                    .limit(1);

                if (fetchError) throw fetchError;

                const existingOrder = existingOrders && existingOrders.length > 0 ? existingOrders[0] : null;

                if (existingOrder) {
                    const currentProducts = existingOrder.productos || [];
                    const mergedProducts = [...currentProducts];

                    newProducts.forEach(newP => {
                        const existingProductIndex = mergedProducts.findIndex(p => p.producto_id === newP.producto_id);
                        if (existingProductIndex >= 0) {
                            mergedProducts[existingProductIndex].cantidad += newP.cantidad;
                        } else {
                            mergedProducts.push(newP);
                        }
                    });

                    const { error: updateError } = await supabase
                        .from('pedidos_centralizada')
                        .update({ productos: mergedProducts })
                        .eq('id', existingOrder.id);

                    if (updateError) throw updateError;
                } else {
                    const { error: insertError } = await supabase
                        .from('pedidos_centralizada')
                        .insert({
                            sucursal_id: originalOrder.sucursal_id,
                            productos: newProducts,
                            usuario_id: user.id,
                            tipo_pedido: 'proveedor',
                            proveedor_id: supplierId,
                            estado: 'pendiente_proveedor',
                        });
                    
                    if (insertError) throw insertError;
                }
            }

            // Clean up original internal order using the helper
            const { hasFaltantes } = await checkFaltantesForPedido(originalOrder.id);
            if (hasFaltantes) {
                await resolveFaltantesForPedido(originalOrder.id);
            }

            const assignedProductIds = assignedProducts.map(p => p.producto_id);
            const result = await updateInternalOrderAfterProviderAssignment(originalOrder.id, assignedProductIds);

            if (!result.success) {
                throw new Error(result.error);
            }

            if (result.deleted) {
                toast({ title: 'Éxito', description: 'Pedido interno eliminado (100% asignado a proveedores).' });
            } else {
                toast({ title: 'Éxito', description: `Pedido interno actualizado con ${result.remainingCount} items restantes.` });
            }

            onAssignmentComplete(assignedProductIds);

        } catch (error) {
            console.error('Error in AssignSupplierDialog:', error);
            if (error.code === '23503') {
                 toast({ variant: 'destructive', title: 'Error de Integridad', description: 'No se pudo eliminar el pedido original porque tiene registros dependientes.' });
            } else {
                 toast({ variant: 'destructive', title: 'Error', description: `Ocurrió un error al procesar la solicitud: ${error.message}` });
            }
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-xl">
                <DialogHeader>
                    <DialogTitle>Asignar Proveedores</DialogTitle>
                    <DialogDescription>
                        Selecciona un proveedor para cada producto. La cantidad mostrada es la que ingresaste manualmente.
                    </DialogDescription>
                </DialogHeader>

                <div className="py-4 space-y-4 max-h-[60vh] overflow-y-auto">
                    {productsToAssign.map(product => {
                        const displayQuantity = product.cantidad_gestionada !== undefined && product.cantidad_gestionada !== null 
                            ? product.cantidad_gestionada 
                            : product.cantidad;

                        return (
                            <div key={product.producto_id} className="flex items-center justify-between gap-4 p-2 border rounded-md">
                                <div>
                                    <p className="font-medium">{productosMap[product.producto_id]?.nombre}</p>
                                    <p className="text-sm text-muted-foreground">
                                        Cantidad: <strong>{displayQuantity}</strong> {productosMap[product.producto_id]?.unidad_medida}
                                    </p>
                                </div>
                                {loadingSuppliers ? (
                                    <Loader2 className="animate-spin" />
                                ) : (
                                    <Select onValueChange={(value) => handleSupplierChange(product.producto_id, value)}>
                                        <SelectTrigger className="w-[200px]">
                                            <SelectValue placeholder="Seleccionar proveedor" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {suppliers.map(supplier => (
                                                <SelectItem key={supplier.id} value={supplier.id.toString()}>
                                                    {supplier.name}
                                                </SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                )}
                            </div>
                        );
                    })}
                </div>

                <DialogFooter>
                    <Button variant="outline" onClick={onClose} disabled={isSubmitting}>Cancelar</Button>
                    <Button onClick={handleSubmit} disabled={isSubmitting || loadingSuppliers || Object.keys(productSuppliers).length === 0}>
                        {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Confirmar y Dividir
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

export default AssignSupplierDialog;