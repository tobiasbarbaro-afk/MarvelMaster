import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Loader2, Calendar as CalendarIcon, Trash2, PlusCircle, Send, CheckCircle2, RefreshCw } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogTrigger, AlertDialogFooter } from '@/components/ui/alert-dialog';
import AddToExistingOrderDialog from './AddToExistingOrderDialog';

const ITEMS_PER_PAGE = 50;

const MissingItemsDialog = ({ 
    isOpen, 
    onClose, 
    sucursales, 
    onMissingItemsUpdate,
    filterStatus = 'all',
    filterBranch = 'all'
}) => {
    const { userRole, userProfile } = useAuth();
    const { toast } = useToast();
    const [loading, setLoading] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);
    const [missingItems, setMissingItems] = useState([]);
    const [page, setPage] = useState(1);
    const [totalCount, setTotalCount] = useState(0);
    const [selectedItems, setSelectedItems] = useState(new Set());
    const [actionTarget, setActionTarget] = useState(null);
    const [isAddToOrderOpen, setIsAddToOrderOpen] = useState(false);
    
    // Transaction & Order Generation States
    const [isGenerateOrderOpen, setIsGenerateOrderOpen] = useState(false);
    const [orderType, setOrderType] = useState('interno');
    const [selectedSupplierId, setSelectedSupplierId] = useState('none');
    const [suppliers, setSuppliers] = useState([]);
    const [isProcessingOrder, setIsProcessingOrder] = useState(false);
    const [processingStep, setProcessingStep] = useState(''); // Feedback text

    const [filters, setFilters] = useState({
        sucursal_id: 'all',
        date_from: null,
        date_to: null,
    });
    
    // Sync internal filters with global props
    useEffect(() => {
        if (filterBranch !== 'all') {
            setFilters(prev => ({ ...prev, sucursal_id: filterBranch }));
        }
    }, [filterBranch]);

    const canManage = ['admin', 'centralizada', 'gerente'].includes(userRole);
    const canDelete = ['admin', 'gerente', 'centralizada'].includes(userRole);

    const fetchSuppliers = useCallback(async () => {
        const { data } = await supabase.from('suppliers').select('id, name').order('name');
        setSuppliers(data || []);
    }, []);

    const fetchMissingItemsWithRetry = useCallback(async () => {
        setLoading(true);
        let retries = 3;
        let delay = 1000;

        while (retries > 0) {
            try {
                const from = (page - 1) * ITEMS_PER_PAGE;
                const to = from + ITEMS_PER_PAGE - 1;

                let query = supabase
                    .from('faltantes_centralizada')
                    .select('*, sucursales(id, nombre), productos_centralizada(id, nombre, unidad_medida, unidad_medida_stock)', { count: 'exact' })
                    .eq('estado', 'pendiente')
                    .order('fecha_pedido', { ascending: true })
                    .range(from, to);

                if (['gerente', 'empleado'].includes(userRole) && userProfile?.sucursal_id) {
                    query = query.eq('sucursal_id', userProfile.sucursal_id);
                } else if (filters.sucursal_id !== 'all') {
                    query = query.eq('sucursal_id', filters.sucursal_id);
                }

                if (filters.date_from) {
                    query = query.gte('fecha_pedido', format(filters.date_from, 'yyyy-MM-dd'));
                }
                if (filters.date_to) {
                    query = query.lte('fecha_pedido', format(filters.date_to, 'yyyy-MM-dd'));
                }

                const { data, error, count } = await query;
                if (error) throw error;

                setMissingItems(data || []);
                setTotalCount(count || 0);
                setLoading(false);
                return; // Success, exit loop
            } catch (error) {
                console.warn(`Fetch attempt failed. Retries left: ${retries - 1}`, error);
                retries--;
                if (retries === 0) {
                    toast({ variant: 'destructive', title: 'Error de Conexión', description: `No se pudo cargar el listado de faltantes tras varios intentos: ${error.message}` });
                    setLoading(false);
                } else {
                    await new Promise(resolve => setTimeout(resolve, delay));
                    delay *= 2; // Exponential backoff
                }
            }
        }
    }, [userRole, userProfile, toast, filters, page]);

    // Initial fetch only on mount or filter/page change
    useEffect(() => {
        if (isOpen) {
            if (['gerente', 'empleado'].includes(userRole) && userProfile?.sucursal_id) {
                 setFilters(prev => prev.sucursal_id === userProfile.sucursal_id.toString() ? prev : ({ ...prev, sucursal_id: userProfile.sucursal_id.toString() }));
            }
            fetchSuppliers();
            fetchMissingItemsWithRetry();
        }
    }, [isOpen, fetchMissingItemsWithRetry, fetchSuppliers]); 

    const handleFilterChange = (key, value) => {
        setFilters(prev => {
            const newFilters = { ...prev, [key]: value };
            setPage(1);
            return newFilters;
        });
    };

    const handleSelectItem = (itemId) => {
        setSelectedItems(prev => {
            const newSet = new Set(prev);
            if (newSet.has(itemId)) {
                newSet.delete(itemId);
            } else {
                newSet.add(itemId);
            }
            return newSet;
        });
    };

    const handleDelete = async () => {
        const itemsToDelete = Array.from(selectedItems);
        if (itemsToDelete.length === 0) return;

        setIsDeleting(true);
        try {
            const { error } = await supabase
                .from('faltantes_centralizada')
                .delete()
                .in('id', itemsToDelete);
            
            if (error) throw error;

            toast({ title: 'Éxito', description: `${itemsToDelete.length} faltante(s) eliminado(s) permanentemente.` });
            setSelectedItems(new Set());
            fetchMissingItemsWithRetry();
            onMissingItemsUpdate();
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: `No se pudo eliminar: ${error.message}` });
        } finally {
            setIsDeleting(false);
        }
    };

    // --- Helper Functions for Transaction Management ---
    const deleteCreatedPedido = async (pedidoId) => {
        console.log(`[Rollback] Eliminando pedido huérfano: ${pedidoId}`);
        const { error } = await supabase
            .from('pedidos_centralizada')
            .delete()
            .eq('id', pedidoId);
        
        if (error) {
            console.error('[Rollback] Error CRÍTICO: No se pudo eliminar el pedido huérfano:', error);
        } else {
            console.log(`[Rollback] Pedido ${pedidoId} eliminado exitosamente.`);
        }
    };

    const revertFaltantesChanges = async (originalState) => {
        console.log(`[Rollback] Revertiendo ${originalState.length} items a su estado original...`);
        let failureCount = 0;
        
        for (const item of originalState) {
            try {
                const { error } = await supabase
                    .from('faltantes_centralizada')
                    .update({ pedido_id: item.pedido_id, estado: 'pendiente' })
                    .eq('id', item.id);
                
                if (error) {
                    console.error(`[Rollback] Failed to revert item ${item.id}:`, error);
                    failureCount++;
                }
            } catch (err) {
                 console.error(`[Rollback] Exception reverting item ${item.id}:`, err);
                 failureCount++;
            }
        }
        
        if (failureCount > 0) {
            throw new Error(`Falló la reversión de ${failureCount} items. Integridad comprometida.`);
        }
    };

    const openGenerateOrderDialog = () => {
        if (selectedItems.size === 0) {
            toast({ variant: 'destructive', title: 'Error', description: 'Selecciona al menos un faltante.' });
            return;
        }

        const itemsToProcess = missingItems.filter(item => selectedItems.has(item.id));
        const sucursalId = itemsToProcess[0].sucursal_id;

        if (!itemsToProcess.every(item => item.sucursal_id === sucursalId)) {
            toast({ variant: 'destructive', title: 'Error', description: 'Todos los faltantes seleccionados deben ser de la misma sucursal.' });
            return;
        }
        
        setSelectedSupplierId('none');
        setOrderType('interno');
        setIsGenerateOrderOpen(true);
    };

    const handleConfirmGenerateOrder = async () => {
        if (selectedItems.size === 0) return;

        setIsProcessingOrder(true);
        setProcessingStep('Iniciando transacción...');

        const itemsToProcess = missingItems.filter(item => selectedItems.has(item.id));
        const sucursalId = itemsToProcess[0].sucursal_id;
        let newOrderId = null;
        let updatesApplied = false;
        
        const originalItemsState = itemsToProcess.map(item => ({ 
            id: item.id, 
            pedido_id: item.pedido_id,
            estado: item.estado 
        }));

        try {
            setProcessingStep('Creando pedido...');
            
            const isProvider = orderType === 'proveedor';
            
            const orderPayload = {
                sucursal_id: sucursalId,
                productos: itemsToProcess.map(item => ({
                    producto_id: item.producto_id,
                    cantidad: item.cantidad_faltante,
                })),
                estado: isProvider ? 'pendiente_proveedor' : 'pendiente',
                fecha_pedido: new Date().toISOString(),
                tipo_pedido: isProvider ? 'proveedor' : 'interno',
                observaciones: `Generado desde faltantes (${itemsToProcess.length} items)`,
                usuario_id: userProfile?.id,
                proveedor_id: null
            };

            if (isProvider && selectedSupplierId && selectedSupplierId !== 'none') {
                setProcessingStep('Asignando proveedor...');
                orderPayload.proveedor_id = parseInt(selectedSupplierId);
            }

            const { data: newOrder, error: createError } = await supabase
                .from('pedidos_centralizada')
                .insert([orderPayload])
                .select('id')
                .single();

            if (createError) throw new Error(`Error al crear el pedido: ${createError.message}`);
            if (!newOrder?.id) throw new Error("No se recibió el ID del nuevo pedido.");
            
            newOrderId = newOrder.id;
            console.log(`[Transaction] Pedido creado: ${newOrderId}`);

            const { data: verifyOrder } = await supabase
                .from('pedidos_centralizada')
                .select('id')
                .eq('id', newOrderId)
                .single();
            
            if (!verifyOrder) throw new Error("Verificación fallida: El pedido no existe tras creación.");

            setProcessingStep('Vinculando items...');
            const { error: updateError } = await supabase
                .from('faltantes_centralizada')
                .update({ estado: 'reasignado', pedido_id: newOrderId })
                .in('id', itemsToProcess.map(i => i.id));

            if (updateError) {
                throw new Error(`Error vinculando faltantes: ${updateError.message}`);
            }
            
            updatesApplied = true;

            setProcessingStep('¡Completado!');
            toast({ title: 'Éxito', description: `Pedido #${newOrderId.slice(0,8)} generado correctamente.` });
            
            setSelectedItems(new Set());
            setIsGenerateOrderOpen(false);
            fetchMissingItemsWithRetry();
            onMissingItemsUpdate();

        } catch (error) {
            console.error('Transaction Failed:', error);
            setProcessingStep('Error - Revirtiendo cambios...');
            
            if (newOrderId) {
                try {
                    if (updatesApplied) {
                        await revertFaltantesChanges(originalItemsState);
                    }
                    await deleteCreatedPedido(newOrderId);
                    
                    toast({ 
                        variant: 'destructive', 
                        title: 'Operación Revertida', 
                        description: `Ocurrió un error y se deshicieron los cambios. Detalle: ${error.message}` 
                    });
                } catch (rollbackError) {
                    console.error('CRITICAL ROLLBACK FAILURE:', rollbackError);
                    toast({ 
                        variant: 'destructive', 
                        title: 'Error Crítico de Integridad', 
                        description: `El sistema no pudo revertir completamente los cambios. Por favor contacte a soporte técnico inmediatamente. Pedido ID: ${newOrderId}` 
                    });
                }
            } else {
                 toast({ variant: 'destructive', title: 'Error', description: error.message });
            }
        } finally {
            setIsProcessingOrder(false);
            setProcessingStep('');
        }
    };

    const openAddToOrderDialog = () => {
        if (selectedItems.size === 0) {
            toast({ variant: 'destructive', title: 'Error', description: 'Selecciona al menos un faltante.' });
            return;
        }
        const itemsToProcess = missingItems.filter(item => selectedItems.has(item.id));
        const sucursalId = itemsToProcess[0].sucursal_id;
        if (!itemsToProcess.every(item => item.sucursal_id === sucursalId)) {
            toast({ variant: 'destructive', title: 'Error', description: 'Todos los faltantes seleccionados deben ser de la misma sucursal.' });
            return;
        }
        setActionTarget(itemsToProcess);
        setIsAddToOrderOpen(true);
    };

    const handleAddedToOrder = () => {
        setIsAddToOrderOpen(false);
        setActionTarget(null);
        setSelectedItems(new Set());
        fetchMissingItemsWithRetry();
        onMissingItemsUpdate();
    };

    const totalPages = Math.ceil(totalCount / ITEMS_PER_PAGE);

    const groupedItems = useMemo(() => {
        return missingItems.reduce((acc, item) => {
            const sucursalName = item.sucursales?.nombre || 'Desconocida';
            if (!acc[sucursalName]) {
                acc[sucursalName] = [];
            }
            acc[sucursalName].push(item);
            return acc;
        }, {});
    }, [missingItems]);

    return (
        <>
            <Dialog open={isOpen} onOpenChange={onClose}>
                <DialogContent className="max-w-6xl h-[90vh] flex flex-col">
                    <DialogHeader>
                        <DialogTitle>Gestión de Faltantes</DialogTitle>
                        <DialogDescription>Visualiza y gestiona los productos faltantes de los pedidos.</DialogDescription>
                    </DialogHeader>
                    
                    <div className="p-4 flex-shrink-0 bg-muted/50 rounded-lg my-4 space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                            {['admin', 'centralizada'].includes(userRole) && (
                                <div>
                                    <Label htmlFor="sucursal-filter-missing">Sucursal</Label>
                                    <Select value={filters.sucursal_id} onValueChange={(v) => handleFilterChange('sucursal_id', v)}>
                                        <SelectTrigger id="sucursal-filter-missing">
                                            <SelectValue placeholder="Seleccionar sucursal" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="all">Todas las sucursales</SelectItem>
                                            {sucursales.map(s => <SelectItem key={s.id} value={s.id.toString()}>{s.nombre}</SelectItem>)}
                                        </SelectContent>
                                    </Select>
                                </div>
                            )}
                            <div>
                                <Label htmlFor="date-from-missing">Desde</Label>
                                <Popover>
                                    <PopoverTrigger asChild>
                                        <Button id="date-from-missing" variant="outline" className={cn("w-full justify-start text-left font-normal", !filters.date_from && "text-muted-foreground")}>
                                            <CalendarIcon className="mr-2 h-4 w-4" />
                                            {filters.date_from ? format(filters.date_from, "PPP", { locale: es }) : <span>Fecha de Pedido</span>}
                                        </Button>
                                    </PopoverTrigger>
                                    <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={filters.date_from} onSelect={(d) => handleFilterChange('date_from', d)} initialFocus /></PopoverContent>
                                </Popover>
                            </div>
                            <div className="flex gap-2">
                                <div className="flex-1">
                                    <Label htmlFor="date-to-missing">Hasta</Label>
                                    <Popover>
                                        <PopoverTrigger asChild>
                                            <Button id="date-to-missing" variant="outline" className={cn("w-full justify-start text-left font-normal", !filters.date_to && "text-muted-foreground")}>
                                                <CalendarIcon className="mr-2 h-4 w-4" />
                                                {filters.date_to ? format(filters.date_to, "PPP", { locale: es }) : <span>Fecha de Pedido</span>}
                                            </Button>
                                        </PopoverTrigger>
                                        <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={filters.date_to} onSelect={(d) => handleFilterChange('date_to', d)} initialFocus /></PopoverContent>
                                    </Popover>
                                </div>
                                <div className="flex items-end">
                                     <Button variant="ghost" size="icon" onClick={() => fetchMissingItemsWithRetry()} title="Recargar lista">
                                         <RefreshCw className={cn("h-4 w-4", loading && "animate-spin")} />
                                     </Button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="flex-grow overflow-y-auto pr-2 space-y-4">
                        {loading ? (
                            <div className="flex flex-col justify-center items-center h-full gap-2">
                                <Loader2 className="h-8 w-8 animate-spin" />
                                <p className="text-sm text-muted-foreground">Cargando faltantes...</p>
                            </div>
                        ) : Object.keys(groupedItems).length === 0 ? (
                            <p className="text-center text-muted-foreground py-8">No hay faltantes pendientes que coincidan con los filtros.</p>
                        ) : (
                            Object.entries(groupedItems).map(([sucursalName, items]) => (
                                <Card key={sucursalName}>
                                    <CardHeader className="py-3 bg-muted/20"><CardTitle className="text-base">{sucursalName}</CardTitle></CardHeader>
                                    <CardContent className="space-y-2 p-3">
                                        {items.map(item => (
                                            <div key={item.id} className={cn("flex items-center justify-between p-2 border rounded-md transition-colors hover:bg-muted/30", selectedItems.has(item.id) && "bg-primary/10 border-primary")}>
                                                <div className="flex items-center gap-4">
                                                    {canManage && (
                                                        <input type="checkbox" checked={selectedItems.has(item.id)} onChange={() => handleSelectItem(item.id)} className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary" />
                                                    )}
                                                    <div>
                                                        <p className="font-semibold text-sm">
                                                            {item.productos_centralizada?.nombre || 'Producto Desconocido'} 
                                                            <span className="text-muted-foreground font-normal ml-2">
                                                                ({item.cantidad_faltante} {item.productos_centralizada?.unidad_medida || 'u'})
                                                            </span>
                                                        </p>
                                                        <p className="text-xs text-muted-foreground">Pedido del: {format(new Date(item.fecha_pedido), 'dd/MM/yyyy')}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </CardContent>
                                </Card>
                            ))
                        )}
                    </div>

                    <div className="flex-shrink-0 pt-4 flex flex-col sm:flex-row justify-between items-center gap-4 border-t mt-2">
                        <div className="flex items-center gap-2">
                            <Button variant="outline" size="sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1 || loading}>Anterior</Button>
                            <span className="text-xs text-muted-foreground">Página {page} de {totalPages || 1}</span>
                            <Button variant="outline" size="sm" onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages || loading}>Siguiente</Button>
                        </div>
                        {canManage && (
                            <div className="flex items-center gap-2 flex-wrap justify-end">
                                {canDelete && (
                                    <AlertDialog>
                                        <AlertDialogTrigger asChild>
                                            <Button variant="destructive" size="sm" disabled={selectedItems.size === 0 || isDeleting}>
                                                {isDeleting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Trash2 className="mr-2 h-4 w-4" />}
                                                Eliminar ({selectedItems.size})
                                            </Button>
                                        </AlertDialogTrigger>
                                        <AlertDialogContent>
                                            <AlertDialogHeader>
                                                <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
                                                <AlertDialogDescription>
                                                    Esta acción eliminará PERMANENTEMENTE {selectedItems.size} faltante(s) de la base de datos.
                                                </AlertDialogDescription>
                                            </AlertDialogHeader>
                                            <AlertDialogFooter>
                                                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                                <AlertDialogAction onClick={handleDelete} disabled={isDeleting}>
                                                    {isDeleting ? "Eliminando..." : "Confirmar"}
                                                </AlertDialogAction>
                                            </AlertDialogFooter>
                                        </AlertDialogContent>
                                    </AlertDialog>
                                )}
                                <Button size="sm" onClick={openAddToOrderDialog} disabled={selectedItems.size === 0} variant="outline">
                                    <PlusCircle className="mr-2 h-4 w-4" /> Agregar a Pedido ({selectedItems.size})
                                </Button>
                                <Button size="sm" onClick={openGenerateOrderDialog} disabled={selectedItems.size === 0}>
                                    <Send className="mr-2 h-4 w-4" /> Generar Pedido ({selectedItems.size})
                                </Button>
                            </div>
                        )}
                    </div>
                </DialogContent>
            </Dialog>

            {/* Confirmation Dialog for New Order */}
            <Dialog open={isGenerateOrderOpen} onOpenChange={setIsGenerateOrderOpen}>
                <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                        <DialogTitle>Generar Nuevo Pedido</DialogTitle>
                        <DialogDescription>
                            Se creará un nuevo pedido con los {selectedItems.size} items seleccionados.
                        </DialogDescription>
                    </DialogHeader>
                    
                    <div className="space-y-6 py-4">
                        <div className="space-y-3">
                            <Label>Tipo de Pedido</Label>
                            <RadioGroup 
                                value={orderType} 
                                onValueChange={setOrderType} 
                                className="flex flex-col sm:flex-row gap-4"
                                disabled={isProcessingOrder}
                            >
                                <div className="flex items-center space-x-2 border p-3 rounded-md cursor-pointer hover:bg-muted/50 transition-colors w-full">
                                    <RadioGroupItem value="interno" id="t-interno" />
                                    <Label htmlFor="t-interno" className="cursor-pointer w-full">Interno (Central)</Label>
                                </div>
                                <div className="flex items-center space-x-2 border p-3 rounded-md cursor-pointer hover:bg-muted/50 transition-colors w-full">
                                    <RadioGroupItem value="proveedor" id="t-proveedor" />
                                    <Label htmlFor="t-proveedor" className="cursor-pointer w-full">A Proveedor</Label>
                                </div>
                            </RadioGroup>
                        </div>

                        {orderType === 'proveedor' && (
                            <div className="space-y-2 animate-in fade-in slide-in-from-top-2">
                                <Label htmlFor="supplier-select">Asignar Proveedor (Opcional)</Label>
                                <Select value={selectedSupplierId} onValueChange={setSelectedSupplierId} disabled={isProcessingOrder}>
                                    <SelectTrigger id="supplier-select">
                                        <SelectValue placeholder="Seleccionar proveedor..." />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="none">-- Sin proveedor (Pendiente) --</SelectItem>
                                        {suppliers.map(sup => (
                                            <SelectItem key={sup.id} value={sup.id.toString()}>{sup.name}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                                <p className="text-xs text-muted-foreground">
                                    Si seleccionas un proveedor, el pedido se creará ya asignado.
                                </p>
                            </div>
                        )}
                        
                        {isProcessingOrder && (
                            <div className="flex items-center gap-2 p-3 bg-muted rounded-md text-sm text-blue-600">
                                <Loader2 className="h-4 w-4 animate-spin" />
                                <span>{processingStep}</span>
                            </div>
                        )}
                    </div>

                    <DialogFooter className="sm:justify-between">
                        <Button variant="outline" onClick={() => setIsGenerateOrderOpen(false)} disabled={isProcessingOrder}>
                            Cancelar
                        </Button>
                        <Button onClick={handleConfirmGenerateOrder} disabled={isProcessingOrder}>
                            {isProcessingOrder ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CheckCircle2 className="mr-2 h-4 w-4" />}
                            Confirmar Generación
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {isAddToOrderOpen && actionTarget && (
                <AddToExistingOrderDialog
                    isOpen={isAddToOrderOpen}
                    onClose={() => setIsAddToOrderOpen(false)}
                    missingItems={actionTarget}
                    onSuccess={handleAddedToOrder}
                />
            )}
        </>
    );
};

export default MissingItemsDialog;