import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FileText, PackageOpen, CheckCircle, Edit, Send, AlertCircle, Download, UploadCloud, Loader2, MessageSquare as MessageSquareWarning, RefreshCw, Truck, Building } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

const OrderCard = ({ order, productosMap, onManage, onUploadSigned, onGenerateAndConfirm, onConfirmFinal, onAddReturn, onModify, isProcessing }) => {
    const { userRole } = useAuth();

    const getStatusInfo = (status) => {
        const baseClasses = 'px-2 py-1 text-xs font-medium rounded-full inline-flex items-center gap-1.5';
        switch (status) {
            case 'pendiente':
                return { text: 'Pendiente', className: `${baseClasses} bg-yellow-500/20 text-yellow-400` };
            case 'pendiente_proveedor':
                return { text: 'Pendiente Proveedor', className: `${baseClasses} bg-orange-500/20 text-orange-500` };
            case 'orden_generada':
                return { text: 'OC Generada', className: `${baseClasses} bg-blue-500/20 text-blue-400` };
            case 'factura_cargada':
                return { text: 'Factura Cargada', className: `${baseClasses} bg-indigo-500/20 text-indigo-400` };
            case 'gestionado':
                return { text: 'Gestionado', className: `${baseClasses} bg-blue-500/20 text-blue-400` };
            case 'confirmado':
                 if (userRole === 'centralizada') {
                    return { text: 'Confirmado a sucursal', className: `${baseClasses} bg-gray-500/20 text-gray-400` };
                }
                return { text: 'Confirmado', className: `${baseClasses} bg-teal-500/20 text-teal-400` };
            case 'firma_pendiente':
                return { text: 'Firma Pendiente', className: `${baseClasses} bg-purple-500/20 text-purple-400` };
            case 'cerrado':
                return { text: 'Cerrado', className: `${baseClasses} bg-green-500/20 text-green-400` };
            case 'cerrado_proveedor':
                return { text: 'Cerrado Proveedor', className: `${baseClasses} bg-green-500/20 text-green-400` };
            default:
                return { text: status, className: `${baseClasses} bg-gray-500/20 text-gray-400` };
        }
    };

    const statusInfo = getStatusInfo(order.estado);
    const sucursalVisibleStatuses = ['confirmado', 'firma_pendiente'];
    const canModify = ['admin', 'centralizada', 'gerente'].includes(userRole);
    const isProviderOrder = order.tipo_pedido === 'proveedor' || order.tipo_pedido === 'a_proveedor';

    const renderSucursalActions = () => {
        if (order.estado === 'confirmado' && order.remito_pdf_url) {
            return (
                <div className="flex flex-col sm:flex-row gap-2 flex-wrap justify-end">
                    <Button asChild variant="secondary" size="sm">
                        <a href={order.remito_pdf_url} target="_blank" rel="noopener noreferrer">
                            <Download className="mr-2 h-4 w-4" />
                            Descargar Remito
                        </a>
                    </Button>
                    {userRole === 'gerente' && (
                        <>
                             <Button variant="outline" size="sm" onClick={() => onAddReturn(order)}>
                                <RefreshCw className="mr-2 h-4 w-4" />
                                Agregar Devolución
                            </Button>
                            <Button variant="default" size="sm" onClick={() => onUploadSigned(order)} className="bg-yellow-500 hover:bg-yellow-600 text-black">
                                <UploadCloud className="mr-2 h-4 w-4" />
                                Cargar Remito Firmado
                            </Button>
                        </>
                    )}
                     {!['gerente'].includes(userRole) && (
                        <>
                             <Button variant="outline" size="sm" onClick={() => onAddReturn(order)}>
                                <RefreshCw className="mr-2 h-4 w-4" />
                                Agregar Devolución
                            </Button>
                            <Button variant="default" size="sm" onClick={() => onUploadSigned(order)}>
                                <UploadCloud className="mr-2 h-4 w-4" />
                                Cargar Remito Firmado
                            </Button>
                        </>
                     )}
                </div>
            );
        }
        if (order.estado === 'firma_pendiente' && order.remito_firmado_url) {
             return (
                 <Button asChild variant="secondary" size="sm">
                    <a href={order.remito_firmado_url} target="_blank" rel="noopener noreferrer">
                        <FileText className="mr-2 h-4 w-4" />
                        Ver Remito Firmado
                    </a>
                </Button>
             );
        }
        return null;
    };
    
    const renderCentralActions = () => {
        switch (order.estado) {
            case 'pendiente':
            case 'pendiente_proveedor':
                return (
                    <Button variant="outline" size="sm" onClick={() => onManage(order)}>
                        <PackageOpen className="mr-2 h-4 w-4" />
                        Gestionar
                    </Button>
                );
            case 'gestionado':
                return (
                    <div className="flex flex-col sm:flex-row gap-2">
                        <Button variant="outline" size="sm" onClick={() => onManage(order)}>
                            <Edit className="mr-2 h-4 w-4" />
                            Editar Envío
                        </Button>
                        <Button variant="default" size="sm" onClick={() => onGenerateAndConfirm(order.id)} disabled={isProcessing}>
                            {isProcessing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
                            Generar Remito y Confirmar
                        </Button>
                    </div>
                );
             case 'firma_pendiente':
                return (
                    <div className="flex flex-col sm:flex-row gap-2">
                         <Button asChild variant="secondary" size="sm">
                            <a href={order.remito_firmado_url} target="_blank" rel="noopener noreferrer">
                                <FileText className="mr-2 h-4 w-4" />
                                Ver Firmado
                            </a>
                        </Button>
                        <Button variant="default" size="sm" onClick={() => onConfirmFinal(order.id)}>
                            <CheckCircle className="mr-2 h-4 w-4" />
                            Confirmar y Cerrar
                        </Button>
                    </div>
                );
            case 'confirmado':
                if (canModify && order.remito_pdf_url) {
                    return (
                        <div className="flex flex-col sm:flex-row gap-2 flex-wrap justify-end">
                            <Button asChild variant="secondary" size="sm">
                                <a href={order.remito_pdf_url} target="_blank" rel="noopener noreferrer">
                                    <Download className="mr-2 h-4 w-4" />
                                    Descargar Remito
                                </a>
                            </Button>
                             {order.devolucion_url && (
                                <Button asChild variant="outline" size="sm">
                                    <a href={order.devolucion_url} target="_blank" rel="noopener noreferrer">
                                        <RefreshCw className="mr-2 h-4 w-4" /> Ver Devolución
                                    </a>
                                </Button>
                            )}
                            
                            {userRole !== 'gerente' && (
                                <Button variant="outline" size="sm" onClick={() => onModify(order)}>
                                    <Edit className="mr-2 h-4 w-4" />
                                    Modificar
                                </Button>
                            )}

                             {userRole === 'gerente' && (
                                <>
                                     <Button variant="outline" size="sm" onClick={() => onAddReturn(order)}>
                                        <RefreshCw className="mr-2 h-4 w-4" />
                                        Agregar Devolución
                                    </Button>
                                    <Button variant="default" size="sm" onClick={() => onUploadSigned(order)} className="bg-yellow-500 hover:bg-yellow-600 text-black">
                                        <UploadCloud className="mr-2 h-4 w-4" />
                                        Cargar Remito Firmado
                                    </Button>
                                </>
                            )}
                        </div>
                    );
                }
                return null;
            case 'cerrado':
                 if (userRole === 'centralizada' && order.devolucion_url) {
                    return (
                        <Button asChild variant="outline" size="sm">
                            <a href={order.devolucion_url} target="_blank" rel="noopener noreferrer">
                                <RefreshCw className="mr-2 h-4 w-4" /> Ver Devolución
                            </a>
                        </Button>
                    );
                }
                return null;
            default:
                return null;
        }
    };

    const renderActions = () => {
        if (['admin', 'centralizada'].includes(userRole)) {
            const centralActions = renderCentralActions();
            if (centralActions) return centralActions;
        }

        if (userRole === 'gerente') {
             const sucursalActions = renderSucursalActions();
             if (sucursalActions) return sucursalActions;
        }
        
        const sucursalActions = renderSucursalActions();
        if (sucursalActions) return sucursalActions;

        return null;
    }


    return (
        <Card className="w-full">
            <CardHeader>
                <div className="flex justify-between items-start">
                    <div className="space-y-1">
                        <div className="flex items-center gap-2">
                            <CardTitle className="text-lg">{order.sucursales?.nombre || 'Sucursal Desconocida'}</CardTitle>
                            <Badge variant={isProviderOrder ? "default" : "secondary"} className="text-[10px] uppercase flex items-center gap-1">
                                {isProviderOrder ? <Truck className="h-3 w-3" /> : <Building className="h-3 w-3" />}
                                {isProviderOrder ? 'A Proveedor' : 'Interno'}
                            </Badge>
                        </div>
                        <CardDescription>
                            Pedido: {new Date(order.fecha_pedido).toLocaleDateString()}
                            {order.remito_numero && ` | Remito N.º: ${String(order.remito_numero).padStart(6, '0')}`}
                            {sucursalVisibleStatuses.includes(order.estado) && order.fecha_envio && ` | Envío: ${new Date(order.fecha_envio).toLocaleDateString()}`}
                        </CardDescription>
                    </div>
                    <span className={statusInfo.className}>{statusInfo.text}</span>
                </div>
            </CardHeader>
            <CardContent>
                <ul className="list-disc list-inside text-sm space-y-1">
                    {order.productos.map(p => (
                        <li key={p.producto_id}>
                            <span className="font-medium">{productosMap[p.producto_id]?.nombre || 'N/A'}</span>:
                            Solicitado: {p.cantidad} {productosMap[p.producto_id]?.unidad_medida || ''}
                            {p.cantidad_enviada > 0 && <span className="text-blue-400 ml-2">(A enviar: {p.cantidad_enviada})</span>}
                        </li>
                    ))}
                </ul>
                {order.estado === 'confirmado' && !canModify && (
                    <div className="mt-3 text-sm text-teal-400 flex items-center gap-2">
                        <AlertCircle className="h-4 w-4" />
                        <span>Esperando recepción y carga de remito firmado por sucursal.</span>
                    </div>
                )}
                 {order.estado === 'firma_pendiente' && (
                    <div className="mt-3 text-sm text-purple-400 flex items-center gap-2">
                        <FileText className="h-4 w-4" />
                        <span>Remito firmado cargado. Pendiente de confirmación final.</span>
                    </div>
                )}
                {['admin', 'centralizada'].includes(userRole) && order.observaciones && (
                    <div className="mt-4 p-3 bg-yellow-500/10 border-l-4 border-yellow-500 rounded">
                        <div className="flex items-start gap-2">
                            <MessageSquareWarning className="h-5 w-5 text-yellow-500 mt-0.5" />
                            <div>
                                <h4 className="font-semibold text-yellow-400">Observaciones de Sucursal</h4>
                                <p className="text-sm text-yellow-300/80">{order.observaciones}</p>
                            </div>
                        </div>
                    </div>
                )}
                 {order.devolucion_url && userRole !== 'centralizada' && (
                    <div className="mt-3 text-sm text-indigo-400 flex items-center gap-2">
                        <RefreshCw className="h-4 w-4" />
                        <a href={order.devolucion_url} target="_blank" rel="noopener noreferrer" className="underline">Ver detalle de devolución cargado</a>
                    </div>
                )}
            </CardContent>
            <CardFooter className="flex justify-end">
                {renderActions()}
            </CardFooter>
        </Card>
    );
};

export default OrderCard;