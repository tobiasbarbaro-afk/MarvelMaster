import React, { useMemo } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';

const FilterBar = ({ 
    selectedStatus, 
    onStatusChange, 
    selectedBranch, 
    onBranchChange, 
    sucursales = [],
    availableStatuses = [] // Optional: if we want to pass specific statuses, otherwise use defaults
}) => {
    const { userRole } = useAuth();
    const showBranchFilter = ['admin', 'centralizada'].includes(userRole);

    // Default status list if none provided
    const defaultStatuses = [
        { value: 'all', label: 'Todos los Estados' },
        { value: 'pendiente', label: 'Pendiente' },
        { value: 'gestionado', label: 'Gestionado' },
        { value: 'firma_pendiente', label: 'Firma Pendiente' },
        { value: 'confirmado', label: 'Confirmado' },
        { value: 'cerrado', label: 'Cerrado' },
        { value: 'pendiente_proveedor', label: 'Pendiente Proveedor' },
        { value: 'orden_generada', label: 'Orden Generada' },
        { value: 'factura_cargada', label: 'Factura Cargada' },
        { value: 'cerrado_proveedor', label: 'Cerrado Proveedor' }
    ];

    const statuses = availableStatuses.length > 0 
        ? [{ value: 'all', label: 'Todos los Estados' }, ...availableStatuses] 
        : defaultStatuses;

    const handleClearFilters = () => {
        onStatusChange('all');
        if (showBranchFilter) {
            onBranchChange('all');
        }
    };

    const hasActiveFilters = selectedStatus !== 'all' || (showBranchFilter && selectedBranch !== 'all');

    return (
        <div className="flex flex-col sm:flex-row gap-4 p-4 bg-card border rounded-lg shadow-sm mb-6 items-end">
            <div className="flex-1 w-full sm:w-auto space-y-2">
                <Label htmlFor="status-filter">Estado</Label>
                <Select value={selectedStatus} onValueChange={onStatusChange}>
                    <SelectTrigger id="status-filter">
                        <SelectValue placeholder="Filtrar por estado" />
                    </SelectTrigger>
                    <SelectContent>
                        {statuses.map((status) => (
                            <SelectItem key={status.value} value={status.value}>
                                {status.label}
                            </SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>

            {showBranchFilter && (
                <div className="flex-1 w-full sm:w-auto space-y-2">
                    <Label htmlFor="branch-filter">Sucursal</Label>
                    <Select value={selectedBranch} onValueChange={onBranchChange}>
                        <SelectTrigger id="branch-filter">
                            <SelectValue placeholder="Filtrar por sucursal" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">Todas las Sucursales</SelectItem>
                            {sucursales.map((sucursal) => (
                                <SelectItem key={sucursal.id} value={sucursal.id.toString()}>
                                    {sucursal.nombre}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
            )}

            {hasActiveFilters && (
                <div className="pb-0.5">
                    <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={handleClearFilters}
                        title="Limpiar filtros"
                        className="text-muted-foreground hover:text-foreground"
                    >
                        <X className="h-4 w-4" />
                    </Button>
                </div>
            )}
        </div>
    );
};

export default FilterBar;