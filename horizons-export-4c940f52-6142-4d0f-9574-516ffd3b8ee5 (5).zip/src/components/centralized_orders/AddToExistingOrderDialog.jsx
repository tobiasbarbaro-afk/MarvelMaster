import React, { useState, useEffect, useCallback } from 'react';
    import { supabase } from '@/lib/supabaseClient';
    import { useToast } from '@/components/ui/use-toast';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { Button } from '@/components/ui/button';
    import { Loader2 } from 'lucide-react';
    
    const AddToExistingOrderDialog = ({ isOpen, onClose, missingItems, onSuccess }) => {
        const { toast } = useToast();
        const [pendingOrders, setPendingOrders] = useState([]);
        const [selectedOrderId, setSelectedOrderId] = useState('');
        const [loading, setLoading] = useState(false);
        const [isSubmitting, setIsSubmitting] = useState(false);
    
        const sucursalId = missingItems?.[0]?.sucursal_id;
    
        const fetchPendingOrders = useCallback(async () => {
            if (!sucursalId) return;
            setLoading(true);
            try {
                const { data, error } = await supabase
                    .from('pedidos_centralizada')
                    .select('id, fecha_pedido')
                    .eq('sucursal_id', sucursalId)
                    .eq('estado', 'pendiente')
                    .neq('estado', 'cerrado')
                    .neq('estado', 'cerrado_proveedor')
                    .order('fecha_pedido', { ascending: false });
    
                if (error) throw error;
                setPendingOrders(data);
            } catch (error) {
                toast({ variant: 'destructive', title: 'Error', description: 'No se pudieron cargar los pedidos pendientes.' });
            } finally {
                setLoading(false);
            }
        }, [sucursalId, toast]);
    
        useEffect(() => {
            if (isOpen) {
                fetchPendingOrders();
            }
        }, [isOpen, fetchPendingOrders]);
    
        const handleSubmit = async () => {
            if (!selectedOrderId) {
                toast({ variant: 'destructive', title: 'Error', description: 'Por favor, selecciona un pedido.' });
                return;
            }
    
            setIsSubmitting(true);
            try {
                // 1. Get the existing order
                const { data: existingOrder, error: fetchError } = await supabase
                    .from('pedidos_centralizada')
                    .select('productos')
                    .eq('id', selectedOrderId)
                    .single();
    
                if (fetchError) throw fetchError;
    
                // 2. Merge products
                const updatedProducts = [...existingOrder.productos];
                missingItems.forEach(missingItem => {
                    const existingProductIndex = updatedProducts.findIndex(p => p.producto_id === missingItem.producto_id);
                    if (existingProductIndex !== -1) {
                        updatedProducts[existingProductIndex].cantidad += missingItem.cantidad_faltante;
                    } else {
                        updatedProducts.push({
                            producto_id: missingItem.producto_id,
                            cantidad: missingItem.cantidad_faltante,
                        });
                    }
                });
    
                // 3. Update the order
                const { error: updateOrderError } = await supabase
                    .from('pedidos_centralizada')
                    .update({ productos: updatedProducts })
                    .eq('id', selectedOrderId);
    
                if (updateOrderError) throw updateOrderError;
    
                // 4. Update the missing items
                const missingItemIds = missingItems.map(item => item.id);
                const { error: updateMissingError } = await supabase
                    .from('faltantes_centralizada')
                    .update({ estado: 'reasignado', pedido_id: selectedOrderId })
                    .in('id', missingItemIds);
    
                if (updateMissingError) {
                    toast({ variant: 'destructive', title: 'Advertencia', description: 'Pedido actualizado, pero no se pudieron marcar los faltantes como reasignados.' });
                } else {
                    toast({ title: 'Éxito', description: 'Faltantes agregados al pedido existente.' });
                }
    
                onSuccess();
            } catch (error) {
                toast({ variant: 'destructive', title: 'Error', description: `No se pudo agregar al pedido: ${error.message}` });
            } finally {
                setIsSubmitting(false);
            }
        };
    
        return (
            <Dialog open={isOpen} onOpenChange={onClose}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Agregar Faltantes a Pedido Existente</DialogTitle>
                        <DialogDescription>
                            Selecciona un pedido pendiente de la sucursal "{missingItems?.[0]?.sucursales?.nombre}" para agregar los productos faltantes.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="py-4">
                        {loading ? (
                            <div className="flex justify-center"><Loader2 className="animate-spin" /></div>
                        ) : pendingOrders.length > 0 ? (
                            <Select onValueChange={setSelectedOrderId} value={selectedOrderId}>
                                <SelectTrigger>
                                    <SelectValue placeholder="Selecciona un pedido pendiente" />
                                </SelectTrigger>
                                <SelectContent>
                                    {pendingOrders.map(order => (
                                        <SelectItem key={order.id} value={order.id}>
                                            Pedido del {new Date(order.fecha_pedido).toLocaleDateString()}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        ) : (
                            <p className="text-center text-muted-foreground">No hay pedidos pendientes para esta sucursal.</p>
                        )}
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={onClose}>Cancelar</Button>
                        <Button onClick={handleSubmit} disabled={loading || isSubmitting || pendingOrders.length === 0 || !selectedOrderId}>
                            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Agregar a Pedido
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        );
    };
    
    export default AddToExistingOrderDialog;