import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';
import ManageOrderDialog from './ManageOrderDialog';
import UploadSignedRemitoDialog from './UploadSignedRemitoDialog';
import OrderCard from './OrderCard';
import { useAuth } from '@/hooks/useAuth';
import AddReturnDialog from './AddReturnDialog';
import ModifyOrderDialog from './ModifyOrderDialog';

const OrderList = ({ 
  statuses, 
  refreshTrigger, 
  onOrdersRefreshed, 
  productosMap, 
  loadingProducts, 
  processingOrders, 
  onProcessingChange,
  filterStatus = 'all',
  filterBranch = 'all'
}) => {
  const { toast } = useToast();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const { userRole, userProfile } = useAuth();

  const [selectedOrder, setSelectedOrder] = useState(null);
  const [isManageModalOpen, setIsManageModalOpen] = useState(false);
  const [isUploadSignedModalOpen, setIsUploadSignedModalOpen] = useState(false);
  const [isAddReturnModalOpen, setIsAddReturnModalOpen] = useState(false);
  const [isModifyModalOpen, setIsModifyModalOpen] = useState(false);

  const fetchOrders = useCallback(async () => {
    setLoading(true);
    try {
      // Fetch orders excluding closed ones explicitly
      let query = supabase
        .from('pedidos_centralizada')
        .select('*, sucursales(nombre, direccion)')
        .in('estado', statuses)
        .neq('estado', 'cerrado')
        .neq('estado', 'cerrado_proveedor')
        .order('fecha_pedido', { ascending: false });

      if (['gerente', 'empleado', 'cocina'].includes(userRole) && userProfile?.sucursal_id && userRole !== 'centralizada') {
        query = query.eq('sucursal_id', userProfile.sucursal_id);
      }

      if (userRole === 'cocina') {
         query = query.neq('estado', 'orden_generada');
      }

      const { data: ordersData, error: ordersError } = await query;
      if (ordersError) throw ordersError;

      if (userRole === 'centralizada' || userRole === 'admin') {
        const statusOrder = { pendiente: 1, gestionado: 2, firma_pendiente: 3, confirmado: 4, cerrado: 5, pendiente_proveedor: 6 };
        ordersData.sort((a, b) => {
          const orderA = statusOrder[a.estado] || 99;
          const orderB = statusOrder[b.estado] || 99;
          if (orderA !== orderB) return orderA - orderB;
          return new Date(b.fecha_pedido) - new Date(a.fecha_pedido);
        });
      }

      setOrders(ordersData);
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: `No se pudieron cargar los pedidos: ${error.message}`,
      });
    } finally {
      setLoading(false);
    }
  }, [toast, statuses, userRole, userProfile]);

  useEffect(() => {
    fetchOrders();
  }, [fetchOrders, refreshTrigger]);

  const filteredOrders = useMemo(() => {
    return orders.filter(order => {
        const matchesStatus = filterStatus === 'all' || order.estado === filterStatus;
        const matchesBranch = filterBranch === 'all' || (order.sucursal_id && order.sucursal_id.toString() === filterBranch);
        return matchesStatus && matchesBranch;
    });
  }, [orders, filterStatus, filterBranch]);

  const handleManageClick = (order) => {
    setSelectedOrder(order);
    setIsManageModalOpen(true);
  };

  const handleUploadSignedClick = (order) => {
    setSelectedOrder(order);
    setIsUploadSignedModalOpen(true);
  };
  
  const handleAddReturnClick = (order) => {
    setSelectedOrder(order);
    setIsAddReturnModalOpen(true);
  };

  const handleModifyClick = (order) => {
    setSelectedOrder(order);
    setIsModifyModalOpen(true);
  };

  const handleGenerateAndConfirm = async (orderId) => {
    // Set loading state for this specific order
    onProcessingChange(orderId, true);
    
    try {
      const { data, error } = await supabase.functions.invoke('generate-remito', {
        body: { orderId },
      });

      if (error) throw error;

      const { success, remitoUrl, error: serverError } = data || {};
      if (!success) {
        throw new Error(serverError || 'No se pudo generar el remito.');
      }

      toast({ title: 'Éxito', description: 'Remito generado y pedido confirmado.' });
      handleOrderManaged();

    } catch (err) {
      console.error("Error generating remito:", err);
      toast({ variant: 'destructive', title: 'Error', description: err.message });
    } finally {
      // Clear loading state for this specific order
      onProcessingChange(orderId, false);
    }
  };

  const handleConfirmFinal = async (orderId) => {
    // Set loading state for this specific order
    onProcessingChange(orderId, true);

    try {
      const { error } = await supabase
        .from('pedidos_centralizada')
        .update({ estado: 'cerrado' })
        .eq('id', orderId);
      if (error) throw error;
      toast({ title: 'Éxito', description: 'Pedido cerrado correctamente.' });
      handleOrderManaged();
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: `No se pudo cerrar el pedido: ${error.message}`,
      });
    } finally {
        // Clear loading state
        onProcessingChange(orderId, false);
    }
  };

  const handleCloseModals = () => {
    setIsManageModalOpen(false);
    setIsUploadSignedModalOpen(false);
    setIsAddReturnModalOpen(false);
    setIsModifyModalOpen(false);
    setSelectedOrder(null);
  };

  // Called when a child dialog completes an action
  const handleOrderManaged = () => {
    // 1. Re-fetch local orders
    fetchOrders();
    // 2. Notify parent to refresh other lists if needed
    if (onOrdersRefreshed) onOrdersRefreshed();
  };

  if (loading || loadingProducts) {
    return (
      <div className="flex justify-center items-center h-40">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {filteredOrders.length === 0 ? (
        <div className="text-center text-muted-foreground py-10">
            {orders.length > 0 ? "No hay pedidos que coincidan con los filtros." : "No hay pedidos en esta sección."}
        </div>
      ) : (
        filteredOrders.map((order) => (
          <OrderCard
            key={order.id}
            order={order}
            productosMap={productosMap}
            onManage={handleManageClick}
            onUploadSigned={handleUploadSignedClick}
            onGenerateAndConfirm={handleGenerateAndConfirm}
            onConfirmFinal={handleConfirmFinal}
            onAddReturn={handleAddReturnClick}
            onModify={handleModifyClick}
            isProcessing={!!processingOrders[order.id]} // Check per-order loading status
          />
        ))
      )}

      {selectedOrder && (
        <>
          <ManageOrderDialog
            order={selectedOrder}
            isOpen={isManageModalOpen}
            onClose={handleCloseModals}
            onOrderUpdated={handleOrderManaged}
            productosMap={productosMap}
          />
          <UploadSignedRemitoDialog
            order={selectedOrder}
            isOpen={isUploadSignedModalOpen}
            onClose={handleCloseModals}
            onOrderManaged={handleOrderManaged}
          />
          <AddReturnDialog
            order={selectedOrder}
            isOpen={isAddReturnModalOpen}
            onClose={handleCloseModals}
            onOrderManaged={handleOrderManaged}
          />
          <ModifyOrderDialog
            order={selectedOrder}
            isOpen={isModifyModalOpen}
            onClose={handleCloseModals}
            onOrderManaged={handleOrderManaged}
            productosMap={productosMap}
          />
        </>
      )}
    </div>
  );
};

export default OrderList;