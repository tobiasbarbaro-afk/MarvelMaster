import React, { useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, UploadCloud, File, RefreshCw } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

const AddReturnDialog = ({ order, isOpen, onClose, onOrderManaged }) => {
    const { toast } = useToast();
    const [file, setFile] = useState(null);
    const [loading, setLoading] = useState(false);

    const handleFileChange = (e) => {
        if (e.target.files && e.target.files.length > 0) {
            setFile(e.target.files[0]);
        }
    };

    const handleUpload = async () => {
        if (!file) {
            toast({ variant: 'destructive', title: 'Error', description: 'Por favor, seleccione un archivo.' });
            return;
        }

        setLoading(true);

        try {
            const fileExt = file.name.split('.').pop();
            const fileName = `${uuidv4()}.${fileExt}`;
            const filePath = `public/devoluciones_centralizada/${order.id}/${fileName}`;
            
            // Upload file to Supabase Storage
            const { error: uploadError } = await supabase.storage
                .from('devoluciones_centralizada')
                .upload(filePath, file);

            if (uploadError) {
                throw new Error(`Error al subir el archivo: ${uploadError.message}`);
            }

            // Get public URL of the uploaded file
            const { data: urlData } = supabase.storage
                .from('devoluciones_centralizada')
                .getPublicUrl(filePath);
            
            if (!urlData || !urlData.publicUrl) {
                throw new Error('No se pudo obtener la URL pública del archivo.');
            }

            // Update the order in the database
            const { error: dbError } = await supabase
                .from('pedidos_centralizada')
                .update({
                    devolucion_url: urlData.publicUrl,
                })
                .eq('id', order.id);

            if (dbError) {
                throw new Error(`Error al actualizar el pedido: ${dbError.message}`);
            }

            toast({ title: 'Éxito', description: 'El detalle de devolución se ha cargado correctamente.' });
            onOrderManaged();
            handleClose();
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: error.message });
        } finally {
            setLoading(false);
        }
    };

    const handleClose = () => {
        setFile(null);
        onClose();
    };

    return (
        <Dialog open={isOpen} onOpenChange={handleClose}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Agregar Detalle de Devolución</DialogTitle>
                    <DialogDescription>
                        Adjunte un archivo (JPG, PNG, PDF) con el detalle de la mercadería devuelta a centralizada para el pedido N.º {order?.remito_numero}.
                    </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                    <div className="grid w-full max-w-sm items-center gap-1.5">
                        <Label htmlFor="return-file">Archivo de Devolución</Label>
                        <Input id="return-file" type="file" accept="image/jpeg,image/png,application/pdf" onChange={handleFileChange} />
                    </div>
                    {file && (
                        <div className="flex items-center p-2 mt-2 bg-muted rounded-md text-sm">
                            <File className="h-4 w-4 mr-2 flex-shrink-0" />
                            <span className="truncate">{file.name}</span>
                        </div>
                    )}
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={handleClose}>Cancelar</Button>
                    <Button onClick={handleUpload} disabled={!file || loading}>
                        {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
                        Subir Devolución
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

export default AddReturnDialog;