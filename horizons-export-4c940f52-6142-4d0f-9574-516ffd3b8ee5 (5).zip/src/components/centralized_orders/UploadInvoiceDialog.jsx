import React, { useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, UploadCloud } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

const UploadInvoiceDialog = ({ order, isOpen, onClose, onInvoiceUploaded }) => {
    const { toast } = useToast();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [invoiceFile, setInvoiceFile] = useState(null);
    const [observaciones, setObservaciones] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!invoiceFile) {
            toast({ variant: 'destructive', title: 'Falta archivo', description: 'Debes cargar el archivo de la factura.' });
            return;
        }
        setIsSubmitting(true);

        try {
            const fileExt = invoiceFile.name.split('.').pop();
            const fileName = `factura-${order.id}-${uuidv4()}.${fileExt}`;
            const filePath = `public/facturas_proveedores/${fileName}`;

            // Upload factura file con contentType explícito
            const { data: uploadData, error: uploadError } = await supabase.storage
                .from('remitos_centralizada')
                .upload(filePath, invoiceFile, {
                    contentType: invoiceFile.type,
                    cacheControl: '3600',
                    upsert: false
                });

            if (uploadError) throw uploadError;

            const { data: urlData } = supabase.storage.from('remitos_centralizada').getPublicUrl(filePath);

            // Create or Update record in facturas table
            // Usamos upsert con onConflict en 'numero_pedido' para evitar el error de clave duplicada
            // si ya existe una factura para este pedido.
            const { data: facturaRecord, error: facturaError } = await supabase
                .from('facturas')
                .upsert({
                    fecha: new Date().toISOString().split('T')[0],
                    sucursal_id: order.sucursal_id,
                    proveedor_id: order.proveedor_id,
                    numero_pedido: order.id, // Constraint uq_factura_numero_pedido
                    archivo_url: urlData.publicUrl,
                    verificado: false, // Resetear estado de verificación al subir nueva versión
                    cargado_en_sistema: false,
                    orden_compra_asociada_id: order.id,
                }, { onConflict: 'numero_pedido' })
                .select('id')
                .single();
            
            if (facturaError) throw facturaError;
            
            // Invoke edge function to merge documents
            const { data: mergeData, error: mergeError } = await supabase.functions.invoke('merge-oc-factura', {
                body: {
                    orderId: order.id,
                    facturaUrl: urlData.publicUrl,
                    facturaId: facturaRecord.id
                }
            });

            if (mergeError) throw mergeError;
            if (!mergeData.success) throw new Error(mergeData.error || 'Error al fusionar documentos.');

            // Update the order with the merged PDF and new state
            const { error: updateError } = await supabase
                .from('pedidos_centralizada')
                .update({
                    estado: 'factura_cargada',
                    remito_firmado_url: mergeData.mergedPdfUrl,
                    observaciones: observaciones || null,
                })
                .eq('id', order.id);

            if (updateError) throw updateError;
            
            toast({ title: 'Éxito', description: 'Factura cargada y documento de compra generado.' });
            onInvoiceUploaded();
            onClose();

        } catch (error) {
            console.error('Error uploading invoice:', error);
            toast({ variant: 'destructive', title: 'Error', description: `No se pudo cargar la factura: ${error.message}` });
        } finally {
            setIsSubmitting(false);
        }
    };

    if (!order) return null;

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Cargar Factura de Proveedor</DialogTitle>
                    <DialogDescription>
                        Sube el archivo (PDF, JPG, PNG) de la factura para el pedido a {order.suppliers.name}.
                    </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4 pt-4">
                    <div>
                        <Label htmlFor="invoice_file">Archivo de Factura</Label>
                        <Input 
                            id="invoice_file" 
                            type="file" 
                            accept="application/pdf,image/jpeg,image/png,image/jpg" 
                            onChange={(e) => setInvoiceFile(e.target.files[0])} 
                        />
                    </div>
                    <div>
                        <Label htmlFor="observaciones">Observaciones (opcional)</Label>
                        <Textarea 
                            id="observaciones"
                            placeholder="Ej: La factura tiene un monto diferente al acordado..."
                            value={observaciones}
                            onChange={(e) => setObservaciones(e.target.value)}
                        />
                    </div>
                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
                        <Button type="submit" disabled={isSubmitting || !invoiceFile}>
                            {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UploadCloud className="mr-2 h-4 w-4" />}
                            Cargar y Confirmar
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default UploadInvoiceDialog;