import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Loader2 } from 'lucide-react';
import OrderCardProveedor from './OrderCardProveedor';
import UploadInvoiceDialog from './UploadInvoiceDialog';
import { useAuth } from '@/hooks/useAuth';
import { validateAndFilterOrders } from '@/lib/orderStatusValidator';

const OrderListProveedor = ({ 
    refreshTrigger, 
    onOrdersRefreshed, 
    productosMap, 
    loadingProducts,
    filterStatus = 'all',
    filterBranch = 'all',
    statuses // array of allowed statuses
}) => {
    const { toast } = useToast();
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const { userRole, userProfile } = useAuth();
    
    // Action States
    const [isGeneratingOC, setIsGeneratingOC] = useState(false);
    const [isGeneratingRemito, setIsGeneratingRemito] = useState(false);
    
    // Upload Invoice State
    const [isUploadingInvoice, setIsUploadingInvoice] = useState(false);
    const [selectedOrderForInvoice, setSelectedOrderForInvoice] = useState(null);

    const fetchOrders = useCallback(async () => {
        setLoading(true);
        try {
            let query = supabase
                .from('pedidos_centralizada')
                .select('*, sucursales(nombre), suppliers(name, cuit)');

            // Apply explicit status filtering at the DB level according to Task requirements
            if (statuses && statuses.includes('pendiente_proveedor') && statuses.length === 1) {
                // Task 1 & 5: Fetch orders with (estado = 'pendiente_proveedor' OR tipo_pedido = 'reposicion_faltantes') AND estado != 'orden_generada'
                query = query.or('estado.eq.pendiente_proveedor,tipo_pedido.eq.reposicion_faltantes')
                             .neq('estado', 'orden_generada');
            } else if (statuses && statuses.length > 0) {
                query = query.in('estado', statuses);
                if (!statuses.includes('orden_generada')) {
                    query = query.neq('estado', 'orden_generada');
                }
            } else {
                query = query.eq('estado', 'orden_generada');
            }

            // Globally exclude closed orders from active views
            query = query.neq('estado', 'cerrado').neq('estado', 'cerrado_proveedor');

            // Role-based filtering
            if (['gerente', 'cocina'].includes(userRole) && userProfile?.sucursal_id) {
                query = query.eq('sucursal_id', userProfile.sucursal_id);
            }
            
            const { data, error } = await query;
            if (error) throw error;
            
            // Front-end Validation: Ensure logic is maintained
            const expectedContext = (statuses && statuses.includes('pendiente_proveedor') && statuses.length === 1) 
                ? 'centralized_proveedor' 
                : (statuses || 'provider_orders');

            const validData = validateAndFilterOrders(data || [], expectedContext);

            // Sorting logic
            const statusOrder = {
                pendiente: 1,
                gestionado: 1,
                pendiente_proveedor: 1,
                orden_generada: 2,
                factura_cargada: 3,
                cerrado_proveedor: 4
            };

            validData.sort((a, b) => {
                const orderA = statusOrder[a.estado] || 99;
                const orderB = statusOrder[b.estado] || 99;
                if (orderA !== orderB) return orderA - orderB;
                return new Date(b.fecha_pedido) - new Date(a.fecha_pedido);
            });

            setOrders(validData);
        } catch (error) {
            console.error("[OrderListProveedor] Fetch error:", error);
            toast({ variant: 'destructive', title: 'Error', description: `No se pudieron cargar los pedidos: ${error.message}` });
        } finally {
            setLoading(false);
        }
    }, [toast, userRole, userProfile, statuses]);

    useEffect(() => {
        fetchOrders();
    }, [fetchOrders, refreshTrigger]);

    const filteredOrders = useMemo(() => {
        return orders.filter(order => {
            const matchesStatus = filterStatus === 'all' || order.estado === filterStatus;
            const matchesBranch = filterBranch === 'all' || (order.sucursal_id && order.sucursal_id.toString() === filterBranch);
            return matchesStatus && matchesBranch;
        });
    }, [orders, filterStatus, filterBranch]);
    
    const handleGenerateOC = async (order) => {
        setIsGeneratingOC(true);
        try {
            const { data, error } = await supabase.functions.invoke('generate-orden-compra', {
                body: { orderId: order.id }
            });

            if (error) throw error;
            if (!data.success) throw new Error(data.error || "Error en la función al generar OC.");
            
            toast({ title: 'Éxito', description: 'Orden de Compra generada exitosamente y guardada en el sistema.' });
            onOrdersRefreshed();
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: `No se pudo generar la OC: ${error.message}` });
        } finally {
            setIsGeneratingOC(false);
        }
    };

    const handleGenerateRemito = async (order) => {
        setIsGeneratingRemito(true);
        try {
            const { data, error } = await supabase.functions.invoke('generate-remito', {
                body: { orderId: order.id }
            });

            if (error) throw error;
            if (!data.success) throw new Error(data.error || "Error en la función al generar el Remito.");

            toast({ title: 'Éxito', description: 'Remito interno generado y pedido confirmado.' });
            onOrdersRefreshed();
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: `No se pudo generar el remito: ${error.message}` });
        } finally {
            setIsGeneratingRemito(false);
        }
    };
    
    const handleUploadInvoice = (order) => {
        setSelectedOrderForInvoice(order);
        setIsUploadingInvoice(true);
    };

    const handleInvoiceUploaded = () => {
        setIsUploadingInvoice(false);
        setSelectedOrderForInvoice(null);
        onOrdersRefreshed();
    };

    const handleCloseOrder = async (orderId) => {
        try {
            const { error } = await supabase
                .from('pedidos_centralizada')
                .update({ estado: 'cerrado_proveedor' })
                .eq('id', orderId);
            if (error) throw error;
            toast({ title: 'Éxito', description: 'El pedido al proveedor ha sido cerrado.' });
            onOrdersRefreshed();
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: `No se pudo cerrar el pedido: ${error.message}` });
        }
    };

    if (loading || loadingProducts) {
        return <div className="flex justify-center items-center h-40"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
    }

    return (
        <div className="space-y-4">
            {filteredOrders.length === 0 ? (
                <div className="text-center text-muted-foreground py-10 border rounded-md bg-muted/20">
                    {orders.length > 0 
                        ? "No hay pedidos que coincidan con los filtros aplicados." 
                        : "No hay pedidos en este estado disponibles para mostrar."}
                </div>
            ) : (
                filteredOrders.map((order, index) => (
                    <OrderCardProveedor
                        key={`${order.id}-${index}`}
                        order={order}
                        productosMap={productosMap}
                        onGenerateOC={handleGenerateOC}
                        onGenerateRemito={handleGenerateRemito}
                        onUploadInvoice={handleUploadInvoice}
                        onCloseOrder={handleCloseOrder}
                        isGeneratingOC={isGeneratingOC}
                        isGeneratingRemito={isGeneratingRemito}
                        userRole={userRole}
                    />
                ))
            )}
            {selectedOrderForInvoice && (
                <UploadInvoiceDialog
                    isOpen={isUploadingInvoice}
                    onClose={() => setIsUploadingInvoice(false)}
                    order={selectedOrderForInvoice}
                    onInvoiceUploaded={handleInvoiceUploaded}
                />
            )}
        </div>
    );
};

export default OrderListProveedor;