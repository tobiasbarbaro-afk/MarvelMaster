import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FileText, Truck, Building, CheckCircle, UploadCloud, Loader2, Download } from 'lucide-react';

const OrderCardProveedor = ({ 
    order, 
    productosMap, 
    onGenerateOC, 
    onGenerateRemito, 
    onUploadInvoice, 
    onCloseOrder, 
    isGeneratingOC, 
    isGeneratingRemito,
    userRole 
}) => {
    
    const getStatusInfo = (status) => {
        const baseClasses = 'px-2 py-1 text-xs font-medium rounded-full inline-flex items-center gap-1.5';
        switch (status) {
            case 'pendiente':
            case 'gestionado':
                return { text: 'Pendiente (Interno)', className: `${baseClasses} bg-gray-500/20 text-gray-400` };
            case 'pendiente_proveedor':
                return { text: 'Pendiente Proveedor', className: `${baseClasses} bg-yellow-500/20 text-yellow-400` };
            case 'orden_generada':
                return { text: 'OC Generada', className: `${baseClasses} bg-blue-500/20 text-blue-400` };
            case 'factura_cargada':
                return { text: 'Factura Cargada', className: `${baseClasses} bg-purple-500/20 text-purple-400` };
            case 'cerrado_proveedor':
                return { text: 'Cerrado', className: `${baseClasses} bg-green-500/20 text-green-400` };
            default:
                return { text: status, className: `${baseClasses} bg-gray-500/20 text-gray-400` };
        }
    };

    const statusInfo = getStatusInfo(order.estado);
    const isCentralOrAdmin = ['admin', 'centralizada'].includes(userRole);
    
    // Check if the order is functionally an internal one (tipo_pedido = interno OR reposicion_faltantes without a supplier)
    const isInterno = order.tipo_pedido === 'interno' || (order.tipo_pedido === 'reposicion_faltantes' && !order.proveedor_id);

    const renderActions = () => {
        if (isCentralOrAdmin) {
            // Task 2: Action buttons condition checks
            const isPending = ['pendiente_proveedor', 'pendiente', 'gestionado'].includes(order.estado);
            const isFaltantesPending = order.tipo_pedido === 'reposicion_faltantes' && !['orden_generada', 'confirmado', 'cerrado', 'cerrado_proveedor', 'factura_cargada'].includes(order.estado);

            if (isPending || isFaltantesPending) {
                if (isInterno) {
                    return (
                        <Button onClick={() => onGenerateRemito(order)} disabled={isGeneratingRemito}>
                            {isGeneratingRemito ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileText className="mr-2 h-4 w-4" />}
                            Generar Remito
                        </Button>
                    );
                } else {
                    return (
                        <Button onClick={() => onGenerateOC(order)} disabled={isGeneratingOC}>
                            {isGeneratingOC ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileText className="mr-2 h-4 w-4" />}
                            Confirmar y Generar OC
                        </Button>
                    );
                }
            }

            switch (order.estado) {
                case 'orden_generada':
                     return (
                        <Button asChild variant="secondary">
                            <a href={order.orden_compra_url} target="_blank" rel="noopener noreferrer">
                                <Download className="mr-2 h-4 w-4" /> Descargar OC
                            </a>
                        </Button>
                    );
                case 'factura_cargada':
                    return (
                        <div className="flex gap-2">
                             <Button asChild variant="secondary">
                                <a href={order.remito_firmado_url} target="_blank" rel="noopener noreferrer">
                                    <Download className="mr-2 h-4 w-4" /> Ver Doc. Compra
                                </a>
                            </Button>
                            <Button onClick={() => onCloseOrder(order.id)}>
                                <CheckCircle className="mr-2 h-4 w-4" /> Cerrar Pedido
                            </Button>
                        </div>
                    );
                 case 'cerrado_proveedor':
                     return (
                        <Button asChild variant="secondary">
                            <a href={order.remito_firmado_url} target="_blank" rel="noopener noreferrer">
                                <Download className="mr-2 h-4 w-4" /> Ver Doc. Compra
                            </a>
                        </Button>
                    );
                default: return null;
            }
        } else { // Sucursal roles
            switch (order.estado) {
                case 'orden_generada':
                    return (
                        <Button onClick={() => onUploadInvoice(order)}>
                            <UploadCloud className="mr-2 h-4 w-4" /> Cargar Factura
                        </Button>
                    );
                case 'factura_cargada':
                case 'cerrado_proveedor':
                    return (
                         <Button asChild variant="secondary">
                            <a href={order.remito_firmado_url} target="_blank" rel="noopener noreferrer">
                                <Download className="mr-2 h-4 w-4" /> Ver Doc. Compra
                            </a>
                        </Button>
                    );
                default: return <p className="text-sm text-muted-foreground">Pendiente de gestión central.</p>;
            }
        }
    };
    
    return (
        <Card className={`w-full border-l-4 ${isInterno ? 'border-blue-500' : 'border-amber-500'}`}>
            <CardHeader>
                <div className="flex justify-between items-start">
                    <div>
                        <CardTitle className="text-lg flex items-center gap-2">
                            {isInterno ? <Building className="h-5 w-5" /> : <Truck className="h-5 w-5" />}
                            {isInterno ? 'Pedido Interno (Reposición)' : `Pedido a ${order.suppliers?.name || 'Proveedor'}`}
                        </CardTitle>
                        <CardDescription>
                            Para sucursal: {order.sucursales?.nombre} | Pedido del: {new Date(order.fecha_pedido).toLocaleDateString()}
                        </CardDescription>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                        <span className={statusInfo.className}>{statusInfo.text}</span>
                        {order.tipo_pedido === 'reposicion_faltantes' && (
                            <Badge variant="outline" className="text-[10px] uppercase">
                                Reposición de Faltantes
                            </Badge>
                        )}
                    </div>
                </div>
            </CardHeader>
            <CardContent>
                <ul className="list-disc list-inside text-sm space-y-1">
                    {order.productos.map((p, index) => (
                        <li key={`${p.producto_id}-${index}`}>
                            <span className="font-medium">{productosMap[p.producto_id]?.nombre || 'N/A'}</span>:
                            Solicitado: {p.cantidad} {productosMap[p.producto_id]?.unidad_medida || ''}
                        </li>
                    ))}
                </ul>
                {order.observaciones && (
                     <div className="mt-4 p-3 bg-yellow-500/10 border-l-4 border-yellow-500 rounded">
                        <h4 className="font-semibold text-yellow-400">Observaciones</h4>
                        <p className="text-sm text-yellow-300/80">{order.observaciones}</p>
                    </div>
                )}
            </CardContent>
            <CardFooter className="flex justify-end">
                {renderActions()}
            </CardFooter>
        </Card>
    );
};

export default OrderCardProveedor;