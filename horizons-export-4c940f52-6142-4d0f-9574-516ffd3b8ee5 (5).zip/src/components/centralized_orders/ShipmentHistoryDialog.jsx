import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Loader2, Download, Calendar as CalendarIcon, FileText, Package, ChevronDown, ChevronUp } from 'lucide-react';
import { format, startOfMonth, endOfMonth } from 'date-fns';
import { es } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { exportToExcel } from '@/lib/sheetUtils';
import { motion, AnimatePresence } from 'framer-motion';

const ShipmentHistoryDialog = ({ 
    isOpen, 
    onClose, 
    productosMap, 
    sucursales,
    filterStatus = 'all',
    filterBranch = 'all' 
}) => {
    const { userRole, userProfile } = useAuth();
    const { toast } = useToast();
    const [loading, setLoading] = useState(false);
    const [isDownloading, setIsDownloading] = useState(false);
    const [closedOrders, setClosedOrders] = useState([]);
    const [activeTab, setActiveTab] = useState('history');
    const [suppliers, setSuppliers] = useState([]);
    const [showFilters, setShowFilters] = useState(true);

    const [filters, setFilters] = useState({
        sucursal_id: 'all',
        tipo_pedido: 'all',
        supplier_id: 'all',
        date_from: startOfMonth(new Date()),
        date_to: endOfMonth(new Date()),
    });

    useEffect(() => {
        if (filterBranch !== 'all') {
             setFilters(prev => ({ ...prev, sucursal_id: filterBranch }));
        }
    }, [filterBranch]);

    useEffect(() => {
        const fetchSuppliers = async () => {
            try {
                const { data, error } = await supabase
                    .from('suppliers')
                    .select('*')
                    .order('name');
                
                if (error) throw error;
                setSuppliers(data || []);
            } catch (error) {
                console.error('Error fetching suppliers:', error);
            }
        };

        fetchSuppliers();
    }, []);

    const fetchClosedOrders = useCallback(async () => {
        setLoading(true);
        try {
            let query = supabase
                .from('pedidos_centralizada')
                .select(`
                    *, 
                    sucursales(id, nombre),
                    suppliers(id, name)
                `)
                .in('estado', ['cerrado', 'cerrado_proveedor'])
                .order('fecha_pedido', { ascending: false });

            if (userRole === 'gerente' && userProfile?.sucursal_id) {
                query = query.eq('sucursal_id', userProfile.sucursal_id).eq('tipo_pedido', 'interno');
            }
            
            const { data: orders, error } = await query;
            if (error) throw error;

            const supplierOrders = orders.filter(o => o.tipo_pedido === 'proveedor');
            
            if (supplierOrders.length > 0) {
                const supplierOrderIds = supplierOrders.map(o => o.id);
                
                const { data: facturas, error: facturasError } = await supabase
                    .from('facturas')
                    .select('id, orden_compra_asociada_id, pdf_fusionado_url, archivo_url, numero_pedido, fecha')
                    .in('orden_compra_asociada_id', supplierOrderIds)
                    .not('pdf_fusionado_url', 'is', null);
                
                if (facturasError) console.error('Error fetching facturas:', facturasError);
                
                const facturaIds = facturas?.map(f => f.id).filter(Boolean) || [];
                let ordenesCompra = [];
                if (facturaIds.length > 0) {
                    const { data: ocs, error: ocsError } = await supabase
                        .from('ordenes_compra')
                        .select('id, factura_id, pdf_fusionado_url, archivo_url, numero_pedido, fecha')
                        .in('factura_id', facturaIds)
                        .not('pdf_fusionado_url', 'is', null);
                    
                    if (ocsError) console.error('Error fetching ordenes_compra:', ocsError);
                    ordenesCompra = ocs || [];
                }
                
                orders.forEach(order => {
                    if (order.tipo_pedido === 'proveedor') {
                        order.facturas_docs = facturas?.filter(f => f.orden_compra_asociada_id === order.id) || [];
                        order.ordenes_compra_docs = [];
                        
                        order.facturas_docs.forEach(factura => {
                            const ocs = ordenesCompra.filter(oc => oc.factura_id === factura.id);
                            order.ordenes_compra_docs.push(...ocs);
                        });
                    }
                });
            }
            
            setClosedOrders(orders || []);
        } catch (error) {
            console.error('Error in fetchClosedOrders:', error);
            toast({ variant: 'destructive', title: 'Error', description: `No se pudo cargar el historial: ${error.message}` });
        } finally {
            setLoading(false);
        }
    }, [userRole, userProfile, toast]);

    useEffect(() => {
        if (isOpen) {
            fetchClosedOrders();
            if (userRole === 'gerente' && userProfile?.sucursal_id) {
                setFilters(prev => ({ ...prev, sucursal_id: userProfile.sucursal_id.toString(), tipo_pedido: 'interno' }));
            }
        }
    }, [isOpen, fetchClosedOrders, userRole, userProfile]);

    const filteredHistory = useMemo(() => {
        return closedOrders.filter(order => {
            const orderDate = new Date(order.fecha_envio || order.fecha_pedido);
            const from = filters.date_from ? new Date(new Date(filters.date_from).setHours(0, 0, 0, 0)) : null;
            const to = filters.date_to ? new Date(new Date(filters.date_to).setHours(23, 59, 59, 999)) : null;

            const sucursalMatch = filters.sucursal_id === 'all' || order.sucursal_id?.toString() === filters.sucursal_id;
            const tipoMatch = filters.tipo_pedido === 'all' || order.tipo_pedido === filters.tipo_pedido;
            const supplierMatch = filters.supplier_id === 'all' || 
                                  (order.proveedor_id && order.proveedor_id.toString() === filters.supplier_id);
            const dateMatch = (!from || orderDate >= from) && (!to || orderDate <= to);

            const globalStatusMatch = filterStatus === 'all' || order.estado === filterStatus;
            const globalBranchMatch = filterBranch === 'all' || (order.sucursal_id && order.sucursal_id.toString() === filterBranch);

            return sucursalMatch && tipoMatch && dateMatch && supplierMatch && globalStatusMatch && globalBranchMatch;
        });
    }, [closedOrders, filters, filterStatus, filterBranch]);

    const productSummary = useMemo(() => {
        const summary = filteredHistory.reduce((acc, order) => {
            order.productos?.forEach(p => {
                const qty = order.tipo_pedido === 'interno' ? p.cantidad_enviada : p.cantidad;
                if (qty > 0) {
                    if (!acc[p.producto_id]) {
                        acc[p.producto_id] = {
                            total_enviado: 0,
                            pedidos_internos: new Set(),
                            pedidos_proveedor: new Set(),
                        };
                    }
                    acc[p.producto_id].total_enviado += qty;
                    if (order.tipo_pedido === 'interno') {
                        acc[p.producto_id].pedidos_internos.add(order.id);
                    } else {
                        acc[p.producto_id].pedidos_proveedor.add(order.id);
                    }
                }
            });
            return acc;
        }, {});

        return Object.entries(summary).map(([producto_id, data]) => ({
            producto_id,
            nombre: productosMap[producto_id]?.nombre || 'Desconocido',
            unidad_medida: productosMap[producto_id]?.unidad_medida || '',
            total_enviado: data.total_enviado,
            pedidos_internos: data.pedidos_internos.size,
            pedidos_proveedor: data.pedidos_proveedor.size,
        }));
    }, [filteredHistory, productosMap]);

    const handleFilterChange = (key, value) => {
        setFilters(prev => ({ ...prev, [key]: value }));
        if (key === 'tipo_pedido' && value === 'proveedor') {
            setShowFilters(false);
        }
    };

    const handleExport = () => {
        setIsDownloading(true);
        try {
            const historySheetData = filteredHistory.map(order => {
                const isInternal = order.tipo_pedido === 'interno';
                return {
                    "Tipo": isInternal ? 'Interno' : 'Proveedor',
                    "N° Pedido/Remito": isInternal 
                        ? String(order.remito_numero || '').padStart(6, '0') 
                        : order.id?.substring(0, 8) || '-',
                    "Fecha": format(new Date(order.fecha_envio || order.fecha_pedido), 'dd/MM/yyyy'),
                    "Sucursal": order.sucursales?.nombre || '-',
                    "Proveedor": order.suppliers?.name || '-',
                    "Productos": order.productos
                        ?.filter(p => (isInternal ? p.cantidad_enviada : p.cantidad) > 0)
                        .map(p => {
                            const qty = isInternal ? p.cantidad_enviada : p.cantidad;
                            return `${productosMap[p.producto_id]?.nombre}: ${qty}`;
                        })
                        .join('\n') || '-',
                    "Observaciones": order.observaciones || '-',
                    "Documentos Disponibles": isInternal 
                        ? (order.remito_pdf_url ? 'Remito PDF, ' : '') + (order.remito_firmado_url ? 'Remito Firmado' : '')
                        : (order.facturas_docs?.length || 0) + ' Facturas fusionadas, ' + (order.ordenes_compra_docs?.length || 0) + ' OCs fusionadas',
                };
            });

            const summarySheetData = productSummary.map(item => ({
                "Producto": item.nombre,
                "Unidad de Medida": item.unidad_medida,
                "Cantidad Total": item.total_enviado,
                "Pedidos Internos": item.pedidos_internos,
                "Pedidos Proveedor": item.pedidos_proveedor,
                "Total Pedidos": item.pedidos_internos + item.pedidos_proveedor,
            }));

            const sheets = [
                { sheetName: 'Historial Pedidos Cerrados', data: historySheetData },
                { sheetName: 'Resumen Productos', data: summarySheetData }
            ];

            const fromDate = filters.date_from ? format(filters.date_from, 'yyyy-MM-dd') : 'inicio';
            const toDate = filters.date_to ? format(filters.date_to, 'yyyy-MM-dd') : 'fin';
            const fileName = `Reporte_Pedidos_${filters.tipo_pedido}_${fromDate}_a_${toDate}`;

            exportToExcel({ sheets, fileName });

            toast({ title: 'Éxito', description: 'El reporte se ha generado correctamente.' });
        } catch (error) {
            console.error('Export error:', error);
            toast({ variant: 'destructive', title: 'Error', description: `No se pudo generar el reporte: ${error.message}` });
        } finally {
            setIsDownloading(false);
        }
    };

    const renderDocuments = (order) => {
        const isInternal = order.tipo_pedido === 'interno';
        
        if (isInternal) {
            return (
                <div className="flex flex-col gap-1">
                    {order.remito_pdf_url && (
                        <Button asChild variant="ghost" size="sm" className="justify-start h-auto py-1">
                            <a href={order.remito_pdf_url} target="_blank" rel="noopener noreferrer">
                                <FileText className="h-3 w-3 mr-1" />
                                <span className="text-xs">Remito PDF</span>
                            </a>
                        </Button>
                    )}
                    {order.remito_firmado_url && (
                        <Button asChild variant="ghost" size="sm" className="justify-start h-auto py-1">
                            <a href={order.remito_firmado_url} target="_blank" rel="noopener noreferrer">
                                <FileText className="h-3 w-3 mr-1" />
                                <span className="text-xs">Remito Firmado</span>
                            </a>
                        </Button>
                    )}
                    {order.devolucion_url && (
                        <Button asChild variant="ghost" size="sm" className="justify-start h-auto py-1">
                            <a href={order.devolucion_url} target="_blank" rel="noopener noreferrer">
                                <FileText className="h-3 w-3 mr-1" />
                                <span className="text-xs">Devolución</span>
                            </a>
                        </Button>
                    )}
                    {!order.remito_pdf_url && !order.remito_firmado_url && (
                        <span className="text-xs text-muted-foreground">Sin documentos</span>
                    )}
                </div>
            );
        } else {
            const facturasCount = order.facturas_docs?.length || 0;
            const ocsCount = order.ordenes_compra_docs?.length || 0;
            
            if (facturasCount === 0 && ocsCount === 0) {
                return <span className="text-xs text-muted-foreground">Sin documentos fusionados</span>;
            }
            
            return (
                <div className="flex flex-col gap-1">
                    {order.facturas_docs?.map((factura, idx) => (
                        <Button 
                            key={`factura-${idx}`} 
                            asChild 
                            variant="ghost" 
                            size="sm" 
                            className="justify-start h-auto py-1"
                        >
                            <a href={factura.pdf_fusionado_url} target="_blank" rel="noopener noreferrer">
                                <FileText className="h-3 w-3 mr-1" />
                                <span className="text-xs">Factura {factura.numero_pedido || `#${idx + 1}`}</span>
                            </a>
                        </Button>
                    ))}
                    {order.ordenes_compra_docs?.map((oc, idx) => (
                        <Button 
                            key={`oc-${idx}`} 
                            asChild 
                            variant="ghost" 
                            size="sm" 
                            className="justify-start h-auto py-1"
                        >
                            <a href={oc.pdf_fusionado_url} target="_blank" rel="noopener noreferrer">
                                <Package className="h-3 w-3 mr-1" />
                                <span className="text-xs">OC {oc.numero_pedido || `#${idx + 1}`}</span>
                            </a>
                        </Button>
                    ))}
                </div>
            );
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose} modal={false}>
            <DialogContent className="max-w-6xl h-[90vh] flex flex-col p-0 overflow-hidden">
                <DialogHeader className="p-6 pb-2 shrink-0">
                    <DialogTitle>Historial de Envíos y Pedidos Cerrados</DialogTitle>
                    <DialogDescription>Consulta pedidos internos y a proveedores cerrados, con sus documentos asociados.</DialogDescription>
                </DialogHeader>
                
                <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col overflow-hidden px-6">
                    <TabsList className="flex-shrink-0 w-fit">
                        <TabsTrigger value="history">Historial de Pedidos</TabsTrigger>
                        <TabsTrigger value="summary">Resumen de Productos</TabsTrigger>
                    </TabsList>

                    <div className="px-4 py-3 flex-shrink-0 bg-muted/30 rounded-lg my-4 border flex flex-col gap-2 transition-all">
                        <div className="flex items-center justify-between">
                            <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => setShowFilters(!showFilters)} 
                                className="font-medium text-foreground -ml-2 hover:bg-transparent"
                            >
                                Filtros de Búsqueda
                                {showFilters ? <ChevronUp className="ml-2 h-4 w-4" /> : <ChevronDown className="ml-2 h-4 w-4" />}
                            </Button>
                            <Button onClick={handleExport} disabled={isDownloading || loading} size="sm" variant="outline" className="bg-background">
                                {isDownloading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Download className="mr-2 h-4 w-4" />}
                                Descargar Reporte
                            </Button>
                        </div>
                        <AnimatePresence>
                            {showFilters && (
                                <motion.div
                                    initial={{ height: 0, opacity: 0 }}
                                    animate={{ height: "auto", opacity: 1 }}
                                    exit={{ height: 0, opacity: 0 }}
                                    transition={{ duration: 0.2 }}
                                    className="overflow-hidden"
                                >
                                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end pt-2 pb-1">
                                        <div>
                                            <Label htmlFor="tipo-filter" className="mb-1 block text-xs">Tipo de Pedido</Label>
                                            <Select value={filters.tipo_pedido} onValueChange={(v) => handleFilterChange('tipo_pedido', v)}>
                                                <SelectTrigger id="tipo-filter">
                                                    <SelectValue placeholder="Tipo de pedido" />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="all">Todos</SelectItem>
                                                    <SelectItem value="interno">Internos (Sucursales)</SelectItem>
                                                    <SelectItem value="proveedor">Proveedores</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>
                                        
                                        {filters.tipo_pedido === 'proveedor' && (
                                            <div>
                                                <Label htmlFor="supplier-filter" className="mb-1 block text-xs">Proveedor</Label>
                                                <Select value={filters.supplier_id} onValueChange={(v) => handleFilterChange('supplier_id', v)}>
                                                    <SelectTrigger id="supplier-filter">
                                                        <SelectValue placeholder="Seleccionar proveedor" />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="all">Todos los Proveedores</SelectItem>
                                                        {suppliers.map(s => (
                                                            <SelectItem key={s.id} value={s.id.toString()}>{s.name}</SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        )}

                                        {userRole !== 'gerente' && (
                                            <div>
                                                <Label htmlFor="sucursal-filter" className="mb-1 block text-xs">Sucursal</Label>
                                                <Select value={filters.sucursal_id} onValueChange={(v) => handleFilterChange('sucursal_id', v)}>
                                                    <SelectTrigger id="sucursal-filter">
                                                        <SelectValue placeholder="Seleccionar sucursal" />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="all">Todas las sucursales</SelectItem>
                                                        {sucursales.map(s => <SelectItem key={s.id} value={s.id.toString()}>{s.nombre}</SelectItem>)}
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        )}
                                        <div>
                                            <Label htmlFor="date-from" className="mb-1 block text-xs">Desde</Label>
                                            <Popover>
                                                <PopoverTrigger asChild>
                                                    <Button id="date-from" variant="outline" className={cn("w-full justify-start text-left font-normal", !filters.date_from && "text-muted-foreground")}>
                                                        <CalendarIcon className="mr-2 h-4 w-4" />
                                                        {filters.date_from ? format(filters.date_from, "PPP", { locale: es }) : <span>Seleccionar fecha</span>}
                                                    </Button>
                                                </PopoverTrigger>
                                                <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={filters.date_from} onSelect={(d) => handleFilterChange('date_from', d)} initialFocus /></PopoverContent>
                                            </Popover>
                                        </div>
                                        <div>
                                            <Label htmlFor="date-to" className="mb-1 block text-xs">Hasta</Label>
                                            <Popover>
                                                <PopoverTrigger asChild>
                                                    <Button id="date-to" variant="outline" className={cn("w-full justify-start text-left font-normal", !filters.date_to && "text-muted-foreground")}>
                                                        <CalendarIcon className="mr-2 h-4 w-4" />
                                                        {filters.date_to ? format(filters.date_to, "PPP", { locale: es }) : <span>Seleccionar fecha</span>}
                                                    </Button>
                                                </PopoverTrigger>
                                                <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={filters.date_to} onSelect={(d) => handleFilterChange('date_to', d)} initialFocus /></PopoverContent>
                                            </Popover>
                                        </div>
                                    </div>
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </div>

                    <div className="flex-1 overflow-hidden pb-6">
                        {loading ? (
                            <div className="flex justify-center items-center h-full"><Loader2 className="h-8 w-8 animate-spin" /></div>
                        ) : (
                            <ScrollArea className="h-full border rounded-md bg-background">
                                <TabsContent value="history" className="m-0 min-h-[400px]">
                                    <Table>
                                        <TableHeader className="sticky top-0 bg-secondary z-10 shadow-sm">
                                            <TableRow>
                                                <TableHead className="w-[100px]">Tipo</TableHead>
                                                <TableHead>N° / ID</TableHead>
                                                <TableHead>Fecha</TableHead>
                                                <TableHead>Sucursal/Proveedor</TableHead>
                                                <TableHead>Productos</TableHead>
                                                <TableHead className="text-right">Documentos</TableHead>
                                            </TableRow>
                                        </TableHeader>
                                        <TableBody>
                                            {filteredHistory.map(order => {
                                                const isInternal = order.tipo_pedido === 'interno';
                                                return (
                                                    <TableRow key={order.id} className="hover:bg-muted/50">
                                                        <TableCell>
                                                            <Badge variant={isInternal ? "default" : "secondary"}>
                                                                {isInternal ? 'Interno' : 'Proveedor'}
                                                            </Badge>
                                                        </TableCell>
                                                        <TableCell className="font-mono text-xs">
                                                            {isInternal 
                                                                ? (order.remito_numero ? String(order.remito_numero).padStart(6, '0') : '-')
                                                                : (order.id?.substring(0, 8) || '-')
                                                            }
                                                        </TableCell>
                                                        <TableCell className="text-sm">
                                                            {format(new Date(order.fecha_envio || order.fecha_pedido), 'dd/MM/yyyy')}
                                                        </TableCell>
                                                        <TableCell>
                                                            {isInternal 
                                                                ? order.sucursales?.nombre || '-'
                                                                : order.suppliers?.name || '-'
                                                            }
                                                        </TableCell>
                                                        <TableCell>
                                                            <ul className="list-disc list-inside text-xs max-w-[250px]">
                                                                {order.productos?.filter(p => {
                                                                    const qty = isInternal ? p.cantidad_enviada : p.cantidad;
                                                                    return qty > 0;
                                                                }).map(p => {
                                                                    const qty = isInternal ? p.cantidad_enviada : p.cantidad;
                                                                    return (
                                                                        <li key={p.producto_id} className="truncate">
                                                                            {productosMap[p.producto_id]?.nombre}: {qty}
                                                                        </li>
                                                                    );
                                                                })}
                                                            </ul>
                                                        </TableCell>
                                                        <TableCell className="text-right">
                                                            {renderDocuments(order)}
                                                        </TableCell>
                                                    </TableRow>
                                                );
                                            })}
                                        </TableBody>
                                    </Table>
                                    {filteredHistory.length === 0 && (
                                        <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
                                            <Package className="h-10 w-10 mb-2 opacity-20" />
                                            <p>No hay pedidos cerrados que coincidan con los filtros.</p>
                                        </div>
                                    )}
                                </TabsContent>
                                
                                <TabsContent value="summary" className="m-0 min-h-[400px]">
                                    <Table>
                                        <TableHeader className="sticky top-0 bg-secondary z-10 shadow-sm">
                                            <TableRow>
                                                <TableHead>Producto</TableHead>
                                                <TableHead>Unidad</TableHead>
                                                <TableHead>Cantidad Total</TableHead>
                                                <TableHead>Pedidos Internos</TableHead>
                                                <TableHead>Pedidos Proveedor</TableHead>
                                                <TableHead>Total Pedidos</TableHead>
                                            </TableRow>
                                        </TableHeader>
                                        <TableBody>
                                            {productSummary.map(item => (
                                                <TableRow key={item.producto_id} className="hover:bg-muted/50">
                                                    <TableCell className="font-medium">{item.nombre}</TableCell>
                                                    <TableCell>{item.unidad_medida}</TableCell>
                                                    <TableCell className="font-semibold text-primary">{item.total_enviado}</TableCell>
                                                    <TableCell>{item.pedidos_internos}</TableCell>
                                                    <TableCell>{item.pedidos_proveedor}</TableCell>
                                                    <TableCell>{item.pedidos_internos + item.pedidos_proveedor}</TableCell>
                                                </TableRow>
                                            ))}
                                        </TableBody>
                                    </Table>
                                    {productSummary.length === 0 && (
                                        <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
                                            <Package className="h-10 w-10 mb-2 opacity-20" />
                                            <p>No hay productos que coincidan con los filtros.</p>
                                        </div>
                                    )}
                                </TabsContent>
                            </ScrollArea>
                        )}
                    </div>
                </Tabs>
            </DialogContent>
        </Dialog>
    );
};

export default ShipmentHistoryDialog;