import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, Save, Calendar as CalendarIcon } from 'lucide-react';

const ModifyOrderDialog = ({ order, isOpen, onClose, onOrderManaged, productosMap }) => {
    const { toast } = useToast();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [modifiedProducts, setModifiedProducts] = useState([]);
    const [shippingDate, setShippingDate] = useState('');
    const [hasChanges, setHasChanges] = useState(false);

    useEffect(() => {
        if (order) {
            setModifiedProducts(order.productos.map(p => ({
                ...p,
                cantidad_enviada: p.cantidad_enviada || 0,
            })));
            
            const dateToSet = order.fecha_envio ? new Date(order.fecha_envio) : new Date();
            dateToSet.setMinutes(dateToSet.getMinutes() - dateToSet.getTimezoneOffset());
            setShippingDate(dateToSet.toISOString().split('T')[0]);
            setHasChanges(false);
        }
    }, [order]);

    const handleProductQuantityChange = (producto_id, cantidad_enviada) => {
        const originalProduct = order.productos.find(p => p.producto_id === producto_id);
        const requestedQuantity = originalProduct.cantidad;
        
        let finalQuantity = parseInt(cantidad_enviada, 10);
        if (isNaN(finalQuantity) || finalQuantity < 0) {
            finalQuantity = 0;
        } else if (finalQuantity > requestedQuantity) {
            finalQuantity = requestedQuantity;
            toast({
                variant: 'destructive',
                title: 'Cantidad excedida',
                description: `No puedes enviar más de la cantidad solicitada (${requestedQuantity}).`
            });
        }

        setModifiedProducts(modifiedProducts.map(p =>
            p.producto_id === producto_id ? { ...p, cantidad_enviada: finalQuantity } : p
        ));
        setHasChanges(true);
    };

    const handleDateChange = (e) => {
        setShippingDate(e.target.value);
        setHasChanges(true);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!shippingDate) {
            toast({ variant: 'destructive', title: 'Error', description: 'Por favor, selecciona una fecha de envío.' });
            return;
        }
        setIsSubmitting(true);

        try {
            // 1. Update the order with new products and date
            const { error: updateError } = await supabase
                .from('pedidos_centralizada')
                .update({
                    productos: modifiedProducts,
                    fecha_envio: new Date(shippingDate).toISOString(),
                })
                .eq('id', order.id);

            if (updateError) throw updateError;

            // 2. Call edge function to regenerate remito
            const { data, error: functionError } = await supabase.functions.invoke('regenerate-remito', {
                body: { orderId: order.id },
            });

            if (functionError) {
                // Log the error but don't block the user, as the main data was updated.
                console.error("Error regenerating remito:", functionError);
                toast({ variant: 'destructive', title: 'Advertencia', description: 'Pedido actualizado, pero no se pudo regenerar el remito. Contacte a soporte.' });
            } else if (data && !data.success) {
                console.error("Failed to regenerate remito:", data.error);
                toast({ variant: 'destructive', title: 'Advertencia', description: `Pedido actualizado, pero falló la regeneración del remito: ${data.error}` });
            } else {
                toast({ title: 'Éxito', description: 'Pedido modificado y remito regenerado correctamente.' });
            }

            onOrderManaged();
            onClose();
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: `No se pudo modificar el pedido: ${error.message}` });
        } finally {
            setIsSubmitting(false);
        }
    };

    if (!order) return null;

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-2xl max-h-[90vh] flex flex-col">
                <DialogHeader className="flex-shrink-0">
                    <DialogTitle>Modificar Pedido Confirmado</DialogTitle>
                    <DialogDescription>
                        Ajusta las cantidades y/o la fecha de envío. El remito se regenerará automáticamente.
                    </DialogDescription>
                </DialogHeader>
                <div className="flex-grow overflow-y-auto pr-6 space-y-4">
                    <form onSubmit={handleSubmit} className="flex flex-col h-full">
                        <div className="space-y-4 flex-grow">
                            <div className="space-y-2">
                                <Label htmlFor="shippingDate" className="flex items-center">
                                    <CalendarIcon className="mr-2 h-4 w-4" />
                                    Fecha de Envío
                                </Label>
                                <Input
                                    id="shippingDate"
                                    type="date"
                                    value={shippingDate}
                                    onChange={handleDateChange}
                                    className="w-full"
                                    required
                                />
                            </div>
                            <div className="space-y-2">
                                <Label>Productos a Enviar</Label>
                                {modifiedProducts.map(p => (
                                    <div key={p.producto_id} className="flex items-center justify-between gap-4 p-2 border rounded-md">
                                        <div className="flex-1">
                                            <p className="font-medium">{productosMap[p.producto_id]?.nombre || 'Producto desconocido'}</p>
                                            <p className="text-sm text-muted-foreground">Solicitado: {p.cantidad} {productosMap[p.producto_id]?.unidad_medida}</p>
                                        </div>
                                        <div className="w-32">
                                            <Label htmlFor={`sent-${p.producto_id}`} className="text-xs">Cantidad a enviar</Label>
                                            <Input
                                                id={`sent-${p.producto_id}`}
                                                type="number"
                                                min="0"
                                                max={p.cantidad}
                                                value={p.cantidad_enviada}
                                                onChange={(e) => handleProductQuantityChange(p.producto_id, e.target.value)}
                                            />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                        <DialogFooter className="pt-4 flex-shrink-0 sticky bottom-0 bg-card pb-0 pr-0">
                            <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
                            <Button type="submit" disabled={isSubmitting || !hasChanges}>
                                {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                                Guardar Cambios
                            </Button>
                        </DialogFooter>
                    </form>
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default ModifyOrderDialog;