import React from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Edit, Trash2, PackageSearch } from 'lucide-react';

    const SupplierList = ({ suppliers, onEdit, onDelete, isLoading }) => {

      if (isLoading) {
        return (
          <div className="flex justify-center items-center py-10">
            <PackageSearch className="w-12 h-12 text-primary animate-pulse" />
            <p className="ml-4 text-lg text-muted-foreground">Cargando proveedores...</p>
          </div>
        );
      }

      if (!suppliers || suppliers.length === 0) {
        return (
          <div className="text-center py-10">
            <PackageSearch className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <p className="text-xl text-muted-foreground">No hay proveedores registrados.</p>
            <p className="text-sm text-muted-foreground">Intente agregar uno nuevo.</p>
          </div>
        );
      }

      return (
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow>
                <TableHead className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Nombre</TableHead>
                <TableHead className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">CUIT</TableHead>
                <TableHead className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Contacto</TableHead>
                <TableHead className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody className="divide-y divide-border">
              {suppliers.map((supplier, index) => (
                <motion.tr
                  key={supplier.id}
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                  className="hover:bg-muted/30"
                >
                  <TableCell className="px-6 py-4 whitespace-nowrap text-sm font-medium">{supplier.name}</TableCell>
                  <TableCell className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">{supplier.cuit}</TableCell>
                  <TableCell className="px-6 py-4 whitespace-nowrap text-sm text-muted-foreground">{supplier.contact_person || '-'}</TableCell>
                  <TableCell className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    <Button variant="outline" size="sm" onClick={() => onEdit(supplier)} className="text-primary border-primary hover:bg-primary hover:text-primary-foreground">
                      <Edit className="w-4 h-4 mr-1" /> Editar
                    </Button>
                    <Button variant="destructive" size="sm" onClick={() => onDelete(supplier.id)}>
                      <Trash2 className="w-4 h-4 mr-1" /> Eliminar
                    </Button>
                  </TableCell>
                </motion.tr>
              ))}
            </TableBody>
          </Table>
        </div>
      );
    };

    export default SupplierList;