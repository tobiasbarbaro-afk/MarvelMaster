import React, { useState, useEffect } from 'react';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { supabase } from '@/lib/supabaseClient';
    import { useToast } from '@/components/ui/use-toast';

    const SupplierFormDialog = ({ open, onOpenChange, supplier, onSave }) => {
      const [formData, setFormData] = useState({
        name: '',
        cuit: '',
        contact_person: '',
      });
      const [errors, setErrors] = useState({});
      const [isSaving, setIsSaving] = useState(false);
      const { toast } = useToast();

      useEffect(() => {
        if (supplier) {
          setFormData({
            name: supplier.name || '',
            cuit: supplier.cuit || '',
            contact_person: supplier.contact_person || '',
          });
        } else {
          setFormData({
            name: '',
            cuit: '',
            contact_person: '',
          });
        }
        setErrors({});
      }, [supplier, open]);

      const validateCuit = (cuit) => {
        if (!cuit) return "El CUIT es requerido.";
        if (!/^\d+$/.test(cuit)) return "El CUIT debe ser numérico.";
        if (cuit.length < 11 || cuit.length > 11) return "El CUIT debe tener 11 dígitos.";
        return "";
      };
      
      const validateForm = () => {
        const newErrors = {};
        if (!formData.name.trim()) newErrors.name = "El nombre es requerido.";
        
        const cuitError = validateCuit(formData.cuit);
        if (cuitError) newErrors.cuit = cuitError;
        
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
      };

      const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
        if (errors[name]) {
          setErrors(prev => ({ ...prev, [name]: null }));
        }
      };

      const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validateForm()) return;

        setIsSaving(true);
        const dataToSave = {
          name: formData.name,
          cuit: formData.cuit,
          contact_person: formData.contact_person,
        };

        let result;
        if (supplier && supplier.id) {
          result = await supabase
            .from('suppliers')
            .update(dataToSave)
            .eq('id', supplier.id)
            .select();
        } else {
          result = await supabase
            .from('suppliers')
            .insert(dataToSave)
            .select();
        }

        setIsSaving(false);
        if (result.error) {
          toast({
            variant: "destructive",
            title: "Error al guardar",
            description: result.error.message,
          });
        } else {
          toast({
            title: "Éxito",
            description: `Proveedor ${supplier ? 'actualizado' : 'creado'} correctamente.`,
          });
          onSave(result.data[0]);
          onOpenChange(false);
        }
      };

      return (
        <Dialog open={open} onOpenChange={onOpenChange}>
          <DialogContent className="sm:max-w-[425px] bg-card border-border">
            <DialogHeader>
              <DialogTitle className="text-primary">{supplier ? 'Editar Proveedor' : 'Agregar Nuevo Proveedor'}</DialogTitle>
              <DialogDescription>
                {supplier ? 'Modifique los datos del proveedor.' : 'Complete los datos para agregar un nuevo proveedor.'}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="grid gap-4 py-4">
              <div>
                <Label htmlFor="name" className="text-foreground">Nombre</Label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="mt-1 bg-input border-border focus:border-primary"
                  disabled={isSaving}
                />
                {errors.name && <p className="text-sm text-destructive mt-1">{errors.name}</p>}
              </div>
              <div>
                <Label htmlFor="cuit" className="text-foreground">CUIT (solo números, 11 dígitos)</Label>
                <Input
                  id="cuit"
                  name="cuit"
                  value={formData.cuit}
                  onChange={handleChange}
                  className="mt-1 bg-input border-border focus:border-primary"
                  disabled={isSaving}
                  maxLength={11}
                />
                {errors.cuit && <p className="text-sm text-destructive mt-1">{errors.cuit}</p>}
              </div>
              <div>
                <Label htmlFor="contact_person" className="text-foreground">Contacto (Persona/Email/Tel)</Label>
                <Input
                  id="contact_person"
                  name="contact_person"
                  value={formData.contact_person}
                  onChange={handleChange}
                  className="mt-1 bg-input border-border focus:border-primary"
                  disabled={isSaving}
                />
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isSaving}>
                  Cancelar
                </Button>
                <Button type="submit" className="bg-primary hover:bg-primary/90" disabled={isSaving}>
                  {isSaving ? (supplier ? 'Guardando Cambios...' : 'Creando Proveedor...') : (supplier ? 'Guardar Cambios' : 'Crear Proveedor')}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      );
    };

    export default SupplierFormDialog;