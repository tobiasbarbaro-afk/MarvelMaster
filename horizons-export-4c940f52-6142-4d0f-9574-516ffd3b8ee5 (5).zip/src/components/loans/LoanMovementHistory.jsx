import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { format } from 'date-fns';
import { Loader2 } from 'lucide-react';

const LoanMovementHistory = ({ loanId }) => {
    const [movements, setMovements] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!loanId) return;

        const fetchMovements = async () => {
            setLoading(true);
            const { data, error } = await supabase
                .from('movimientos_prestamos')
                .select('*')
                .eq('prestamo_id', loanId)
                .order('fecha', { ascending: false });

            if (error) {
                console.error("Error fetching movements:", error);
            } else {
                setMovements(data || []);
            }
            setLoading(false);
        };

        fetchMovements();
    }, [loanId]);

    if (loading) {
        return <div className="flex justify-center p-4"><Loader2 className="animate-spin h-6 w-6 text-primary" /></div>;
    }

    if (movements.length === 0) {
        return <div className="text-center p-4 text-muted-foreground">No hay movimientos registrados.</div>;
    }

    return (
        <div className="overflow-x-auto">
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Fecha</TableHead>
                        <TableHead>Tipo</TableHead>
                        <TableHead className="text-right">Monto</TableHead>
                        <TableHead className="text-right">Saldo Anterior</TableHead>
                        <TableHead className="text-right">Saldo Nuevo</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {movements.map((mov) => (
                        <TableRow key={mov.id}>
                            <TableCell>{format(new Date(mov.fecha), 'dd/MM/yyyy HH:mm')}</TableCell>
                            <TableCell className="capitalize">{mov.tipo_movimiento}</TableCell>
                            <TableCell className="text-right">${parseFloat(mov.monto).toLocaleString('es-AR', {minimumFractionDigits: 2})}</TableCell>
                            <TableCell className="text-right">${parseFloat(mov.saldo_anterior).toLocaleString('es-AR', {minimumFractionDigits: 2})}</TableCell>
                            <TableCell className="text-right font-medium">${parseFloat(mov.saldo_nuevo).toLocaleString('es-AR', {minimumFractionDigits: 2})}</TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </div>
    );
};

export default LoanMovementHistory;