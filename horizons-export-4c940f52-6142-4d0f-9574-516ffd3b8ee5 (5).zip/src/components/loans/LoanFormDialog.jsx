import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Plus, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { getTodayDateISO } from '@/lib/sheetUtils';

const LoanFormDialog = ({ branchId, onLoanCreated }) => {
    const [open, setOpen] = useState(false);
    const [employees, setEmployees] = useState([]);
    const [loading, setLoading] = useState(false);
    const [submitting, setSubmitting] = useState(false);
    const { toast } = useToast();
    const { user } = useAuth();

    const [formData, setFormData] = useState({
        empleado_id: '',
        monto_total: '',
        tipo: 'efectivo'
    });

    useEffect(() => {
        if (open && branchId) {
            fetchEmployees();
        }
    }, [open, branchId]);

    const fetchEmployees = async () => {
        setLoading(true);
        const { data, error } = await supabase
            .from('empleados')
            .select('id, nombre_completo')
            .eq('sucursal_id', branchId)
            .order('nombre_completo');
        
        if (error) {
            toast({ variant: 'destructive', title: 'Error', description: 'No se pudieron cargar los empleados.' });
        } else {
            setEmployees(data || []);
        }
        setLoading(false);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (!formData.empleado_id || !formData.monto_total || parseFloat(formData.monto_total) <= 0) {
            toast({ variant: 'destructive', title: 'Error', description: 'Complete todos los campos correctamente.' });
            return;
        }

        setSubmitting(true);
        const monto = parseFloat(formData.monto_total);

        try {
            // 1. Insert Prestamo
            const { data: prestamoData, error: prestamoError } = await supabase
                .from('prestamos_empleados')
                .insert([{
                    empleado_id: formData.empleado_id,
                    sucursal_id: parseInt(branchId),
                    monto_total: monto,
                    tipo: formData.tipo,
                    saldo_actual: monto
                }])
                .select()
                .single();

            if (prestamoError) throw prestamoError;

            // 2. Insert Movimiento
            const { error: movError } = await supabase
                .from('movimientos_prestamos')
                .insert([{
                    prestamo_id: prestamoData.id,
                    tipo_movimiento: 'nuevo',
                    monto: monto,
                    saldo_anterior: 0,
                    saldo_nuevo: monto
                }]);

            if (movError) throw movError;

            // 3. Deduct from Safebox if Efectivo
            if (formData.tipo === 'efectivo') {
                const empName = employees.find(e => e.id === formData.empleado_id)?.nombre_completo || 'Empleado';
                const { error: safeBoxError } = await supabase
                    .from('entradas_diarias')
                    .insert([{
                        fecha: getTodayDateISO(),
                        monto: monto,
                        ioe: 'E',
                        tipo_ioe: 'Préstamo a Empleado',
                        razon_social: empName,
                        observaciones: 'Préstamo nuevo generado en el sistema.',
                        haber: monto,
                        debe: 0,
                        sucursal_id: parseInt(branchId),
                        usuario_email: user.email,
                        verificado: true // Automatically verified based on system logic
                    }]);
                
                if (safeBoxError) throw safeBoxError;
            }

            toast({ title: 'Éxito', description: 'Préstamo registrado correctamente.' });
            setOpen(false);
            setFormData({ empleado_id: '', monto_total: '', tipo: 'efectivo' });
            if (onLoanCreated) onLoanCreated();

        } catch (error) {
            console.error("Error creating loan:", error);
            toast({ variant: 'destructive', title: 'Error', description: error.message || 'Error al procesar el préstamo.' });
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
                <Button disabled={!branchId}>
                    <Plus className="mr-2 h-4 w-4" /> Nuevo Préstamo
                </Button>
            </DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Registrar Nuevo Préstamo</DialogTitle>
                    <DialogDescription>
                        Complete los detalles del préstamo. Si es en efectivo, se registrará un egreso automático en la caja fuerte.
                    </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                    <div className="space-y-2">
                        <Label>Empleado</Label>
                        <Select 
                            value={formData.empleado_id} 
                            onValueChange={(val) => setFormData({...formData, empleado_id: val})}
                            disabled={loading || submitting}
                        >
                            <SelectTrigger>
                                <SelectValue placeholder={loading ? "Cargando..." : "Seleccione empleado"} />
                            </SelectTrigger>
                            <SelectContent>
                                {employees.map(emp => (
                                    <SelectItem key={emp.id} value={emp.id}>{emp.nombre_completo}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="space-y-2">
                        <Label>Monto Total ($)</Label>
                        <Input 
                            type="number" 
                            min="0.01" 
                            step="0.01" 
                            value={formData.monto_total}
                            onChange={(e) => setFormData({...formData, monto_total: e.target.value})}
                            placeholder="Ej: 50000"
                            required
                            disabled={submitting}
                        />
                    </div>

                    <div className="space-y-2 pt-2">
                        <Label>Tipo de Entrega</Label>
                        <RadioGroup 
                            value={formData.tipo} 
                            onValueChange={(val) => setFormData({...formData, tipo: val})}
                            className="flex space-x-4"
                            disabled={submitting}
                        >
                            <div className="flex items-center space-x-2">
                                <RadioGroupItem value="efectivo" id="efectivo" />
                                <Label htmlFor="efectivo">Efectivo</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                                <RadioGroupItem value="transferencia" id="transferencia" />
                                <Label htmlFor="transferencia">Transferencia</Label>
                            </div>
                        </RadioGroup>
                    </div>

                    <Button type="submit" className="w-full" disabled={submitting}>
                        {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        {submitting ? 'Guardando...' : 'Registrar Préstamo'}
                    </Button>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default LoanFormDialog;