import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Eye } from 'lucide-react';
import LoanMovementHistory from './LoanMovementHistory';
import { format } from 'date-fns';

const LoanDetailsDialog = ({ loan }) => {
    if (!loan) return null;

    return (
        <Dialog>
            <DialogTrigger asChild>
                <Button variant="ghost" size="sm">
                    <Eye className="h-4 w-4 mr-2" />
                    Ver Detalles
                </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl">
                <DialogHeader>
                    <DialogTitle>Detalles del Préstamo</DialogTitle>
                    <DialogDescription>
                        Historial de movimientos e información del préstamo para {loan.empleados?.nombre_completo}.
                    </DialogDescription>
                </DialogHeader>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 bg-muted/30 p-4 rounded-lg">
                    <div>
                        <p className="text-sm text-muted-foreground">Monto Total</p>
                        <p className="font-semibold">${parseFloat(loan.monto_total).toLocaleString('es-AR', {minimumFractionDigits: 2})}</p>
                    </div>
                    <div>
                        <p className="text-sm text-muted-foreground">Saldo Actual</p>
                        <p className={`font-bold ${loan.saldo_actual > 0 ? 'text-orange-500' : 'text-green-500'}`}>
                            ${parseFloat(loan.saldo_actual).toLocaleString('es-AR', {minimumFractionDigits: 2})}
                        </p>
                    </div>
                    <div>
                        <p className="text-sm text-muted-foreground">Tipo</p>
                        <p className="capitalize font-medium">{loan.tipo}</p>
                    </div>
                    <div>
                        <p className="text-sm text-muted-foreground">Fecha Creación</p>
                        <p className="font-medium">{format(new Date(loan.fecha_creacion), 'dd/MM/yyyy')}</p>
                    </div>
                </div>

                <div className="mt-4">
                    <h3 className="text-lg font-semibold mb-2">Historial de Movimientos</h3>
                    <LoanMovementHistory loanId={loan.id} />
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default LoanDetailsDialog;