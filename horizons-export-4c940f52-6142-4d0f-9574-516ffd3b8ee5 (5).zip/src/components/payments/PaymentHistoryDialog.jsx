import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Loader2, Download, Calendar as CalendarIcon, FileText, ExternalLink } from 'lucide-react';
import { format, startOfMonth, endOfMonth } from 'date-fns';
import { es } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { useToast } from '@/components/ui/use-toast';

const PaymentHistoryDialog = ({ isOpen, onClose }) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [payments, setPayments] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  
  // Filters
  const [filters, setFilters] = useState({
    proveedor_id: 'all',
    date_from: startOfMonth(new Date()),
    date_to: endOfMonth(new Date())
  });

  // Fetch suppliers on mount
  useEffect(() => {
    const fetchSuppliers = async () => {
      const { data } = await supabase.from('suppliers').select('*').order('name');
      if (data) setSuppliers(data);
    };
    fetchSuppliers();
  }, []);

  // Fetch payments when open or filters change
  useEffect(() => {
    if (!isOpen) return;

    const fetchPayments = async () => {
      setLoading(true);
      try {
        let query = supabase
          .from('pagos_proveedores')
          .select(`
            *,
            suppliers (
              name
            )
          `)
          .order('fecha', { ascending: false });

        if (filters.proveedor_id !== 'all') {
          query = query.eq('proveedor_id', filters.proveedor_id);
        }

        if (filters.date_from) {
          query = query.gte('fecha', format(filters.date_from, 'yyyy-MM-dd'));
        }

        if (filters.date_to) {
          query = query.lte('fecha', format(filters.date_to, 'yyyy-MM-dd'));
        }

        const { data, error } = await query;

        if (error) throw error;
        setPayments(data || []);

      } catch (error) {
        console.error('Error fetching payments:', error);
        toast({
          variant: 'destructive',
          title: 'Error',
          description: 'No se pudo cargar el historial de pagos.'
        });
      } finally {
        setLoading(false);
      }
    };

    fetchPayments();
  }, [isOpen, filters, toast]);

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const clearFilters = () => {
    setFilters({
      proveedor_id: 'all',
      date_from: null,
      date_to: null
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Historial de Pagos a Proveedores</DialogTitle>
          <DialogDescription>
            Consulta y descarga los comprobantes de pagos realizados.
          </DialogDescription>
        </DialogHeader>

        {/* Filters Section */}
        <div className="flex flex-wrap gap-4 items-end bg-muted/30 p-4 rounded-lg">
          <div className="space-y-1 min-w-[200px]">
            <Label>Proveedor</Label>
            <Select 
              value={filters.proveedor_id} 
              onValueChange={(val) => handleFilterChange('proveedor_id', val)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Todos" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los proveedores</SelectItem>
                {suppliers.map(s => (
                  <SelectItem key={s.id} value={s.id.toString()}>{s.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1">
            <Label>Desde</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn("w-[180px] justify-start text-left font-normal", !filters.date_from && "text-muted-foreground")}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {filters.date_from ? format(filters.date_from, "P", { locale: es }) : <span>Seleccionar</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar mode="single" selected={filters.date_from} onSelect={(d) => handleFilterChange('date_from', d)} initialFocus />
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-1">
            <Label>Hasta</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn("w-[180px] justify-start text-left font-normal", !filters.date_to && "text-muted-foreground")}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {filters.date_to ? format(filters.date_to, "P", { locale: es }) : <span>Seleccionar</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar mode="single" selected={filters.date_to} onSelect={(d) => handleFilterChange('date_to', d)} initialFocus />
              </PopoverContent>
            </Popover>
          </div>

          <Button variant="ghost" onClick={clearFilters} className="mb-0.5">
            Limpiar Filtros
          </Button>
        </div>

        {/* Table Section */}
        <div className="flex-grow overflow-auto border rounded-md">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Fecha</TableHead>
                <TableHead>Proveedor</TableHead>
                <TableHead>Monto</TableHead>
                <TableHead>Adjuntos</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={4} className="h-24 text-center">
                    <Loader2 className="h-6 w-6 animate-spin mx-auto" />
                  </TableCell>
                </TableRow>
              ) : payments.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="h-24 text-center text-muted-foreground">
                    No se encontraron pagos con los filtros seleccionados.
                  </TableCell>
                </TableRow>
              ) : (
                payments.map((payment) => (
                  <TableRow key={payment.id}>
                    <TableCell>{format(new Date(payment.fecha), 'dd/MM/yyyy')}</TableCell>
                    <TableCell>{payment.suppliers?.name || 'Desconocido'}</TableCell>
                    <TableCell className="font-medium">
                      ${payment.monto?.toLocaleString('es-AR', { minimumFractionDigits: 2 })}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2 flex-wrap">
                        {payment.archivos_urls && payment.archivos_urls.length > 0 ? (
                          payment.archivos_urls.map((url, index) => (
                            <Button
                              key={index}
                              variant="outline"
                              size="sm"
                              className="h-8 px-2"
                              asChild
                            >
                              <a href={url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1">
                                <FileText className="h-3 w-3" />
                                <span className="text-xs">Archivo {index + 1}</span>
                              </a>
                            </Button>
                          ))
                        ) : (
                          <span className="text-muted-foreground text-xs italic">Sin adjuntos</span>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default PaymentHistoryDialog;