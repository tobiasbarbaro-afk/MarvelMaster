import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Calendar as CalendarIcon, Upload, Loader2, X } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { cn } from '@/lib/utils';

const PaymentRegistrationForm = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [suppliers, setSuppliers] = useState([]);
  const [files, setFiles] = useState([]);
  const fileInputRef = useRef(null);

  // Form State
  const [date, setDate] = useState(new Date());
  const [supplierId, setSupplierId] = useState('');
  const [amount, setAmount] = useState('');

  // Fetch suppliers on mount
  useEffect(() => {
    const fetchSuppliers = async () => {
      try {
        const { data, error } = await supabase
          .from('suppliers')
          .select('id, name')
          .order('name');
        
        if (error) throw error;
        setSuppliers(data || []);
      } catch (error) {
        console.error('Error fetching suppliers:', error);
        toast({
          variant: 'destructive',
          title: 'Error',
          description: 'No se pudieron cargar los proveedores.',
        });
      }
    };

    fetchSuppliers();
  }, [toast]);

  const handleFileChange = (e) => {
    const selectedFiles = Array.from(e.target.files);
    
    // Check file count limit (max 2)
    if (files.length + selectedFiles.length > 2) {
      toast({
        variant: 'destructive',
        title: 'Límite de archivos',
        description: 'Solo puedes subir un máximo de 2 archivos.',
      });
      return;
    }

    // Check file types (images or PDF)
    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
    const invalidFiles = selectedFiles.filter(file => !validTypes.includes(file.type));

    if (invalidFiles.length > 0) {
      toast({
        variant: 'destructive',
        title: 'Formato inválido',
        description: 'Solo se permiten imágenes (JPG, PNG) o PDF.',
      });
      return;
    }

    setFiles(prev => [...prev, ...selectedFiles]);
    // Reset input so same file can be selected again if needed after removal
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeFile = (index) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const uploadFiles = async () => {
    const uploadPromises = files.map(async (file) => {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2, 15)}_${Date.now()}.${fileExt}`;
      const filePath = `${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('pagos-proveedores')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('pagos-proveedores')
        .getPublicUrl(filePath);

      return publicUrl;
    });

    return Promise.all(uploadPromises);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!user) {
      toast({
        variant: 'destructive',
        title: 'Error de sesión',
        description: 'Debes iniciar sesión para registrar pagos.',
      });
      return;
    }

    if (!date) {
      toast({
        variant: 'destructive',
        title: 'Fecha requerida',
        description: 'Por favor selecciona una fecha.',
      });
      return;
    }

    if (!supplierId) {
      toast({
        variant: 'destructive',
        title: 'Proveedor requerido',
        description: 'Por favor selecciona un proveedor.',
      });
      return;
    }

    if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
      toast({
        variant: 'destructive',
        title: 'Monto inválido',
        description: 'Por favor ingresa un monto válido.',
      });
      return;
    }

    setLoading(true);
    try {
      // Upload files first
      let uploadedUrls = [];
      if (files.length > 0) {
        uploadedUrls = await uploadFiles();
      }

      // Insert payment record
      const { error } = await supabase.from('pagos_proveedores').insert({
        fecha: format(date, 'yyyy-MM-dd'),
        proveedor_id: parseInt(supplierId),
        monto: parseFloat(amount),
        archivos_urls: uploadedUrls,
        creado_por: user.id
      });

      if (error) throw error;

      toast({
        title: 'Pago registrado',
        description: 'El pago se ha guardado correctamente.',
      });

      // Reset form
      setDate(new Date());
      setSupplierId('');
      setAmount('');
      setFiles([]);

    } catch (error) {
      console.error('Error submitting payment:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: `No se pudo registrar el pago: ${error.message}`,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto shadow-md">
      <CardHeader>
        <CardTitle>Registrar Nuevo Pago</CardTitle>
        <CardDescription>Ingresa los detalles del pago realizado al proveedor.</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Fecha */}
            <div className="flex flex-col space-y-2">
              <Label>Fecha del Pago</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant={"outline"}
                    className={cn(
                      "w-full pl-3 text-left font-normal",
                      !date && "text-muted-foreground"
                    )}
                  >
                    {date ? (
                      format(date, "PPP", { locale: es })
                    ) : (
                      <span>Selecciona una fecha</span>
                    )}
                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    disabled={(d) =>
                      d > new Date() || d < new Date("1900-01-01")
                    }
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            {/* Proveedor */}
            <div className="flex flex-col space-y-2">
              <Label>Proveedor</Label>
              <Select onValueChange={setSupplierId} value={supplierId}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona un proveedor" />
                </SelectTrigger>
                <SelectContent>
                  {suppliers.map((supplier) => (
                    <SelectItem key={supplier.id} value={supplier.id.toString()}>
                      {supplier.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Monto */}
          <div className="flex flex-col space-y-2">
            <Label htmlFor="monto">Monto ($)</Label>
            <Input 
              id="monto"
              type="number" 
              step="0.01" 
              placeholder="0.00" 
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="text-lg"
            />
          </div>

          {/* Archivos */}
          <div className="space-y-2">
            <Label>Comprobantes (Máx. 2)</Label>
            <div className="flex items-center gap-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
                disabled={files.length >= 2}
              >
                <Upload className="mr-2 h-4 w-4" />
                Subir Archivos
              </Button>
              <input
                type="file"
                ref={fileInputRef}
                className="hidden"
                onChange={handleFileChange}
                accept="image/jpeg,image/png,image/webp,application/pdf"
                multiple
              />
              <span className="text-sm text-muted-foreground">
                {files.length} / 2 seleccionados
              </span>
            </div>
            
            {files.length > 0 && (
              <div className="flex flex-col gap-2 mt-2">
                {files.map((file, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-muted rounded-md text-sm">
                    <span className="truncate max-w-[200px] md:max-w-xs">{file.name}</span>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeFile(index)}
                      className="h-6 w-6 p-0 text-destructive hover:text-destructive/80"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Guardando...
              </>
            ) : (
              'Registrar Pago'
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default PaymentRegistrationForm;