import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';

const ProtectedProviderOrdersRoute = ({ children }) => {
  const { userRole, isAuthenticated, loading } = useAuth();
  
  if (loading) {
      return (
          <div className="flex items-center justify-center h-screen bg-background">
              <div className="text-primary text-xl">Cargando...</div>
          </div>
      );
  }

  if (!isAuthenticated) {
      return <Navigate to="/login" replace />;
  }

  const allowedRoles = ['admin', 'centralizada', 'gerente', 'cocina'];
  
  if (!allowedRoles.includes(userRole)) {
      return <Navigate to="/" replace />;
  }

  return children ? children : <Outlet />;
};

export default ProtectedProviderOrdersRoute;