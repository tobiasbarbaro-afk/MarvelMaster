import React, { useState, useEffect } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
    import { Loader2 } from 'lucide-react';

    const BranchFormDialog = ({ isOpen, onOpenChange, onSubmit, initialData, isSubmitting }) => {
      const [branchName, setBranchName] = useState('');
      const [branchAddress, setBranchAddress] = useState('');
      const [initialBalance, setInitialBalance] = useState('');
      const [initialBalanceMonth, setInitialBalanceMonth] = useState('');

      useEffect(() => {
        if (isOpen) {
          if (initialData) {
            setBranchName(initialData.nombre || '');
            setBranchAddress(initialData.direccion || '');
            setInitialBalance(''); 
            setInitialBalanceMonth('');
          } else {
            setBranchName('');
            setBranchAddress('');
            setInitialBalance('');
            const now = new Date();
            const year = now.getFullYear();
            const month = (now.getMonth() + 1).toString().padStart(2, '0');
            setInitialBalanceMonth(`${year}-${month}`);
          }
        }
      }, [initialData, isOpen]);

      const handleSubmitForm = (e) => {
        e.preventDefault();
        const formData = { nombre: branchName, direccion: branchAddress };
        if (!initialData) { // Only for new branches
          formData.initial_balance = initialBalance ? parseFloat(initialBalance) : null;
          formData.initial_balance_month = initialBalanceMonth;
        }
        onSubmit(formData);
      };

      const handleClose = () => {
        onOpenChange(false);
      };

      return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
          <DialogContent className="sm:max-w-[425px] bg-card border-border">
            <DialogHeader>
              <DialogTitle className="text-primary">{initialData ? 'Editar' : 'Agregar'} Sucursal</DialogTitle>
              <DialogDescription>
                {initialData ? 'Modifica los datos de la sucursal.' : 'Completa los datos para agregar una nueva sucursal.'}
                {!initialData && " Opcionalmente, ingrese un saldo inicial."}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmitForm} className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right text-foreground">Nombre</Label>
                <Input id="name" value={branchName} onChange={(e) => setBranchName(e.target.value)} className="col-span-3 bg-background border-input" required />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="address" className="text-right text-foreground">Dirección</Label>
                <Input id="address" value={branchAddress} onChange={(e) => setBranchAddress(e.target.value)} className="col-span-3 bg-background border-input" required />
              </div>
              {!initialData && (
                <>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="initialBalance" className="text-right text-foreground col-span-1">Saldo Inicial</Label>
                    <Input 
                      id="initialBalance" 
                      type="number" 
                      step="0.01" 
                      value={initialBalance} 
                      onChange={(e) => setInitialBalance(e.target.value)} 
                      placeholder="Opcional (ej: 1000.00)"
                      className="col-span-3 bg-background border-input" 
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="initialBalanceMonth" className="text-right text-foreground col-span-1">Mes Saldo Inicial</Label>
                    <Input 
                      id="initialBalanceMonth" 
                      type="month" 
                      value={initialBalanceMonth} 
                      onChange={(e) => setInitialBalanceMonth(e.target.value)} 
                      className="col-span-3 bg-background border-input"
                      disabled={!initialBalance} 
                    />
                  </div>
                   <p className="col-span-4 text-xs text-muted-foreground text-center">
                     El saldo inicial se registrará como el saldo final del mes ANTERIOR al mes seleccionado aquí.
                   </p>
                </>
              )}
              <DialogFooter>
                <Button type="button" variant="outline" onClick={handleClose}>Cancelar</Button>
                <Button type="submit" className="bg-primary text-primary-foreground hover:bg-primary/90" disabled={isSubmitting || (!initialData && initialBalance && !initialBalanceMonth)}>
                  {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {initialData ? 'Guardar Cambios' : 'Agregar Sucursal'}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      );
    };

    export default BranchFormDialog;