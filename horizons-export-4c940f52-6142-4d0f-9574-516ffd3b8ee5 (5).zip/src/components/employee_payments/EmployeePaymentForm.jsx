import React, { useMemo, useRef, useEffect, useState } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Loader2, Wallet, RotateCcw, Paperclip, CheckCircle, Info } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const EmployeePaymentForm = ({ payments, setPayments, isLoading, onProcess, onReset }) => {
    const { toast } = useToast();
    const topScrollRef = useRef(null);
    const bottomScrollRef = useRef(null);

    useEffect(() => {
        const handleTopScroll = () => {
            if (bottomScrollRef.current) {
                bottomScrollRef.current.scrollLeft = topScrollRef.current.scrollLeft;
            }
        };
        const handleBottomScroll = () => {
            if (topScrollRef.current) {
                topScrollRef.current.scrollLeft = bottomScrollRef.current.scrollLeft;
            }
        };

        const topEl = topScrollRef.current;
        const bottomEl = bottomScrollRef.current;

        topEl?.addEventListener('scroll', handleTopScroll);
        bottomEl?.addEventListener('scroll', handleBottomScroll);

        return () => {
            topEl?.removeEventListener('scroll', handleTopScroll);
            bottomEl?.removeEventListener('scroll', handleBottomScroll);
        };
    }, []);

    const updatePaymentRow = (index, field, value) => {
        setPayments(prev => {
            const newPayments = [...prev];
            const payment = { ...newPayments[index] };
            
            // Limit discount to max active loan balance
            if (field === 'descuento_prestamo') {
                const maxBalance = payment.prestamos_activos?.reduce((acc, p) => acc + parseFloat(p.saldo_actual), 0) || 0;
                let valNum = parseFloat(value) || 0;
                if (valNum > maxBalance) valNum = maxBalance;
                if (valNum < 0) valNum = 0;
                payment[field] = value === '' ? '' : valNum;
            } else {
                payment[field] = value;
            }
            
            const montoBase = parseFloat(payment.monto_base) || 0;
            const horas = parseFloat(payment.horas_trabajadas) || 0;
            const extras = parseFloat(payment.extras) || 0;
            const descuentos = parseFloat(payment.descuentos) || 0;
            const descuentoPrestamo = parseFloat(payment.descuento_prestamo) || 0;

            // Calculate Base Amount
            let baseAmount = 0;
            if (payment.tipo_pago === 'Por hora') {
                baseAmount = montoBase * horas;
            } else {
                baseAmount = montoBase;
            }

            // Calculate Total Expected (Including standard discounts and loan discounts)
            const totalAPagar = baseAmount + extras - descuentos - descuentoPrestamo;
            payment.total_a_pagar = totalAPagar < 0 ? 0 : totalAPagar;

            // Auto-calculate Efectivo
            if (['horas_trabajadas', 'extras', 'descuentos', 'descuento_prestamo'].includes(field)) {
                payment.efectivo = payment.total_a_pagar > 0 ? payment.total_a_pagar.toString() : "";
            }

            newPayments[index] = payment;
            return newPayments;
        });
    };

    const handleReceiptChange = (index, file) => {
        if (file && (file.type === 'application/pdf' || file.type.startsWith('image/'))) {
            setPayments(prev => {
                const newPayments = [...prev];
                newPayments[index] = { ...newPayments[index], recibo: file, recibo_nombre: file.name };
                return newPayments;
            });
        } else {
            toast({ variant: 'destructive', title: 'Archivo no válido', description: 'Por favor, suba un PDF o una imagen.' });
        }
    };

    const isRowValid = (p) => {
        const totalPagado = (parseFloat(p.efectivo) || 0) + (parseFloat(p.transferencia) || 0);
        const totalAPagar = parseFloat(p.total_a_pagar) || 0;
        return p.recibo && totalAPagar > 0 && Math.abs(totalPagado - totalAPagar) < 0.1;
    };

    const isFormReadyToProcess = useMemo(() => {
        if (payments.length === 0) return false;
        return payments.some(isRowValid);
    }, [payments]);

    const totalGeneral = useMemo(() => {
        return payments.reduce((acc, curr) => {
            if (isRowValid(curr)) {
                const val = parseFloat(curr.total_a_pagar) || 0;
                return acc + val;
            }
            return acc;
        }, 0);
    }, [payments]);

    const totalEfectivo = useMemo(() => {
        return payments.reduce((acc, curr) => {
            if (isRowValid(curr)) {
                const val = parseFloat(curr.efectivo) || 0;
                return acc + val;
            }
            return acc;
        }, 0);
    }, [payments]);

    const tableHeaders = (
        <TableHeader className="sticky top-0 z-10 bg-card">
            <TableRow>
                <TableHead className="min-w-[150px] sticky left-0 bg-card z-20">Empleado</TableHead>
                <TableHead className="min-w-[120px]">Puesto</TableHead>
                <TableHead className="min-w-[100px]">Horas</TableHead>
                <TableHead className="min-w-[120px]">Monto</TableHead>
                <TableHead className="min-w-[120px]">Efectivo</TableHead>
                <TableHead className="min-w-[120px]">Transferencia</TableHead>
                <TableHead className="min-w-[120px]">Extras</TableHead>
                <TableHead className="min-w-[120px]">Descuentos</TableHead>
                <TableHead className="min-w-[140px]">Desc. Préstamo</TableHead>
                <TableHead className="min-w-[150px]">Total a Pagar</TableHead>
                <TableHead className="min-w-[150px]">Detalle</TableHead>
                <TableHead className="min-w-[200px]">Recibo</TableHead>
            </TableRow>
        </TableHeader>
    );

    return (
        <div className="flex flex-col h-full overflow-hidden">
            <div ref={topScrollRef} className="overflow-x-auto">
                <div className="h-1"></div>
            </div>
            <div ref={bottomScrollRef} className="flex-grow overflow-auto relative">
                <Table className="min-w-max">
                    {tableHeaders}
                    <TableBody>
    {payments.map((p, index) => {
        const isValid = isRowValid(p);
        const totalPagado = (parseFloat(p.efectivo) || 0) + (parseFloat(p.transferencia) || 0);
        const totalAPagar = parseFloat(p.total_a_pagar) || 0;
        const amountsMatch = Math.abs(totalPagado - totalAPagar) < 0.1;
        const hasActiveLoans = p.prestamos_activos && p.prestamos_activos.length > 0;
        const totalLoanBalance = hasActiveLoans ? p.prestamos_activos.reduce((sum, loan) => sum + parseFloat(loan.saldo_actual), 0) : 0;

        return (
            <TableRow key={p.empleado_id} className={`hover:bg-muted/50 ${isValid ? 'bg-green-900/50' : ''}`}>
                
                <TableCell className="py-1 font-medium text-xs sticky left-0 bg-card z-10">
                    <div className="flex flex-col">
                        <span>{p.nombre_completo}</span>
                        {hasActiveLoans && (
                            <TooltipProvider>
                                <Tooltip>
                                    <TooltipTrigger asChild>
                                        <Badge variant="outline" className="w-fit text-[10px] h-4 px-1 border-orange-400 text-orange-500 cursor-help">
                                            Préstamo: ${totalLoanBalance.toLocaleString('es-AR')}
                                        </Badge>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                        <p>Tiene préstamos activos.</p>
                                        <p>Saldo pendiente: ${totalLoanBalance.toLocaleString('es-AR')}</p>
                                    </TooltipContent>
                                </Tooltip>
                            </TooltipProvider>
                        )}
                    </div>
                </TableCell>
                <TableCell className="py-1 text-xs">{p.puesto}</TableCell>
                
                <TableCell className="py-1">
                    <Input 
                        type="number" 
                        value={p.horas_trabajadas} 
                        onChange={e => updatePaymentRow(index, 'horas_trabajadas', e.target.value)} 
                        disabled={p.tipo_pago !== 'Por hora'} 
                        className="w-16 h-7 text-xs px-1" 
                    />
                </TableCell>
                
                <TableCell className="py-1 text-xs">
                    ${parseFloat(p.monto_base).toLocaleString('es-AR')}
                    {p.tipo_pago === 'Por hora' && <span className="text-[10px] text-muted-foreground">/hr</span>}
                </TableCell>
                
                <TableCell className="py-1">
                    <Input 
                        type="number" 
                        value={p.efectivo} 
                        onChange={e => updatePaymentRow(index, 'efectivo', e.target.value)} 
                        className="w-20 h-7 text-xs px-1" 
                    />
                </TableCell>
                <TableCell className="py-1">
                    <Input 
                        type="number" 
                        value={p.transferencia} 
                        onChange={e => updatePaymentRow(index, 'transferencia', e.target.value)} 
                        className="w-20 h-7 text-xs px-1" 
                    />
                </TableCell>
                <TableCell className="py-1">
                    <Input 
                        type="number" 
                        value={p.extras} 
                        onChange={e => updatePaymentRow(index, 'extras', e.target.value)} 
                        className="w-20 h-7 text-xs px-1" 
                    />
                </TableCell>
                <TableCell className="py-1">
                    <Input 
                        type="number" 
                        value={p.descuentos} 
                        onChange={e => updatePaymentRow(index, 'descuentos', e.target.value)} 
                        className="w-20 h-7 text-xs px-1" 
                    />
                </TableCell>
                
                <TableCell className="py-1">
                    <Input 
                        type="number" 
                        value={p.descuento_prestamo} 
                        onChange={e => updatePaymentRow(index, 'descuento_prestamo', e.target.value)} 
                        disabled={!hasActiveLoans}
                        placeholder={hasActiveLoans ? "Monto" : "-"}
                        className={`w-24 h-7 text-xs px-1 ${hasActiveLoans ? 'border-orange-300' : ''}`} 
                    />
                </TableCell>

                <TableCell className={`py-1 font-bold text-xs ${amountsMatch ? 'text-green-400' : 'text-red-400'}`}>
                    ${p.total_a_pagar.toLocaleString('es-AR', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                </TableCell>
                
                <TableCell className="py-1">
                    <Input 
                        value={p.detalle} 
                        onChange={e => updatePaymentRow(index, 'detalle', e.target.value)} 
                        className="w-28 h-7 text-xs px-1" 
                    />
                </TableCell>
                
                <TableCell className="py-1">
                    <Label htmlFor={`receipt-${index}`} className="cursor-pointer text-xs inline-flex items-center h-7">
                        {p.recibo ? (
                            <span className="flex items-center text-green-400 truncate max-w-[100px]">
                                <CheckCircle className="h-3 w-3 mr-1" /> {p.recibo_nombre}
                            </span>
                        ) : (
                            <span className="flex items-center text-blue-400 hover:underline">
                                <Paperclip className="h-3 w-3 mr-1" /> Adjuntar
                            </span>
                        )}
                    </Label>
                    <Input id={`receipt-${index}`} type="file" accept="application/pdf,image/*" onChange={(e) => handleReceiptChange(index, e.target.files[0])} className="sr-only" />
                </TableCell>
            </TableRow>
        )})}
</TableBody>
                </Table>
            </div>
            <div className="flex-shrink-0 pt-2 space-y-2 bg-background border-t mt-1">
    {isFormReadyToProcess && (
        <div className="flex items-center p-2 text-xs text-green-200 bg-green-900/50 rounded-md border border-green-700">
            <CheckCircle className="w-4 h-4 mr-2" />
            <span>¡Listo para procesar! (Filas verdes)</span>
        </div>
                )}
                
                <div className="flex justify-end gap-4">
                    <span className="text-xl font-bold text-green-600">Total Efectivo: ${totalEfectivo.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                    <span className="text-xl font-bold">Total General: ${totalGeneral.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>

                <div className="flex justify-between">
                    <Button variant="outline" onClick={onReset}><RotateCcw className="mr-2 h-4 w-4" /> Cancelar y Reiniciar</Button>
                    <Button onClick={onProcess} disabled={isLoading || !isFormReadyToProcess}>
                        {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Wallet className="mr-2 h-4 w-4" />}
                        Procesar Pagos
                    </Button>
                </div>
            </div>
        </div>
    );
};

export default EmployeePaymentForm;