import React, { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useBranch } from '@/contexts/BranchContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Search } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const EmployeePaymentHistory = () => {
    const { userRole, userProfile } = useAuth();
    const { availableBranches } = useBranch();
    const { toast } = useToast();

    const [history, setHistory] = useState([]);
    const [loadingHistory, setLoadingHistory] = useState(false);
    const [historyBranchId, setHistoryBranchId] = useState('');
    const [historyMonth, setHistoryMonth] = useState(format(new Date(), 'yyyy-MM'));

    useEffect(() => {
        if (userRole === 'gerente' && userProfile?.sucursal_id) {
            setHistoryBranchId(userProfile.sucursal_id.toString());
        }
    }, [userProfile, userRole]);

    const fetchHistory = async () => {
        if (!historyBranchId || !historyMonth) return;
        setLoadingHistory(true);
        const [year, month] = historyMonth.split('-');
        const startDate = `${year}-${month}-01`;
        const endDate = new Date(year, month, 0);
        const endDateStr = `${year}-${month}-${endDate.getDate()}`;
    
        let query = supabase.from('pagos_empleados')
          .select('*, sucursales(nombre)')
          .eq('sucursal_id', parseInt(historyBranchId))
          .gte('fecha_pago', startDate)
          .lte('fecha_pago', endDateStr)
          .order('fecha_pago', { ascending: false });
    
        const { data, error } = await query;
    
        if (error) {
          toast({ variant: 'destructive', title: 'Error', description: 'No se pudo cargar el historial.' });
        } else {
          setHistory(data);
        }
        setLoadingHistory(false);
    };

    return (
        <DialogContent className="max-w-7xl">
            <DialogHeader>
                <DialogTitle>Historial de Pagos de Empleados</DialogTitle>
                <DialogDescription>Consulta los pagos procesados anteriormente.</DialogDescription>
            </DialogHeader>
            <div className="flex gap-4 items-end my-4">
                {userRole === 'admin' && (
                    <div className="flex-1">
                        <Label htmlFor="history_branch">Sucursal</Label>
                        <Select value={historyBranchId} onValueChange={setHistoryBranchId} disabled={loadingHistory}>
                            <SelectTrigger><SelectValue placeholder="Seleccionar sucursal" /></SelectTrigger>
                            <SelectContent>{availableBranches.map(b => <SelectItem key={b.id} value={b.id.toString()}>{b.nombre}</SelectItem>)}</SelectContent>
                        </Select>
                    </div>
                )}
                <div className="flex-1">
                    <Label htmlFor="history_month">Mes</Label>
                    <Input type="month" id="history_month" value={historyMonth} onChange={e => setHistoryMonth(e.target.value)} disabled={loadingHistory} />
                </div>
                <Button onClick={fetchHistory} disabled={loadingHistory || !historyBranchId || !historyMonth}>
                    {loadingHistory ? <Loader2 className="h-4 w-4 animate-spin"/> : <Search className="h-4 w-4"/>}
                </Button>
            </div>
            <div className="max-h-[60vh] overflow-y-auto">
            {loadingHistory ? <p className="text-center py-4">Cargando...</p> : history.length > 0 ? (
                history.map(h => (
                    <Card key={h.id} className="mb-4">
                        <CardHeader>
                            <CardTitle className="text-lg">Pago del {format(new Date(h.fecha_pago), "dd 'de' MMMM, yyyy", { locale: es })} - {h.sucursales.nombre}</CardTitle>
                            <CardDescription>Total General: ${parseFloat(h.total_pagado).toLocaleString('es-AR', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</CardDescription>
                        </CardHeader>
                        <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Empleado</TableHead><TableHead>Puesto</TableHead><TableHead>Horas</TableHead>
                                    <TableHead>Monto</TableHead><TableHead>Efectivo</TableHead><TableHead>Transf.</TableHead>
                                    <TableHead>Extras</TableHead><TableHead>Desc.</TableHead><TableHead>Total</TableHead>
                                    <TableHead>Detalle</TableHead><TableHead>Recibo</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                            {h.pagos_individuales.map((p, i) => (
                                <TableRow key={`${h.id}-detail-${i}`}>
                                    <TableCell>{p.nombre_completo}</TableCell>
                                    <TableCell>{p.puesto}</TableCell>
                                    <TableCell>{p.tipo_pago === 'Por hora' ? p.horas_trabajadas : 'N/A'}</TableCell>
                                    <TableCell>
                                        ${parseFloat(p.monto_base).toLocaleString('es-AR')}
                                        {p.tipo_pago === 'Por hora' && <span className="text-xs text-muted-foreground">/hr</span>}
                                    </TableCell>
                                    <TableCell>${parseFloat(p.efectivo || 0).toLocaleString('es-AR')}</TableCell>
                                    <TableCell>${parseFloat(p.transferencia || 0).toLocaleString('es-AR')}</TableCell>
                                    <TableCell>${parseFloat(p.extras || 0).toLocaleString('es-AR')}</TableCell>
                                    <TableCell>${parseFloat(p.descuentos || 0).toLocaleString('es-AR')}</TableCell>
                                    <TableCell className="font-bold">${parseFloat(p.total_a_pagar).toLocaleString('es-AR')}</TableCell>
                                    <TableCell>{p.detalle}</TableCell>
                                    <TableCell><a href={p.recibo_url} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">Ver</a></TableCell>
                                </TableRow>
                            ))}
                            </TableBody>
                        </Table>
                        </CardContent>
                    </Card>
                ))
            ) : <p className="text-center text-muted-foreground py-4">No hay registros para la selección.</p>}
            </div>
        </DialogContent>
    );
};

export default EmployeePaymentHistory;