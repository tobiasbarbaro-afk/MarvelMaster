import React from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useBranch } from '@/contexts/BranchContext';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { Loader2, CalendarPlus as CalendarIcon, ArrowRight } from 'lucide-react';

const EmployeePaymentStep1 = ({ selectedBranchId, setSelectedBranchId, paymentDate, setPaymentDate, isLoading, onNext }) => {
    const { userRole } = useAuth();
    const { availableBranches, loadingBranches } = useBranch();

    return (
        <div className="space-y-6 max-w-md mx-auto">
            {userRole === 'admin' && (
                <div>
                    <Label htmlFor="branch">Sucursal</Label>
                    <Select value={selectedBranchId} onValueChange={setSelectedBranchId} disabled={loadingBranches}>
                        <SelectTrigger><SelectValue placeholder="Seleccionar sucursal" /></SelectTrigger>
                        <SelectContent>{availableBranches.map(b => <SelectItem key={b.id} value={b.id.toString()}>{b.nombre}</SelectItem>)}</SelectContent>
                    </Select>
                </div>
            )}
            <div>
                <Label>Fecha del Pago</Label>
                <Popover>
                    <PopoverTrigger asChild>
                        <Button variant={"outline"} className={cn("w-full justify-start text-left font-normal", !paymentDate && "text-muted-foreground")}>
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {paymentDate ? format(paymentDate, "PPP", { locale: es }) : <span>Seleccionar fecha</span>}
                        </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={paymentDate} onSelect={setPaymentDate} initialFocus /></PopoverContent>
                </Popover>
            </div>
            <Button onClick={onNext} disabled={isLoading || !selectedBranchId}>
                {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ArrowRight className="mr-2 h-4 w-4" />}
                Siguiente
            </Button>
        </div>
    );
};

export default EmployeePaymentStep1;