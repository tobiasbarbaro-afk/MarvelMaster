import React, { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useBranch } from '@/contexts/BranchContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Search, FileText, ExternalLink } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const CadetPaymentHistory = () => {
    const { userRole, userProfile } = useAuth();
    const { availableBranches } = useBranch();
    const { toast } = useToast();

    const [history, setHistory] = useState([]);
    const [loadingHistory, setLoadingHistory] = useState(false);
    const [historyBranchId, setHistoryBranchId] = useState('');
    const [historyMonth, setHistoryMonth] = useState(format(new Date(), 'yyyy-MM'));

    useEffect(() => {
        if (userRole === 'gerente' && userProfile?.sucursal_id) {
            setHistoryBranchId(userProfile.sucursal_id.toString());
        }
    }, [userProfile, userRole]);

    const fetchHistory = async () => {
        if (!historyBranchId || !historyMonth) return;
        setLoadingHistory(true);
        const [year, month] = historyMonth.split('-');
        const startDate = `${year}-${month}-01`;
        const endDate = new Date(year, month, 0);
        const endDateStr = `${year}-${month}-${endDate.getDate()}`;
    
        let query = supabase.from('pagos_cadetes')
          .select('*, sucursales(nombre)')
          .eq('sucursal_id', parseInt(historyBranchId))
          .gte('fecha_pago', startDate)
          .lte('fecha_pago', endDateStr)
          .order('fecha_pago', { ascending: false });
    
        const { data, error } = await query;
    
        if (error) {
          console.error(error);
          toast({ variant: 'destructive', title: 'Error', description: 'No se pudo cargar el historial.' });
        } else {
          setHistory(data);
        }
        setLoadingHistory(false);
    };

    return (
        <DialogContent className="max-w-7xl max-h-[90vh] flex flex-col">
            <DialogHeader>
                <DialogTitle>Historial de Pagos de Cadetes</DialogTitle>
                <DialogDescription>Consulta los pagos procesados anteriormente.</DialogDescription>
            </DialogHeader>
            
            <div className="flex gap-4 items-end my-4 flex-shrink-0">
                {userRole === 'admin' && (
                    <div className="flex-1">
                        <Label htmlFor="history_branch">Sucursal</Label>
                        <Select value={historyBranchId} onValueChange={setHistoryBranchId} disabled={loadingHistory}>
                            <SelectTrigger><SelectValue placeholder="Seleccionar sucursal" /></SelectTrigger>
                            <SelectContent>{availableBranches.map(b => <SelectItem key={b.id} value={b.id.toString()}>{b.nombre}</SelectItem>)}</SelectContent>
                        </Select>
                    </div>
                )}
                <div className="flex-1">
                    <Label htmlFor="history_month">Mes</Label>
                    <Input type="month" id="history_month" value={historyMonth} onChange={e => setHistoryMonth(e.target.value)} disabled={loadingHistory} />
                </div>
                <Button onClick={fetchHistory} disabled={loadingHistory || !historyBranchId || !historyMonth}>
                    {loadingHistory ? <Loader2 className="h-4 w-4 animate-spin"/> : <Search className="h-4 w-4"/>}
                </Button>
            </div>

            <div className="flex-grow overflow-y-auto pr-2">
                {loadingHistory ? (
                    <div className="flex justify-center py-8"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
                ) : history.length > 0 ? (
                    history.map(h => (
                        <Card key={h.id} className="mb-4 border-l-4 border-l-primary">
                            <CardHeader className="pb-2">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <CardTitle className="text-lg">Pago del {format(new Date(h.fecha_pago), "dd 'de' MMMM, yyyy", { locale: es })}</CardTitle>
                                        <CardDescription className="mt-1 font-medium text-foreground">{h.sucursales?.nombre}</CardDescription>
                                    </div>
                                    <div className="text-right">
                                        <div className="text-2xl font-bold text-primary">${parseFloat(h.total_pagado).toLocaleString('es-AR', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                                        <div className="text-xs text-muted-foreground mt-1">Total del bloque</div>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <div className="mb-4 flex items-center gap-2">
                                    {h.advertencia ? (
                                        <a href={h.advertencia} target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-sm text-blue-600 hover:text-blue-800 hover:underline bg-blue-50 px-3 py-1 rounded-full border border-blue-200 transition-colors">
                                            <FileText className="h-4 w-4 mr-2" />
                                            Ver Recibo del Bloque
                                            <ExternalLink className="h-3 w-3 ml-1" />
                                        </a>
                                    ) : (
                                        <span className="text-sm text-muted-foreground italic">Sin recibo adjunto</span>
                                    )}
                                </div>

                                <div className="rounded-md border">
                                    <Table>
                                        <TableHeader>
                                            <TableRow className="bg-muted/50">
                                                <TableHead>Cadete</TableHead>
                                                <TableHead>Monto Base</TableHead>
                                                <TableHead>Ad. Piso</TableHead>
                                                <TableHead>Extras</TableHead>
                                                <TableHead>Descuentos</TableHead>
                                                <TableHead>Justificación</TableHead>
                                                <TableHead className="text-right">Total</TableHead>
                                            </TableRow>
                                        </TableHeader>
                                        <TableBody>
                                        {h.pagos_individuales && h.pagos_individuales.map((p, i) => (
                                            <TableRow key={`${h.id}-detail-${i}`}>
                                                <TableCell className="font-medium">{p.nombre}</TableCell>
                                                <TableCell>${parseFloat(p.monto || 0).toLocaleString('es-AR')}</TableCell>
                                                <TableCell>${parseFloat(p.ad_piso || 0).toLocaleString('es-AR')}</TableCell>
                                                <TableCell className="text-green-600">
                                                    {parseFloat(p.extras || 0) > 0 ? `+${parseFloat(p.extras).toLocaleString('es-AR')}` : '-'}
                                                </TableCell>
                                                <TableCell className="text-red-600">
                                                    {parseFloat(p.descuentos || 0) > 0 ? `-${parseFloat(p.descuentos).toLocaleString('es-AR')}` : '-'}
                                                </TableCell>
                                                <TableCell className="text-muted-foreground text-sm max-w-[200px] truncate" title={p.justificacion}>
                                                    {p.justificacion || '-'}
                                                </TableCell>
                                                <TableCell className="text-right font-bold">
                                                    ${parseFloat(p.total_a_pagar).toLocaleString('es-AR', {minimumFractionDigits: 2})}
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                        </TableBody>
                                    </Table>
                                </div>
                            </CardContent>
                        </Card>
                    ))
                ) : (
                    <div className="text-center py-12 border-2 border-dashed rounded-lg">
                        <p className="text-muted-foreground">No hay registros de pagos para la selección actual.</p>
                    </div>
                )}
            </div>
        </DialogContent>
    );
};

export default CadetPaymentHistory;